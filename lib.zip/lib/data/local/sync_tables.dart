
import 'package:drift/drift.dart';

class SyncOutbox extends Table {
  TextColumn get opId => text()();
  TextColumn get salonId => text()();

  TextColumn get entityType => text()();
  TextColumn get entityId => text()();

  TextColumn get op => text()();
  IntColumn get baseVersion => integer().withDefault(const Constant(0))();
  TextColumn get payloadJson => text().withDefault(const Constant('{}'))();

  DateTimeColumn get createdAt =>
      dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {opId};
}

class SyncState extends Table {
  TextColumn get salonId => text()();
  IntColumn get lastToken => integer().withDefault(const Constant(0))();
  TextColumn get deviceId => text().nullable()();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();

  @override
  Set<Column> get primaryKey => {salonId};
}
