// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_db.dart';

// ignore_for_file: type=lint
class $SalonsTable extends Salons with TableInfo<$SalonsTable, Salon> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SalonsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [id, name];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'salons';
  @override
  VerificationContext validateIntegrity(Insertable<Salon> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Salon map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Salon(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
    );
  }

  @override
  $SalonsTable createAlias(String alias) {
    return $SalonsTable(attachedDatabase, alias);
  }
}

class Salon extends DataClass implements Insertable<Salon> {
  final String id;
  final String name;
  const Salon({required this.id, required this.name});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['name'] = Variable<String>(name);
    return map;
  }

  SalonsCompanion toCompanion(bool nullToAbsent) {
    return SalonsCompanion(
      id: Value(id),
      name: Value(name),
    );
  }

  factory Salon.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Salon(
      id: serializer.fromJson<String>(json['id']),
      name: serializer.fromJson<String>(json['name']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'name': serializer.toJson<String>(name),
    };
  }

  Salon copyWith({String? id, String? name}) => Salon(
        id: id ?? this.id,
        name: name ?? this.name,
      );
  Salon copyWithCompanion(SalonsCompanion data) {
    return Salon(
      id: data.id.present ? data.id.value : this.id,
      name: data.name.present ? data.name.value : this.name,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Salon(')
          ..write('id: $id, ')
          ..write('name: $name')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, name);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Salon && other.id == this.id && other.name == this.name);
}

class SalonsCompanion extends UpdateCompanion<Salon> {
  final Value<String> id;
  final Value<String> name;
  final Value<int> rowid;
  const SalonsCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SalonsCompanion.insert({
    required String id,
    required String name,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        name = Value(name);
  static Insertable<Salon> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SalonsCompanion copyWith(
      {Value<String>? id, Value<String>? name, Value<int>? rowid}) {
    return SalonsCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SalonsCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $UsersTable extends Users with TableInfo<$UsersTable, User> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UsersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _usernameMeta =
      const VerificationMeta('username');
  @override
  late final GeneratedColumn<String> username = GeneratedColumn<String>(
      'username', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _usernameNormMeta =
      const VerificationMeta('usernameNorm');
  @override
  late final GeneratedColumn<String> usernameNorm = GeneratedColumn<String>(
      'username_norm', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _passwordMeta =
      const VerificationMeta('password');
  @override
  late final GeneratedColumn<String> password = GeneratedColumn<String>(
      'password', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _isAdminMeta =
      const VerificationMeta('isAdmin');
  @override
  late final GeneratedColumn<bool> isAdmin = GeneratedColumn<bool>(
      'is_admin', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_admin" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, salonId, username, usernameNorm, password, isActive, isAdmin];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'users';
  @override
  VerificationContext validateIntegrity(Insertable<User> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('username')) {
      context.handle(_usernameMeta,
          username.isAcceptableOrUnknown(data['username']!, _usernameMeta));
    } else if (isInserting) {
      context.missing(_usernameMeta);
    }
    if (data.containsKey('username_norm')) {
      context.handle(
          _usernameNormMeta,
          usernameNorm.isAcceptableOrUnknown(
              data['username_norm']!, _usernameNormMeta));
    }
    if (data.containsKey('password')) {
      context.handle(_passwordMeta,
          password.isAcceptableOrUnknown(data['password']!, _passwordMeta));
    } else if (isInserting) {
      context.missing(_passwordMeta);
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('is_admin')) {
      context.handle(_isAdminMeta,
          isAdmin.isAcceptableOrUnknown(data['is_admin']!, _isAdminMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  User map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return User(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      username: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}username'])!,
      usernameNorm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}username_norm']),
      password: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}password'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      isAdmin: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_admin'])!,
    );
  }

  @override
  $UsersTable createAlias(String alias) {
    return $UsersTable(attachedDatabase, alias);
  }
}

class User extends DataClass implements Insertable<User> {
  final String id;
  final String salonId;
  final String username;
  final String? usernameNorm;
  final String password;

  /// Soft-disable. Inactive users cannot login and their staff column is hidden.
  final bool isActive;
  final bool isAdmin;
  const User(
      {required this.id,
      required this.salonId,
      required this.username,
      this.usernameNorm,
      required this.password,
      required this.isActive,
      required this.isAdmin});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['username'] = Variable<String>(username);
    if (!nullToAbsent || usernameNorm != null) {
      map['username_norm'] = Variable<String>(usernameNorm);
    }
    map['password'] = Variable<String>(password);
    map['is_active'] = Variable<bool>(isActive);
    map['is_admin'] = Variable<bool>(isAdmin);
    return map;
  }

  UsersCompanion toCompanion(bool nullToAbsent) {
    return UsersCompanion(
      id: Value(id),
      salonId: Value(salonId),
      username: Value(username),
      usernameNorm: usernameNorm == null && nullToAbsent
          ? const Value.absent()
          : Value(usernameNorm),
      password: Value(password),
      isActive: Value(isActive),
      isAdmin: Value(isAdmin),
    );
  }

  factory User.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return User(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      username: serializer.fromJson<String>(json['username']),
      usernameNorm: serializer.fromJson<String?>(json['usernameNorm']),
      password: serializer.fromJson<String>(json['password']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      isAdmin: serializer.fromJson<bool>(json['isAdmin']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'username': serializer.toJson<String>(username),
      'usernameNorm': serializer.toJson<String?>(usernameNorm),
      'password': serializer.toJson<String>(password),
      'isActive': serializer.toJson<bool>(isActive),
      'isAdmin': serializer.toJson<bool>(isAdmin),
    };
  }

  User copyWith(
          {String? id,
          String? salonId,
          String? username,
          Value<String?> usernameNorm = const Value.absent(),
          String? password,
          bool? isActive,
          bool? isAdmin}) =>
      User(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        username: username ?? this.username,
        usernameNorm:
            usernameNorm.present ? usernameNorm.value : this.usernameNorm,
        password: password ?? this.password,
        isActive: isActive ?? this.isActive,
        isAdmin: isAdmin ?? this.isAdmin,
      );
  User copyWithCompanion(UsersCompanion data) {
    return User(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      username: data.username.present ? data.username.value : this.username,
      usernameNorm: data.usernameNorm.present
          ? data.usernameNorm.value
          : this.usernameNorm,
      password: data.password.present ? data.password.value : this.password,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      isAdmin: data.isAdmin.present ? data.isAdmin.value : this.isAdmin,
    );
  }

  @override
  String toString() {
    return (StringBuffer('User(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('username: $username, ')
          ..write('usernameNorm: $usernameNorm, ')
          ..write('password: $password, ')
          ..write('isActive: $isActive, ')
          ..write('isAdmin: $isAdmin')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, salonId, username, usernameNorm, password, isActive, isAdmin);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is User &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.username == this.username &&
          other.usernameNorm == this.usernameNorm &&
          other.password == this.password &&
          other.isActive == this.isActive &&
          other.isAdmin == this.isAdmin);
}

class UsersCompanion extends UpdateCompanion<User> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<String> username;
  final Value<String?> usernameNorm;
  final Value<String> password;
  final Value<bool> isActive;
  final Value<bool> isAdmin;
  final Value<int> rowid;
  const UsersCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.username = const Value.absent(),
    this.usernameNorm = const Value.absent(),
    this.password = const Value.absent(),
    this.isActive = const Value.absent(),
    this.isAdmin = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  UsersCompanion.insert({
    required String id,
    required String salonId,
    required String username,
    this.usernameNorm = const Value.absent(),
    required String password,
    this.isActive = const Value.absent(),
    this.isAdmin = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        username = Value(username),
        password = Value(password);
  static Insertable<User> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<String>? username,
    Expression<String>? usernameNorm,
    Expression<String>? password,
    Expression<bool>? isActive,
    Expression<bool>? isAdmin,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (username != null) 'username': username,
      if (usernameNorm != null) 'username_norm': usernameNorm,
      if (password != null) 'password': password,
      if (isActive != null) 'is_active': isActive,
      if (isAdmin != null) 'is_admin': isAdmin,
      if (rowid != null) 'rowid': rowid,
    });
  }

  UsersCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<String>? username,
      Value<String?>? usernameNorm,
      Value<String>? password,
      Value<bool>? isActive,
      Value<bool>? isAdmin,
      Value<int>? rowid}) {
    return UsersCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      username: username ?? this.username,
      usernameNorm: usernameNorm ?? this.usernameNorm,
      password: password ?? this.password,
      isActive: isActive ?? this.isActive,
      isAdmin: isAdmin ?? this.isAdmin,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (username.present) {
      map['username'] = Variable<String>(username.value);
    }
    if (usernameNorm.present) {
      map['username_norm'] = Variable<String>(usernameNorm.value);
    }
    if (password.present) {
      map['password'] = Variable<String>(password.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (isAdmin.present) {
      map['is_admin'] = Variable<bool>(isAdmin.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UsersCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('username: $username, ')
          ..write('usernameNorm: $usernameNorm, ')
          ..write('password: $password, ')
          ..write('isActive: $isActive, ')
          ..write('isAdmin: $isAdmin, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncOutboxTable extends SyncOutbox
    with TableInfo<$SyncOutboxTable, SyncOutboxData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncOutboxTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _opIdMeta = const VerificationMeta('opId');
  @override
  late final GeneratedColumn<String> opId = GeneratedColumn<String>(
      'op_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _opMeta = const VerificationMeta('op');
  @override
  late final GeneratedColumn<String> op = GeneratedColumn<String>(
      'op', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _baseVersionMeta =
      const VerificationMeta('baseVersion');
  @override
  late final GeneratedColumn<int> baseVersion = GeneratedColumn<int>(
      'base_version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _payloadJsonMeta =
      const VerificationMeta('payloadJson');
  @override
  late final GeneratedColumn<String> payloadJson = GeneratedColumn<String>(
      'payload_json', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('{}'));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        opId,
        salonId,
        entityType,
        entityId,
        op,
        baseVersion,
        payloadJson,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_outbox';
  @override
  VerificationContext validateIntegrity(Insertable<SyncOutboxData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('op_id')) {
      context.handle(
          _opIdMeta, opId.isAcceptableOrUnknown(data['op_id']!, _opIdMeta));
    } else if (isInserting) {
      context.missing(_opIdMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('op')) {
      context.handle(_opMeta, op.isAcceptableOrUnknown(data['op']!, _opMeta));
    } else if (isInserting) {
      context.missing(_opMeta);
    }
    if (data.containsKey('base_version')) {
      context.handle(
          _baseVersionMeta,
          baseVersion.isAcceptableOrUnknown(
              data['base_version']!, _baseVersionMeta));
    }
    if (data.containsKey('payload_json')) {
      context.handle(
          _payloadJsonMeta,
          payloadJson.isAcceptableOrUnknown(
              data['payload_json']!, _payloadJsonMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {opId};
  @override
  SyncOutboxData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncOutboxData(
      opId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}op_id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      op: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}op'])!,
      baseVersion: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}base_version'])!,
      payloadJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payload_json'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $SyncOutboxTable createAlias(String alias) {
    return $SyncOutboxTable(attachedDatabase, alias);
  }
}

class SyncOutboxData extends DataClass implements Insertable<SyncOutboxData> {
  final String opId;
  final String salonId;
  final String entityType;
  final String entityId;
  final String op;
  final int baseVersion;
  final String payloadJson;
  final DateTime createdAt;
  const SyncOutboxData(
      {required this.opId,
      required this.salonId,
      required this.entityType,
      required this.entityId,
      required this.op,
      required this.baseVersion,
      required this.payloadJson,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['op_id'] = Variable<String>(opId);
    map['salon_id'] = Variable<String>(salonId);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['op'] = Variable<String>(op);
    map['base_version'] = Variable<int>(baseVersion);
    map['payload_json'] = Variable<String>(payloadJson);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  SyncOutboxCompanion toCompanion(bool nullToAbsent) {
    return SyncOutboxCompanion(
      opId: Value(opId),
      salonId: Value(salonId),
      entityType: Value(entityType),
      entityId: Value(entityId),
      op: Value(op),
      baseVersion: Value(baseVersion),
      payloadJson: Value(payloadJson),
      createdAt: Value(createdAt),
    );
  }

  factory SyncOutboxData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncOutboxData(
      opId: serializer.fromJson<String>(json['opId']),
      salonId: serializer.fromJson<String>(json['salonId']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      op: serializer.fromJson<String>(json['op']),
      baseVersion: serializer.fromJson<int>(json['baseVersion']),
      payloadJson: serializer.fromJson<String>(json['payloadJson']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'opId': serializer.toJson<String>(opId),
      'salonId': serializer.toJson<String>(salonId),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'op': serializer.toJson<String>(op),
      'baseVersion': serializer.toJson<int>(baseVersion),
      'payloadJson': serializer.toJson<String>(payloadJson),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  SyncOutboxData copyWith(
          {String? opId,
          String? salonId,
          String? entityType,
          String? entityId,
          String? op,
          int? baseVersion,
          String? payloadJson,
          DateTime? createdAt}) =>
      SyncOutboxData(
        opId: opId ?? this.opId,
        salonId: salonId ?? this.salonId,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        op: op ?? this.op,
        baseVersion: baseVersion ?? this.baseVersion,
        payloadJson: payloadJson ?? this.payloadJson,
        createdAt: createdAt ?? this.createdAt,
      );
  SyncOutboxData copyWithCompanion(SyncOutboxCompanion data) {
    return SyncOutboxData(
      opId: data.opId.present ? data.opId.value : this.opId,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      op: data.op.present ? data.op.value : this.op,
      baseVersion:
          data.baseVersion.present ? data.baseVersion.value : this.baseVersion,
      payloadJson:
          data.payloadJson.present ? data.payloadJson.value : this.payloadJson,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncOutboxData(')
          ..write('opId: $opId, ')
          ..write('salonId: $salonId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('op: $op, ')
          ..write('baseVersion: $baseVersion, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(opId, salonId, entityType, entityId, op,
      baseVersion, payloadJson, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncOutboxData &&
          other.opId == this.opId &&
          other.salonId == this.salonId &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.op == this.op &&
          other.baseVersion == this.baseVersion &&
          other.payloadJson == this.payloadJson &&
          other.createdAt == this.createdAt);
}

class SyncOutboxCompanion extends UpdateCompanion<SyncOutboxData> {
  final Value<String> opId;
  final Value<String> salonId;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<String> op;
  final Value<int> baseVersion;
  final Value<String> payloadJson;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const SyncOutboxCompanion({
    this.opId = const Value.absent(),
    this.salonId = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.op = const Value.absent(),
    this.baseVersion = const Value.absent(),
    this.payloadJson = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncOutboxCompanion.insert({
    required String opId,
    required String salonId,
    required String entityType,
    required String entityId,
    required String op,
    this.baseVersion = const Value.absent(),
    this.payloadJson = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : opId = Value(opId),
        salonId = Value(salonId),
        entityType = Value(entityType),
        entityId = Value(entityId),
        op = Value(op);
  static Insertable<SyncOutboxData> custom({
    Expression<String>? opId,
    Expression<String>? salonId,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<String>? op,
    Expression<int>? baseVersion,
    Expression<String>? payloadJson,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (opId != null) 'op_id': opId,
      if (salonId != null) 'salon_id': salonId,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (op != null) 'op': op,
      if (baseVersion != null) 'base_version': baseVersion,
      if (payloadJson != null) 'payload_json': payloadJson,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncOutboxCompanion copyWith(
      {Value<String>? opId,
      Value<String>? salonId,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<String>? op,
      Value<int>? baseVersion,
      Value<String>? payloadJson,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return SyncOutboxCompanion(
      opId: opId ?? this.opId,
      salonId: salonId ?? this.salonId,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      op: op ?? this.op,
      baseVersion: baseVersion ?? this.baseVersion,
      payloadJson: payloadJson ?? this.payloadJson,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (opId.present) {
      map['op_id'] = Variable<String>(opId.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (op.present) {
      map['op'] = Variable<String>(op.value);
    }
    if (baseVersion.present) {
      map['base_version'] = Variable<int>(baseVersion.value);
    }
    if (payloadJson.present) {
      map['payload_json'] = Variable<String>(payloadJson.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncOutboxCompanion(')
          ..write('opId: $opId, ')
          ..write('salonId: $salonId, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('op: $op, ')
          ..write('baseVersion: $baseVersion, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncStateTable extends SyncState
    with TableInfo<$SyncStateTable, SyncStateData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncStateTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _lastTokenMeta =
      const VerificationMeta('lastToken');
  @override
  late final GeneratedColumn<int> lastToken = GeneratedColumn<int>(
      'last_token', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deviceIdMeta =
      const VerificationMeta('deviceId');
  @override
  late final GeneratedColumn<String> deviceId = GeneratedColumn<String>(
      'device_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastSyncedAtMeta =
      const VerificationMeta('lastSyncedAt');
  @override
  late final GeneratedColumn<DateTime> lastSyncedAt = GeneratedColumn<DateTime>(
      'last_synced_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [salonId, lastToken, deviceId, lastSyncedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_state';
  @override
  VerificationContext validateIntegrity(Insertable<SyncStateData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('last_token')) {
      context.handle(_lastTokenMeta,
          lastToken.isAcceptableOrUnknown(data['last_token']!, _lastTokenMeta));
    }
    if (data.containsKey('device_id')) {
      context.handle(_deviceIdMeta,
          deviceId.isAcceptableOrUnknown(data['device_id']!, _deviceIdMeta));
    }
    if (data.containsKey('last_synced_at')) {
      context.handle(
          _lastSyncedAtMeta,
          lastSyncedAt.isAcceptableOrUnknown(
              data['last_synced_at']!, _lastSyncedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {salonId};
  @override
  SyncStateData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncStateData(
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      lastToken: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}last_token'])!,
      deviceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}device_id']),
      lastSyncedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}last_synced_at']),
    );
  }

  @override
  $SyncStateTable createAlias(String alias) {
    return $SyncStateTable(attachedDatabase, alias);
  }
}

class SyncStateData extends DataClass implements Insertable<SyncStateData> {
  final String salonId;
  final int lastToken;
  final String? deviceId;
  final DateTime? lastSyncedAt;
  const SyncStateData(
      {required this.salonId,
      required this.lastToken,
      this.deviceId,
      this.lastSyncedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['salon_id'] = Variable<String>(salonId);
    map['last_token'] = Variable<int>(lastToken);
    if (!nullToAbsent || deviceId != null) {
      map['device_id'] = Variable<String>(deviceId);
    }
    if (!nullToAbsent || lastSyncedAt != null) {
      map['last_synced_at'] = Variable<DateTime>(lastSyncedAt);
    }
    return map;
  }

  SyncStateCompanion toCompanion(bool nullToAbsent) {
    return SyncStateCompanion(
      salonId: Value(salonId),
      lastToken: Value(lastToken),
      deviceId: deviceId == null && nullToAbsent
          ? const Value.absent()
          : Value(deviceId),
      lastSyncedAt: lastSyncedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(lastSyncedAt),
    );
  }

  factory SyncStateData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncStateData(
      salonId: serializer.fromJson<String>(json['salonId']),
      lastToken: serializer.fromJson<int>(json['lastToken']),
      deviceId: serializer.fromJson<String?>(json['deviceId']),
      lastSyncedAt: serializer.fromJson<DateTime?>(json['lastSyncedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'salonId': serializer.toJson<String>(salonId),
      'lastToken': serializer.toJson<int>(lastToken),
      'deviceId': serializer.toJson<String?>(deviceId),
      'lastSyncedAt': serializer.toJson<DateTime?>(lastSyncedAt),
    };
  }

  SyncStateData copyWith(
          {String? salonId,
          int? lastToken,
          Value<String?> deviceId = const Value.absent(),
          Value<DateTime?> lastSyncedAt = const Value.absent()}) =>
      SyncStateData(
        salonId: salonId ?? this.salonId,
        lastToken: lastToken ?? this.lastToken,
        deviceId: deviceId.present ? deviceId.value : this.deviceId,
        lastSyncedAt:
            lastSyncedAt.present ? lastSyncedAt.value : this.lastSyncedAt,
      );
  SyncStateData copyWithCompanion(SyncStateCompanion data) {
    return SyncStateData(
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      lastToken: data.lastToken.present ? data.lastToken.value : this.lastToken,
      deviceId: data.deviceId.present ? data.deviceId.value : this.deviceId,
      lastSyncedAt: data.lastSyncedAt.present
          ? data.lastSyncedAt.value
          : this.lastSyncedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncStateData(')
          ..write('salonId: $salonId, ')
          ..write('lastToken: $lastToken, ')
          ..write('deviceId: $deviceId, ')
          ..write('lastSyncedAt: $lastSyncedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(salonId, lastToken, deviceId, lastSyncedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncStateData &&
          other.salonId == this.salonId &&
          other.lastToken == this.lastToken &&
          other.deviceId == this.deviceId &&
          other.lastSyncedAt == this.lastSyncedAt);
}

class SyncStateCompanion extends UpdateCompanion<SyncStateData> {
  final Value<String> salonId;
  final Value<int> lastToken;
  final Value<String?> deviceId;
  final Value<DateTime?> lastSyncedAt;
  final Value<int> rowid;
  const SyncStateCompanion({
    this.salonId = const Value.absent(),
    this.lastToken = const Value.absent(),
    this.deviceId = const Value.absent(),
    this.lastSyncedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncStateCompanion.insert({
    required String salonId,
    this.lastToken = const Value.absent(),
    this.deviceId = const Value.absent(),
    this.lastSyncedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : salonId = Value(salonId);
  static Insertable<SyncStateData> custom({
    Expression<String>? salonId,
    Expression<int>? lastToken,
    Expression<String>? deviceId,
    Expression<DateTime>? lastSyncedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (salonId != null) 'salon_id': salonId,
      if (lastToken != null) 'last_token': lastToken,
      if (deviceId != null) 'device_id': deviceId,
      if (lastSyncedAt != null) 'last_synced_at': lastSyncedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncStateCompanion copyWith(
      {Value<String>? salonId,
      Value<int>? lastToken,
      Value<String?>? deviceId,
      Value<DateTime?>? lastSyncedAt,
      Value<int>? rowid}) {
    return SyncStateCompanion(
      salonId: salonId ?? this.salonId,
      lastToken: lastToken ?? this.lastToken,
      deviceId: deviceId ?? this.deviceId,
      lastSyncedAt: lastSyncedAt ?? this.lastSyncedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (lastToken.present) {
      map['last_token'] = Variable<int>(lastToken.value);
    }
    if (deviceId.present) {
      map['device_id'] = Variable<String>(deviceId.value);
    }
    if (lastSyncedAt.present) {
      map['last_synced_at'] = Variable<DateTime>(lastSyncedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncStateCompanion(')
          ..write('salonId: $salonId, ')
          ..write('lastToken: $lastToken, ')
          ..write('deviceId: $deviceId, ')
          ..write('lastSyncedAt: $lastSyncedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SalonSettingsTable extends SalonSettings
    with TableInfo<$SalonSettingsTable, SalonSetting> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SalonSettingsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dayStartMinuteMeta =
      const VerificationMeta('dayStartMinute');
  @override
  late final GeneratedColumn<int> dayStartMinute = GeneratedColumn<int>(
      'day_start_minute', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _dayEndMinuteMeta =
      const VerificationMeta('dayEndMinute');
  @override
  late final GeneratedColumn<int> dayEndMinute = GeneratedColumn<int>(
      'day_end_minute', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _slotMinutesMeta =
      const VerificationMeta('slotMinutes');
  @override
  late final GeneratedColumn<int> slotMinutes = GeneratedColumn<int>(
      'slot_minutes', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [salonId, dayStartMinute, dayEndMinute, slotMinutes];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'salon_settings';
  @override
  VerificationContext validateIntegrity(Insertable<SalonSetting> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('day_start_minute')) {
      context.handle(
          _dayStartMinuteMeta,
          dayStartMinute.isAcceptableOrUnknown(
              data['day_start_minute']!, _dayStartMinuteMeta));
    } else if (isInserting) {
      context.missing(_dayStartMinuteMeta);
    }
    if (data.containsKey('day_end_minute')) {
      context.handle(
          _dayEndMinuteMeta,
          dayEndMinute.isAcceptableOrUnknown(
              data['day_end_minute']!, _dayEndMinuteMeta));
    } else if (isInserting) {
      context.missing(_dayEndMinuteMeta);
    }
    if (data.containsKey('slot_minutes')) {
      context.handle(
          _slotMinutesMeta,
          slotMinutes.isAcceptableOrUnknown(
              data['slot_minutes']!, _slotMinutesMeta));
    } else if (isInserting) {
      context.missing(_slotMinutesMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {salonId};
  @override
  SalonSetting map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SalonSetting(
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      dayStartMinute: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}day_start_minute'])!,
      dayEndMinute: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}day_end_minute'])!,
      slotMinutes: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}slot_minutes'])!,
    );
  }

  @override
  $SalonSettingsTable createAlias(String alias) {
    return $SalonSettingsTable(attachedDatabase, alias);
  }
}

class SalonSetting extends DataClass implements Insertable<SalonSetting> {
  final String salonId;
  final int dayStartMinute;
  final int dayEndMinute;
  final int slotMinutes;
  const SalonSetting(
      {required this.salonId,
      required this.dayStartMinute,
      required this.dayEndMinute,
      required this.slotMinutes});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['salon_id'] = Variable<String>(salonId);
    map['day_start_minute'] = Variable<int>(dayStartMinute);
    map['day_end_minute'] = Variable<int>(dayEndMinute);
    map['slot_minutes'] = Variable<int>(slotMinutes);
    return map;
  }

  SalonSettingsCompanion toCompanion(bool nullToAbsent) {
    return SalonSettingsCompanion(
      salonId: Value(salonId),
      dayStartMinute: Value(dayStartMinute),
      dayEndMinute: Value(dayEndMinute),
      slotMinutes: Value(slotMinutes),
    );
  }

  factory SalonSetting.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SalonSetting(
      salonId: serializer.fromJson<String>(json['salonId']),
      dayStartMinute: serializer.fromJson<int>(json['dayStartMinute']),
      dayEndMinute: serializer.fromJson<int>(json['dayEndMinute']),
      slotMinutes: serializer.fromJson<int>(json['slotMinutes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'salonId': serializer.toJson<String>(salonId),
      'dayStartMinute': serializer.toJson<int>(dayStartMinute),
      'dayEndMinute': serializer.toJson<int>(dayEndMinute),
      'slotMinutes': serializer.toJson<int>(slotMinutes),
    };
  }

  SalonSetting copyWith(
          {String? salonId,
          int? dayStartMinute,
          int? dayEndMinute,
          int? slotMinutes}) =>
      SalonSetting(
        salonId: salonId ?? this.salonId,
        dayStartMinute: dayStartMinute ?? this.dayStartMinute,
        dayEndMinute: dayEndMinute ?? this.dayEndMinute,
        slotMinutes: slotMinutes ?? this.slotMinutes,
      );
  SalonSetting copyWithCompanion(SalonSettingsCompanion data) {
    return SalonSetting(
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      dayStartMinute: data.dayStartMinute.present
          ? data.dayStartMinute.value
          : this.dayStartMinute,
      dayEndMinute: data.dayEndMinute.present
          ? data.dayEndMinute.value
          : this.dayEndMinute,
      slotMinutes:
          data.slotMinutes.present ? data.slotMinutes.value : this.slotMinutes,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SalonSetting(')
          ..write('salonId: $salonId, ')
          ..write('dayStartMinute: $dayStartMinute, ')
          ..write('dayEndMinute: $dayEndMinute, ')
          ..write('slotMinutes: $slotMinutes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(salonId, dayStartMinute, dayEndMinute, slotMinutes);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SalonSetting &&
          other.salonId == this.salonId &&
          other.dayStartMinute == this.dayStartMinute &&
          other.dayEndMinute == this.dayEndMinute &&
          other.slotMinutes == this.slotMinutes);
}

class SalonSettingsCompanion extends UpdateCompanion<SalonSetting> {
  final Value<String> salonId;
  final Value<int> dayStartMinute;
  final Value<int> dayEndMinute;
  final Value<int> slotMinutes;
  final Value<int> rowid;
  const SalonSettingsCompanion({
    this.salonId = const Value.absent(),
    this.dayStartMinute = const Value.absent(),
    this.dayEndMinute = const Value.absent(),
    this.slotMinutes = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SalonSettingsCompanion.insert({
    required String salonId,
    required int dayStartMinute,
    required int dayEndMinute,
    required int slotMinutes,
    this.rowid = const Value.absent(),
  })  : salonId = Value(salonId),
        dayStartMinute = Value(dayStartMinute),
        dayEndMinute = Value(dayEndMinute),
        slotMinutes = Value(slotMinutes);
  static Insertable<SalonSetting> custom({
    Expression<String>? salonId,
    Expression<int>? dayStartMinute,
    Expression<int>? dayEndMinute,
    Expression<int>? slotMinutes,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (salonId != null) 'salon_id': salonId,
      if (dayStartMinute != null) 'day_start_minute': dayStartMinute,
      if (dayEndMinute != null) 'day_end_minute': dayEndMinute,
      if (slotMinutes != null) 'slot_minutes': slotMinutes,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SalonSettingsCompanion copyWith(
      {Value<String>? salonId,
      Value<int>? dayStartMinute,
      Value<int>? dayEndMinute,
      Value<int>? slotMinutes,
      Value<int>? rowid}) {
    return SalonSettingsCompanion(
      salonId: salonId ?? this.salonId,
      dayStartMinute: dayStartMinute ?? this.dayStartMinute,
      dayEndMinute: dayEndMinute ?? this.dayEndMinute,
      slotMinutes: slotMinutes ?? this.slotMinutes,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (dayStartMinute.present) {
      map['day_start_minute'] = Variable<int>(dayStartMinute.value);
    }
    if (dayEndMinute.present) {
      map['day_end_minute'] = Variable<int>(dayEndMinute.value);
    }
    if (slotMinutes.present) {
      map['slot_minutes'] = Variable<int>(slotMinutes.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SalonSettingsCompanion(')
          ..write('salonId: $salonId, ')
          ..write('dayStartMinute: $dayStartMinute, ')
          ..write('dayEndMinute: $dayEndMinute, ')
          ..write('slotMinutes: $slotMinutes, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SalonWorkHoursTable extends SalonWorkHours
    with TableInfo<$SalonWorkHoursTable, SalonWorkHour> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SalonWorkHoursTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _weekdayMeta =
      const VerificationMeta('weekday');
  @override
  late final GeneratedColumn<int> weekday = GeneratedColumn<int>(
      'weekday', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _startMinuteMeta =
      const VerificationMeta('startMinute');
  @override
  late final GeneratedColumn<int> startMinute = GeneratedColumn<int>(
      'start_minute', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _endMinuteMeta =
      const VerificationMeta('endMinute');
  @override
  late final GeneratedColumn<int> endMinute = GeneratedColumn<int>(
      'end_minute', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, salonId, weekday, startMinute, endMinute];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'salon_work_hours';
  @override
  VerificationContext validateIntegrity(Insertable<SalonWorkHour> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('weekday')) {
      context.handle(_weekdayMeta,
          weekday.isAcceptableOrUnknown(data['weekday']!, _weekdayMeta));
    } else if (isInserting) {
      context.missing(_weekdayMeta);
    }
    if (data.containsKey('start_minute')) {
      context.handle(
          _startMinuteMeta,
          startMinute.isAcceptableOrUnknown(
              data['start_minute']!, _startMinuteMeta));
    } else if (isInserting) {
      context.missing(_startMinuteMeta);
    }
    if (data.containsKey('end_minute')) {
      context.handle(_endMinuteMeta,
          endMinute.isAcceptableOrUnknown(data['end_minute']!, _endMinuteMeta));
    } else if (isInserting) {
      context.missing(_endMinuteMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {salonId, weekday},
      ];
  @override
  SalonWorkHour map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SalonWorkHour(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      weekday: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}weekday'])!,
      startMinute: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}start_minute'])!,
      endMinute: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}end_minute'])!,
    );
  }

  @override
  $SalonWorkHoursTable createAlias(String alias) {
    return $SalonWorkHoursTable(attachedDatabase, alias);
  }
}

class SalonWorkHour extends DataClass implements Insertable<SalonWorkHour> {
  final String id;
  final String salonId;
  final int weekday;
  final int startMinute;
  final int endMinute;
  const SalonWorkHour(
      {required this.id,
      required this.salonId,
      required this.weekday,
      required this.startMinute,
      required this.endMinute});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['weekday'] = Variable<int>(weekday);
    map['start_minute'] = Variable<int>(startMinute);
    map['end_minute'] = Variable<int>(endMinute);
    return map;
  }

  SalonWorkHoursCompanion toCompanion(bool nullToAbsent) {
    return SalonWorkHoursCompanion(
      id: Value(id),
      salonId: Value(salonId),
      weekday: Value(weekday),
      startMinute: Value(startMinute),
      endMinute: Value(endMinute),
    );
  }

  factory SalonWorkHour.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SalonWorkHour(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      weekday: serializer.fromJson<int>(json['weekday']),
      startMinute: serializer.fromJson<int>(json['startMinute']),
      endMinute: serializer.fromJson<int>(json['endMinute']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'weekday': serializer.toJson<int>(weekday),
      'startMinute': serializer.toJson<int>(startMinute),
      'endMinute': serializer.toJson<int>(endMinute),
    };
  }

  SalonWorkHour copyWith(
          {String? id,
          String? salonId,
          int? weekday,
          int? startMinute,
          int? endMinute}) =>
      SalonWorkHour(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        weekday: weekday ?? this.weekday,
        startMinute: startMinute ?? this.startMinute,
        endMinute: endMinute ?? this.endMinute,
      );
  SalonWorkHour copyWithCompanion(SalonWorkHoursCompanion data) {
    return SalonWorkHour(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      weekday: data.weekday.present ? data.weekday.value : this.weekday,
      startMinute:
          data.startMinute.present ? data.startMinute.value : this.startMinute,
      endMinute: data.endMinute.present ? data.endMinute.value : this.endMinute,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SalonWorkHour(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('weekday: $weekday, ')
          ..write('startMinute: $startMinute, ')
          ..write('endMinute: $endMinute')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, salonId, weekday, startMinute, endMinute);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SalonWorkHour &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.weekday == this.weekday &&
          other.startMinute == this.startMinute &&
          other.endMinute == this.endMinute);
}

class SalonWorkHoursCompanion extends UpdateCompanion<SalonWorkHour> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<int> weekday;
  final Value<int> startMinute;
  final Value<int> endMinute;
  final Value<int> rowid;
  const SalonWorkHoursCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.weekday = const Value.absent(),
    this.startMinute = const Value.absent(),
    this.endMinute = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SalonWorkHoursCompanion.insert({
    required String id,
    required String salonId,
    required int weekday,
    required int startMinute,
    required int endMinute,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        weekday = Value(weekday),
        startMinute = Value(startMinute),
        endMinute = Value(endMinute);
  static Insertable<SalonWorkHour> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<int>? weekday,
    Expression<int>? startMinute,
    Expression<int>? endMinute,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (weekday != null) 'weekday': weekday,
      if (startMinute != null) 'start_minute': startMinute,
      if (endMinute != null) 'end_minute': endMinute,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SalonWorkHoursCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<int>? weekday,
      Value<int>? startMinute,
      Value<int>? endMinute,
      Value<int>? rowid}) {
    return SalonWorkHoursCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      weekday: weekday ?? this.weekday,
      startMinute: startMinute ?? this.startMinute,
      endMinute: endMinute ?? this.endMinute,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (weekday.present) {
      map['weekday'] = Variable<int>(weekday.value);
    }
    if (startMinute.present) {
      map['start_minute'] = Variable<int>(startMinute.value);
    }
    if (endMinute.present) {
      map['end_minute'] = Variable<int>(endMinute.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SalonWorkHoursCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('weekday: $weekday, ')
          ..write('startMinute: $startMinute, ')
          ..write('endMinute: $endMinute, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $StaffColumnsTable extends StaffColumns
    with TableInfo<$StaffColumnsTable, StaffColumn> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $StaffColumnsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _displayNameMeta =
      const VerificationMeta('displayName');
  @override
  late final GeneratedColumn<String> displayName = GeneratedColumn<String>(
      'display_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _professionMeta =
      const VerificationMeta('profession');
  @override
  late final GeneratedColumn<String> profession = GeneratedColumn<String>(
      'profession', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _orderIndexMeta =
      const VerificationMeta('orderIndex');
  @override
  late final GeneratedColumn<int> orderIndex = GeneratedColumn<int>(
      'order_index', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _activeFromMeta =
      const VerificationMeta('activeFrom');
  @override
  late final GeneratedColumn<DateTime> activeFrom = GeneratedColumn<DateTime>(
      'active_from', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _activeToMeta =
      const VerificationMeta('activeTo');
  @override
  late final GeneratedColumn<DateTime> activeTo = GeneratedColumn<DateTime>(
      'active_to', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        salonId,
        userId,
        displayName,
        profession,
        orderIndex,
        activeFrom,
        activeTo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'staff_columns';
  @override
  VerificationContext validateIntegrity(Insertable<StaffColumn> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('display_name')) {
      context.handle(
          _displayNameMeta,
          displayName.isAcceptableOrUnknown(
              data['display_name']!, _displayNameMeta));
    } else if (isInserting) {
      context.missing(_displayNameMeta);
    }
    if (data.containsKey('profession')) {
      context.handle(
          _professionMeta,
          profession.isAcceptableOrUnknown(
              data['profession']!, _professionMeta));
    } else if (isInserting) {
      context.missing(_professionMeta);
    }
    if (data.containsKey('order_index')) {
      context.handle(
          _orderIndexMeta,
          orderIndex.isAcceptableOrUnknown(
              data['order_index']!, _orderIndexMeta));
    }
    if (data.containsKey('active_from')) {
      context.handle(
          _activeFromMeta,
          activeFrom.isAcceptableOrUnknown(
              data['active_from']!, _activeFromMeta));
    } else if (isInserting) {
      context.missing(_activeFromMeta);
    }
    if (data.containsKey('active_to')) {
      context.handle(_activeToMeta,
          activeTo.isAcceptableOrUnknown(data['active_to']!, _activeToMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  StaffColumn map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return StaffColumn(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      displayName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}display_name'])!,
      profession: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}profession'])!,
      orderIndex: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}order_index'])!,
      activeFrom: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}active_from'])!,
      activeTo: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}active_to']),
    );
  }

  @override
  $StaffColumnsTable createAlias(String alias) {
    return $StaffColumnsTable(attachedDatabase, alias);
  }
}

class StaffColumn extends DataClass implements Insertable<StaffColumn> {
  final String id;
  final String salonId;
  final String userId;
  final String displayName;
  final String profession;
  final int orderIndex;
  final DateTime activeFrom;
  final DateTime? activeTo;
  const StaffColumn(
      {required this.id,
      required this.salonId,
      required this.userId,
      required this.displayName,
      required this.profession,
      required this.orderIndex,
      required this.activeFrom,
      this.activeTo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['user_id'] = Variable<String>(userId);
    map['display_name'] = Variable<String>(displayName);
    map['profession'] = Variable<String>(profession);
    map['order_index'] = Variable<int>(orderIndex);
    map['active_from'] = Variable<DateTime>(activeFrom);
    if (!nullToAbsent || activeTo != null) {
      map['active_to'] = Variable<DateTime>(activeTo);
    }
    return map;
  }

  StaffColumnsCompanion toCompanion(bool nullToAbsent) {
    return StaffColumnsCompanion(
      id: Value(id),
      salonId: Value(salonId),
      userId: Value(userId),
      displayName: Value(displayName),
      profession: Value(profession),
      orderIndex: Value(orderIndex),
      activeFrom: Value(activeFrom),
      activeTo: activeTo == null && nullToAbsent
          ? const Value.absent()
          : Value(activeTo),
    );
  }

  factory StaffColumn.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return StaffColumn(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      userId: serializer.fromJson<String>(json['userId']),
      displayName: serializer.fromJson<String>(json['displayName']),
      profession: serializer.fromJson<String>(json['profession']),
      orderIndex: serializer.fromJson<int>(json['orderIndex']),
      activeFrom: serializer.fromJson<DateTime>(json['activeFrom']),
      activeTo: serializer.fromJson<DateTime?>(json['activeTo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'userId': serializer.toJson<String>(userId),
      'displayName': serializer.toJson<String>(displayName),
      'profession': serializer.toJson<String>(profession),
      'orderIndex': serializer.toJson<int>(orderIndex),
      'activeFrom': serializer.toJson<DateTime>(activeFrom),
      'activeTo': serializer.toJson<DateTime?>(activeTo),
    };
  }

  StaffColumn copyWith(
          {String? id,
          String? salonId,
          String? userId,
          String? displayName,
          String? profession,
          int? orderIndex,
          DateTime? activeFrom,
          Value<DateTime?> activeTo = const Value.absent()}) =>
      StaffColumn(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        userId: userId ?? this.userId,
        displayName: displayName ?? this.displayName,
        profession: profession ?? this.profession,
        orderIndex: orderIndex ?? this.orderIndex,
        activeFrom: activeFrom ?? this.activeFrom,
        activeTo: activeTo.present ? activeTo.value : this.activeTo,
      );
  StaffColumn copyWithCompanion(StaffColumnsCompanion data) {
    return StaffColumn(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      userId: data.userId.present ? data.userId.value : this.userId,
      displayName:
          data.displayName.present ? data.displayName.value : this.displayName,
      profession:
          data.profession.present ? data.profession.value : this.profession,
      orderIndex:
          data.orderIndex.present ? data.orderIndex.value : this.orderIndex,
      activeFrom:
          data.activeFrom.present ? data.activeFrom.value : this.activeFrom,
      activeTo: data.activeTo.present ? data.activeTo.value : this.activeTo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('StaffColumn(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('userId: $userId, ')
          ..write('displayName: $displayName, ')
          ..write('profession: $profession, ')
          ..write('orderIndex: $orderIndex, ')
          ..write('activeFrom: $activeFrom, ')
          ..write('activeTo: $activeTo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, salonId, userId, displayName, profession,
      orderIndex, activeFrom, activeTo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is StaffColumn &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.userId == this.userId &&
          other.displayName == this.displayName &&
          other.profession == this.profession &&
          other.orderIndex == this.orderIndex &&
          other.activeFrom == this.activeFrom &&
          other.activeTo == this.activeTo);
}

class StaffColumnsCompanion extends UpdateCompanion<StaffColumn> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<String> userId;
  final Value<String> displayName;
  final Value<String> profession;
  final Value<int> orderIndex;
  final Value<DateTime> activeFrom;
  final Value<DateTime?> activeTo;
  final Value<int> rowid;
  const StaffColumnsCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.userId = const Value.absent(),
    this.displayName = const Value.absent(),
    this.profession = const Value.absent(),
    this.orderIndex = const Value.absent(),
    this.activeFrom = const Value.absent(),
    this.activeTo = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  StaffColumnsCompanion.insert({
    required String id,
    required String salonId,
    required String userId,
    required String displayName,
    required String profession,
    this.orderIndex = const Value.absent(),
    required DateTime activeFrom,
    this.activeTo = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        userId = Value(userId),
        displayName = Value(displayName),
        profession = Value(profession),
        activeFrom = Value(activeFrom);
  static Insertable<StaffColumn> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<String>? userId,
    Expression<String>? displayName,
    Expression<String>? profession,
    Expression<int>? orderIndex,
    Expression<DateTime>? activeFrom,
    Expression<DateTime>? activeTo,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (userId != null) 'user_id': userId,
      if (displayName != null) 'display_name': displayName,
      if (profession != null) 'profession': profession,
      if (orderIndex != null) 'order_index': orderIndex,
      if (activeFrom != null) 'active_from': activeFrom,
      if (activeTo != null) 'active_to': activeTo,
      if (rowid != null) 'rowid': rowid,
    });
  }

  StaffColumnsCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<String>? userId,
      Value<String>? displayName,
      Value<String>? profession,
      Value<int>? orderIndex,
      Value<DateTime>? activeFrom,
      Value<DateTime?>? activeTo,
      Value<int>? rowid}) {
    return StaffColumnsCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      userId: userId ?? this.userId,
      displayName: displayName ?? this.displayName,
      profession: profession ?? this.profession,
      orderIndex: orderIndex ?? this.orderIndex,
      activeFrom: activeFrom ?? this.activeFrom,
      activeTo: activeTo ?? this.activeTo,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (displayName.present) {
      map['display_name'] = Variable<String>(displayName.value);
    }
    if (profession.present) {
      map['profession'] = Variable<String>(profession.value);
    }
    if (orderIndex.present) {
      map['order_index'] = Variable<int>(orderIndex.value);
    }
    if (activeFrom.present) {
      map['active_from'] = Variable<DateTime>(activeFrom.value);
    }
    if (activeTo.present) {
      map['active_to'] = Variable<DateTime>(activeTo.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('StaffColumnsCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('userId: $userId, ')
          ..write('displayName: $displayName, ')
          ..write('profession: $profession, ')
          ..write('orderIndex: $orderIndex, ')
          ..write('activeFrom: $activeFrom, ')
          ..write('activeTo: $activeTo, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $WorkDaysTable extends WorkDays with TableInfo<$WorkDaysTable, WorkDay> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WorkDaysTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dateMeta = const VerificationMeta('date');
  @override
  late final GeneratedColumn<DateTime> date = GeneratedColumn<DateTime>(
      'date', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _currencyCodeMeta =
      const VerificationMeta('currencyCode');
  @override
  late final GeneratedColumn<String> currencyCode = GeneratedColumn<String>(
      'currency_code', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('EUR'));
  @override
  List<GeneratedColumn> get $columns => [id, salonId, date, currencyCode];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'work_days';
  @override
  VerificationContext validateIntegrity(Insertable<WorkDay> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('date')) {
      context.handle(
          _dateMeta, date.isAcceptableOrUnknown(data['date']!, _dateMeta));
    } else if (isInserting) {
      context.missing(_dateMeta);
    }
    if (data.containsKey('currency_code')) {
      context.handle(
          _currencyCodeMeta,
          currencyCode.isAcceptableOrUnknown(
              data['currency_code']!, _currencyCodeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WorkDay map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WorkDay(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      date: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}date'])!,
      currencyCode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}currency_code'])!,
    );
  }

  @override
  $WorkDaysTable createAlias(String alias) {
    return $WorkDaysTable(attachedDatabase, alias);
  }
}

class WorkDay extends DataClass implements Insertable<WorkDay> {
  final String id;
  final String salonId;
  final DateTime date;
  final String currencyCode;
  const WorkDay(
      {required this.id,
      required this.salonId,
      required this.date,
      required this.currencyCode});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['date'] = Variable<DateTime>(date);
    map['currency_code'] = Variable<String>(currencyCode);
    return map;
  }

  WorkDaysCompanion toCompanion(bool nullToAbsent) {
    return WorkDaysCompanion(
      id: Value(id),
      salonId: Value(salonId),
      date: Value(date),
      currencyCode: Value(currencyCode),
    );
  }

  factory WorkDay.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WorkDay(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      date: serializer.fromJson<DateTime>(json['date']),
      currencyCode: serializer.fromJson<String>(json['currencyCode']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'date': serializer.toJson<DateTime>(date),
      'currencyCode': serializer.toJson<String>(currencyCode),
    };
  }

  WorkDay copyWith(
          {String? id,
          String? salonId,
          DateTime? date,
          String? currencyCode}) =>
      WorkDay(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        date: date ?? this.date,
        currencyCode: currencyCode ?? this.currencyCode,
      );
  WorkDay copyWithCompanion(WorkDaysCompanion data) {
    return WorkDay(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      date: data.date.present ? data.date.value : this.date,
      currencyCode: data.currencyCode.present
          ? data.currencyCode.value
          : this.currencyCode,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WorkDay(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('date: $date, ')
          ..write('currencyCode: $currencyCode')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, salonId, date, currencyCode);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WorkDay &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.date == this.date &&
          other.currencyCode == this.currencyCode);
}

class WorkDaysCompanion extends UpdateCompanion<WorkDay> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<DateTime> date;
  final Value<String> currencyCode;
  final Value<int> rowid;
  const WorkDaysCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.date = const Value.absent(),
    this.currencyCode = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  WorkDaysCompanion.insert({
    required String id,
    required String salonId,
    required DateTime date,
    this.currencyCode = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        date = Value(date);
  static Insertable<WorkDay> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<DateTime>? date,
    Expression<String>? currencyCode,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (date != null) 'date': date,
      if (currencyCode != null) 'currency_code': currencyCode,
      if (rowid != null) 'rowid': rowid,
    });
  }

  WorkDaysCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<DateTime>? date,
      Value<String>? currencyCode,
      Value<int>? rowid}) {
    return WorkDaysCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      date: date ?? this.date,
      currencyCode: currencyCode ?? this.currencyCode,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (date.present) {
      map['date'] = Variable<DateTime>(date.value);
    }
    if (currencyCode.present) {
      map['currency_code'] = Variable<String>(currencyCode.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WorkDaysCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('date: $date, ')
          ..write('currencyCode: $currencyCode, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $TimeSlotEntriesTable extends TimeSlotEntries
    with TableInfo<$TimeSlotEntriesTable, TimeSlotEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TimeSlotEntriesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _workDayIdMeta =
      const VerificationMeta('workDayId');
  @override
  late final GeneratedColumn<String> workDayId = GeneratedColumn<String>(
      'work_day_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _staffColumnIdMeta =
      const VerificationMeta('staffColumnId');
  @override
  late final GeneratedColumn<String> staffColumnId = GeneratedColumn<String>(
      'staff_column_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _slotMinuteMeta =
      const VerificationMeta('slotMinute');
  @override
  late final GeneratedColumn<int> slotMinute = GeneratedColumn<int>(
      'slot_minute', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _lockedMeta = const VerificationMeta('locked');
  @override
  late final GeneratedColumn<bool> locked = GeneratedColumn<bool>(
      'locked', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("locked" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _confirmedAtMeta =
      const VerificationMeta('confirmedAt');
  @override
  late final GeneratedColumn<DateTime> confirmedAt = GeneratedColumn<DateTime>(
      'confirmed_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _confirmedByUserIdMeta =
      const VerificationMeta('confirmedByUserId');
  @override
  late final GeneratedColumn<String> confirmedByUserId =
      GeneratedColumn<String>('confirmed_by_user_id', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        salonId,
        workDayId,
        staffColumnId,
        slotMinute,
        locked,
        confirmedAt,
        confirmedByUserId,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'time_slot_entries';
  @override
  VerificationContext validateIntegrity(Insertable<TimeSlotEntry> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('work_day_id')) {
      context.handle(
          _workDayIdMeta,
          workDayId.isAcceptableOrUnknown(
              data['work_day_id']!, _workDayIdMeta));
    } else if (isInserting) {
      context.missing(_workDayIdMeta);
    }
    if (data.containsKey('staff_column_id')) {
      context.handle(
          _staffColumnIdMeta,
          staffColumnId.isAcceptableOrUnknown(
              data['staff_column_id']!, _staffColumnIdMeta));
    } else if (isInserting) {
      context.missing(_staffColumnIdMeta);
    }
    if (data.containsKey('slot_minute')) {
      context.handle(
          _slotMinuteMeta,
          slotMinute.isAcceptableOrUnknown(
              data['slot_minute']!, _slotMinuteMeta));
    } else if (isInserting) {
      context.missing(_slotMinuteMeta);
    }
    if (data.containsKey('locked')) {
      context.handle(_lockedMeta,
          locked.isAcceptableOrUnknown(data['locked']!, _lockedMeta));
    }
    if (data.containsKey('confirmed_at')) {
      context.handle(
          _confirmedAtMeta,
          confirmedAt.isAcceptableOrUnknown(
              data['confirmed_at']!, _confirmedAtMeta));
    }
    if (data.containsKey('confirmed_by_user_id')) {
      context.handle(
          _confirmedByUserIdMeta,
          confirmedByUserId.isAcceptableOrUnknown(
              data['confirmed_by_user_id']!, _confirmedByUserIdMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TimeSlotEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TimeSlotEntry(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      workDayId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}work_day_id'])!,
      staffColumnId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}staff_column_id'])!,
      slotMinute: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}slot_minute'])!,
      locked: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}locked'])!,
      confirmedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}confirmed_at']),
      confirmedByUserId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}confirmed_by_user_id']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $TimeSlotEntriesTable createAlias(String alias) {
    return $TimeSlotEntriesTable(attachedDatabase, alias);
  }
}

class TimeSlotEntry extends DataClass implements Insertable<TimeSlotEntry> {
  final String id;
  final String salonId;
  final String workDayId;
  final String staffColumnId;
  final int slotMinute;
  final bool locked;
  final DateTime? confirmedAt;
  final String? confirmedByUserId;
  final DateTime createdAt;
  final DateTime updatedAt;
  const TimeSlotEntry(
      {required this.id,
      required this.salonId,
      required this.workDayId,
      required this.staffColumnId,
      required this.slotMinute,
      required this.locked,
      this.confirmedAt,
      this.confirmedByUserId,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['work_day_id'] = Variable<String>(workDayId);
    map['staff_column_id'] = Variable<String>(staffColumnId);
    map['slot_minute'] = Variable<int>(slotMinute);
    map['locked'] = Variable<bool>(locked);
    if (!nullToAbsent || confirmedAt != null) {
      map['confirmed_at'] = Variable<DateTime>(confirmedAt);
    }
    if (!nullToAbsent || confirmedByUserId != null) {
      map['confirmed_by_user_id'] = Variable<String>(confirmedByUserId);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  TimeSlotEntriesCompanion toCompanion(bool nullToAbsent) {
    return TimeSlotEntriesCompanion(
      id: Value(id),
      salonId: Value(salonId),
      workDayId: Value(workDayId),
      staffColumnId: Value(staffColumnId),
      slotMinute: Value(slotMinute),
      locked: Value(locked),
      confirmedAt: confirmedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(confirmedAt),
      confirmedByUserId: confirmedByUserId == null && nullToAbsent
          ? const Value.absent()
          : Value(confirmedByUserId),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory TimeSlotEntry.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TimeSlotEntry(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      workDayId: serializer.fromJson<String>(json['workDayId']),
      staffColumnId: serializer.fromJson<String>(json['staffColumnId']),
      slotMinute: serializer.fromJson<int>(json['slotMinute']),
      locked: serializer.fromJson<bool>(json['locked']),
      confirmedAt: serializer.fromJson<DateTime?>(json['confirmedAt']),
      confirmedByUserId:
          serializer.fromJson<String?>(json['confirmedByUserId']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'workDayId': serializer.toJson<String>(workDayId),
      'staffColumnId': serializer.toJson<String>(staffColumnId),
      'slotMinute': serializer.toJson<int>(slotMinute),
      'locked': serializer.toJson<bool>(locked),
      'confirmedAt': serializer.toJson<DateTime?>(confirmedAt),
      'confirmedByUserId': serializer.toJson<String?>(confirmedByUserId),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  TimeSlotEntry copyWith(
          {String? id,
          String? salonId,
          String? workDayId,
          String? staffColumnId,
          int? slotMinute,
          bool? locked,
          Value<DateTime?> confirmedAt = const Value.absent(),
          Value<String?> confirmedByUserId = const Value.absent(),
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      TimeSlotEntry(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        workDayId: workDayId ?? this.workDayId,
        staffColumnId: staffColumnId ?? this.staffColumnId,
        slotMinute: slotMinute ?? this.slotMinute,
        locked: locked ?? this.locked,
        confirmedAt: confirmedAt.present ? confirmedAt.value : this.confirmedAt,
        confirmedByUserId: confirmedByUserId.present
            ? confirmedByUserId.value
            : this.confirmedByUserId,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  TimeSlotEntry copyWithCompanion(TimeSlotEntriesCompanion data) {
    return TimeSlotEntry(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      workDayId: data.workDayId.present ? data.workDayId.value : this.workDayId,
      staffColumnId: data.staffColumnId.present
          ? data.staffColumnId.value
          : this.staffColumnId,
      slotMinute:
          data.slotMinute.present ? data.slotMinute.value : this.slotMinute,
      locked: data.locked.present ? data.locked.value : this.locked,
      confirmedAt:
          data.confirmedAt.present ? data.confirmedAt.value : this.confirmedAt,
      confirmedByUserId: data.confirmedByUserId.present
          ? data.confirmedByUserId.value
          : this.confirmedByUserId,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TimeSlotEntry(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('workDayId: $workDayId, ')
          ..write('staffColumnId: $staffColumnId, ')
          ..write('slotMinute: $slotMinute, ')
          ..write('locked: $locked, ')
          ..write('confirmedAt: $confirmedAt, ')
          ..write('confirmedByUserId: $confirmedByUserId, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, salonId, workDayId, staffColumnId,
      slotMinute, locked, confirmedAt, confirmedByUserId, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TimeSlotEntry &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.workDayId == this.workDayId &&
          other.staffColumnId == this.staffColumnId &&
          other.slotMinute == this.slotMinute &&
          other.locked == this.locked &&
          other.confirmedAt == this.confirmedAt &&
          other.confirmedByUserId == this.confirmedByUserId &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class TimeSlotEntriesCompanion extends UpdateCompanion<TimeSlotEntry> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<String> workDayId;
  final Value<String> staffColumnId;
  final Value<int> slotMinute;
  final Value<bool> locked;
  final Value<DateTime?> confirmedAt;
  final Value<String?> confirmedByUserId;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const TimeSlotEntriesCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.workDayId = const Value.absent(),
    this.staffColumnId = const Value.absent(),
    this.slotMinute = const Value.absent(),
    this.locked = const Value.absent(),
    this.confirmedAt = const Value.absent(),
    this.confirmedByUserId = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  TimeSlotEntriesCompanion.insert({
    required String id,
    required String salonId,
    required String workDayId,
    required String staffColumnId,
    required int slotMinute,
    this.locked = const Value.absent(),
    this.confirmedAt = const Value.absent(),
    this.confirmedByUserId = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        workDayId = Value(workDayId),
        staffColumnId = Value(staffColumnId),
        slotMinute = Value(slotMinute),
        createdAt = Value(createdAt),
        updatedAt = Value(updatedAt);
  static Insertable<TimeSlotEntry> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<String>? workDayId,
    Expression<String>? staffColumnId,
    Expression<int>? slotMinute,
    Expression<bool>? locked,
    Expression<DateTime>? confirmedAt,
    Expression<String>? confirmedByUserId,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (workDayId != null) 'work_day_id': workDayId,
      if (staffColumnId != null) 'staff_column_id': staffColumnId,
      if (slotMinute != null) 'slot_minute': slotMinute,
      if (locked != null) 'locked': locked,
      if (confirmedAt != null) 'confirmed_at': confirmedAt,
      if (confirmedByUserId != null) 'confirmed_by_user_id': confirmedByUserId,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  TimeSlotEntriesCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<String>? workDayId,
      Value<String>? staffColumnId,
      Value<int>? slotMinute,
      Value<bool>? locked,
      Value<DateTime?>? confirmedAt,
      Value<String?>? confirmedByUserId,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return TimeSlotEntriesCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      workDayId: workDayId ?? this.workDayId,
      staffColumnId: staffColumnId ?? this.staffColumnId,
      slotMinute: slotMinute ?? this.slotMinute,
      locked: locked ?? this.locked,
      confirmedAt: confirmedAt ?? this.confirmedAt,
      confirmedByUserId: confirmedByUserId ?? this.confirmedByUserId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (workDayId.present) {
      map['work_day_id'] = Variable<String>(workDayId.value);
    }
    if (staffColumnId.present) {
      map['staff_column_id'] = Variable<String>(staffColumnId.value);
    }
    if (slotMinute.present) {
      map['slot_minute'] = Variable<int>(slotMinute.value);
    }
    if (locked.present) {
      map['locked'] = Variable<bool>(locked.value);
    }
    if (confirmedAt.present) {
      map['confirmed_at'] = Variable<DateTime>(confirmedAt.value);
    }
    if (confirmedByUserId.present) {
      map['confirmed_by_user_id'] = Variable<String>(confirmedByUserId.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TimeSlotEntriesCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('workDayId: $workDayId, ')
          ..write('staffColumnId: $staffColumnId, ')
          ..write('slotMinute: $slotMinute, ')
          ..write('locked: $locked, ')
          ..write('confirmedAt: $confirmedAt, ')
          ..write('confirmedByUserId: $confirmedByUserId, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EntryMoneyTable extends EntryMoney
    with TableInfo<$EntryMoneyTable, EntryMoneyData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EntryMoneyTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _entryIdMeta =
      const VerificationMeta('entryId');
  @override
  late final GeneratedColumn<String> entryId = GeneratedColumn<String>(
      'entry_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _servicesTotalMeta =
      const VerificationMeta('servicesTotal');
  @override
  late final GeneratedColumn<double> servicesTotal = GeneratedColumn<double>(
      'services_total', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0.0));
  static const VerificationMeta _productsTotalMeta =
      const VerificationMeta('productsTotal');
  @override
  late final GeneratedColumn<double> productsTotal = GeneratedColumn<double>(
      'products_total', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0.0));
  static const VerificationMeta _currencyCodeMeta =
      const VerificationMeta('currencyCode');
  @override
  late final GeneratedColumn<String> currencyCode = GeneratedColumn<String>(
      'currency_code', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('EUR'));
  @override
  List<GeneratedColumn> get $columns =>
      [entryId, servicesTotal, productsTotal, currencyCode];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'entry_money';
  @override
  VerificationContext validateIntegrity(Insertable<EntryMoneyData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('entry_id')) {
      context.handle(_entryIdMeta,
          entryId.isAcceptableOrUnknown(data['entry_id']!, _entryIdMeta));
    } else if (isInserting) {
      context.missing(_entryIdMeta);
    }
    if (data.containsKey('services_total')) {
      context.handle(
          _servicesTotalMeta,
          servicesTotal.isAcceptableOrUnknown(
              data['services_total']!, _servicesTotalMeta));
    }
    if (data.containsKey('products_total')) {
      context.handle(
          _productsTotalMeta,
          productsTotal.isAcceptableOrUnknown(
              data['products_total']!, _productsTotalMeta));
    }
    if (data.containsKey('currency_code')) {
      context.handle(
          _currencyCodeMeta,
          currencyCode.isAcceptableOrUnknown(
              data['currency_code']!, _currencyCodeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {entryId};
  @override
  EntryMoneyData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EntryMoneyData(
      entryId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entry_id'])!,
      servicesTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}services_total'])!,
      productsTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}products_total'])!,
      currencyCode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}currency_code'])!,
    );
  }

  @override
  $EntryMoneyTable createAlias(String alias) {
    return $EntryMoneyTable(attachedDatabase, alias);
  }
}

class EntryMoneyData extends DataClass implements Insertable<EntryMoneyData> {
  final String entryId;
  final double servicesTotal;
  final double productsTotal;
  final String currencyCode;
  const EntryMoneyData(
      {required this.entryId,
      required this.servicesTotal,
      required this.productsTotal,
      required this.currencyCode});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['entry_id'] = Variable<String>(entryId);
    map['services_total'] = Variable<double>(servicesTotal);
    map['products_total'] = Variable<double>(productsTotal);
    map['currency_code'] = Variable<String>(currencyCode);
    return map;
  }

  EntryMoneyCompanion toCompanion(bool nullToAbsent) {
    return EntryMoneyCompanion(
      entryId: Value(entryId),
      servicesTotal: Value(servicesTotal),
      productsTotal: Value(productsTotal),
      currencyCode: Value(currencyCode),
    );
  }

  factory EntryMoneyData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EntryMoneyData(
      entryId: serializer.fromJson<String>(json['entryId']),
      servicesTotal: serializer.fromJson<double>(json['servicesTotal']),
      productsTotal: serializer.fromJson<double>(json['productsTotal']),
      currencyCode: serializer.fromJson<String>(json['currencyCode']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'entryId': serializer.toJson<String>(entryId),
      'servicesTotal': serializer.toJson<double>(servicesTotal),
      'productsTotal': serializer.toJson<double>(productsTotal),
      'currencyCode': serializer.toJson<String>(currencyCode),
    };
  }

  EntryMoneyData copyWith(
          {String? entryId,
          double? servicesTotal,
          double? productsTotal,
          String? currencyCode}) =>
      EntryMoneyData(
        entryId: entryId ?? this.entryId,
        servicesTotal: servicesTotal ?? this.servicesTotal,
        productsTotal: productsTotal ?? this.productsTotal,
        currencyCode: currencyCode ?? this.currencyCode,
      );
  EntryMoneyData copyWithCompanion(EntryMoneyCompanion data) {
    return EntryMoneyData(
      entryId: data.entryId.present ? data.entryId.value : this.entryId,
      servicesTotal: data.servicesTotal.present
          ? data.servicesTotal.value
          : this.servicesTotal,
      productsTotal: data.productsTotal.present
          ? data.productsTotal.value
          : this.productsTotal,
      currencyCode: data.currencyCode.present
          ? data.currencyCode.value
          : this.currencyCode,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EntryMoneyData(')
          ..write('entryId: $entryId, ')
          ..write('servicesTotal: $servicesTotal, ')
          ..write('productsTotal: $productsTotal, ')
          ..write('currencyCode: $currencyCode')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(entryId, servicesTotal, productsTotal, currencyCode);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EntryMoneyData &&
          other.entryId == this.entryId &&
          other.servicesTotal == this.servicesTotal &&
          other.productsTotal == this.productsTotal &&
          other.currencyCode == this.currencyCode);
}

class EntryMoneyCompanion extends UpdateCompanion<EntryMoneyData> {
  final Value<String> entryId;
  final Value<double> servicesTotal;
  final Value<double> productsTotal;
  final Value<String> currencyCode;
  final Value<int> rowid;
  const EntryMoneyCompanion({
    this.entryId = const Value.absent(),
    this.servicesTotal = const Value.absent(),
    this.productsTotal = const Value.absent(),
    this.currencyCode = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EntryMoneyCompanion.insert({
    required String entryId,
    this.servicesTotal = const Value.absent(),
    this.productsTotal = const Value.absent(),
    this.currencyCode = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : entryId = Value(entryId);
  static Insertable<EntryMoneyData> custom({
    Expression<String>? entryId,
    Expression<double>? servicesTotal,
    Expression<double>? productsTotal,
    Expression<String>? currencyCode,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (entryId != null) 'entry_id': entryId,
      if (servicesTotal != null) 'services_total': servicesTotal,
      if (productsTotal != null) 'products_total': productsTotal,
      if (currencyCode != null) 'currency_code': currencyCode,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EntryMoneyCompanion copyWith(
      {Value<String>? entryId,
      Value<double>? servicesTotal,
      Value<double>? productsTotal,
      Value<String>? currencyCode,
      Value<int>? rowid}) {
    return EntryMoneyCompanion(
      entryId: entryId ?? this.entryId,
      servicesTotal: servicesTotal ?? this.servicesTotal,
      productsTotal: productsTotal ?? this.productsTotal,
      currencyCode: currencyCode ?? this.currencyCode,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (entryId.present) {
      map['entry_id'] = Variable<String>(entryId.value);
    }
    if (servicesTotal.present) {
      map['services_total'] = Variable<double>(servicesTotal.value);
    }
    if (productsTotal.present) {
      map['products_total'] = Variable<double>(productsTotal.value);
    }
    if (currencyCode.present) {
      map['currency_code'] = Variable<String>(currencyCode.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EntryMoneyCompanion(')
          ..write('entryId: $entryId, ')
          ..write('servicesTotal: $servicesTotal, ')
          ..write('productsTotal: $productsTotal, ')
          ..write('currencyCode: $currencyCode, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CatalogItemsTable extends CatalogItems
    with TableInfo<$CatalogItemsTable, CatalogItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CatalogItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _categoryMeta =
      const VerificationMeta('category');
  @override
  late final GeneratedColumn<String> category = GeneratedColumn<String>(
      'category', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _professionMeta =
      const VerificationMeta('profession');
  @override
  late final GeneratedColumn<String> profession = GeneratedColumn<String>(
      'profession', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _defaultPriceMeta =
      const VerificationMeta('defaultPrice');
  @override
  late final GeneratedColumn<double> defaultPrice = GeneratedColumn<double>(
      'default_price', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _orderIndexMeta =
      const VerificationMeta('orderIndex');
  @override
  late final GeneratedColumn<int> orderIndex = GeneratedColumn<int>(
      'order_index', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        salonId,
        type,
        category,
        profession,
        name,
        defaultPrice,
        orderIndex,
        isActive
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'catalog_items';
  @override
  VerificationContext validateIntegrity(Insertable<CatalogItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('category')) {
      context.handle(_categoryMeta,
          category.isAcceptableOrUnknown(data['category']!, _categoryMeta));
    } else if (isInserting) {
      context.missing(_categoryMeta);
    }
    if (data.containsKey('profession')) {
      context.handle(
          _professionMeta,
          profession.isAcceptableOrUnknown(
              data['profession']!, _professionMeta));
    } else if (isInserting) {
      context.missing(_professionMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('default_price')) {
      context.handle(
          _defaultPriceMeta,
          defaultPrice.isAcceptableOrUnknown(
              data['default_price']!, _defaultPriceMeta));
    }
    if (data.containsKey('order_index')) {
      context.handle(
          _orderIndexMeta,
          orderIndex.isAcceptableOrUnknown(
              data['order_index']!, _orderIndexMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CatalogItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CatalogItem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      category: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category'])!,
      profession: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}profession'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      defaultPrice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}default_price']),
      orderIndex: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}order_index'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
    );
  }

  @override
  $CatalogItemsTable createAlias(String alias) {
    return $CatalogItemsTable(attachedDatabase, alias);
  }
}

class CatalogItem extends DataClass implements Insertable<CatalogItem> {
  final String id;
  final String salonId;
  final String type;
  final String category;
  final String profession;
  final String name;
  final double? defaultPrice;
  final int orderIndex;
  final bool isActive;
  const CatalogItem(
      {required this.id,
      required this.salonId,
      required this.type,
      required this.category,
      required this.profession,
      required this.name,
      this.defaultPrice,
      required this.orderIndex,
      required this.isActive});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['type'] = Variable<String>(type);
    map['category'] = Variable<String>(category);
    map['profession'] = Variable<String>(profession);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || defaultPrice != null) {
      map['default_price'] = Variable<double>(defaultPrice);
    }
    map['order_index'] = Variable<int>(orderIndex);
    map['is_active'] = Variable<bool>(isActive);
    return map;
  }

  CatalogItemsCompanion toCompanion(bool nullToAbsent) {
    return CatalogItemsCompanion(
      id: Value(id),
      salonId: Value(salonId),
      type: Value(type),
      category: Value(category),
      profession: Value(profession),
      name: Value(name),
      defaultPrice: defaultPrice == null && nullToAbsent
          ? const Value.absent()
          : Value(defaultPrice),
      orderIndex: Value(orderIndex),
      isActive: Value(isActive),
    );
  }

  factory CatalogItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CatalogItem(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      type: serializer.fromJson<String>(json['type']),
      category: serializer.fromJson<String>(json['category']),
      profession: serializer.fromJson<String>(json['profession']),
      name: serializer.fromJson<String>(json['name']),
      defaultPrice: serializer.fromJson<double?>(json['defaultPrice']),
      orderIndex: serializer.fromJson<int>(json['orderIndex']),
      isActive: serializer.fromJson<bool>(json['isActive']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'type': serializer.toJson<String>(type),
      'category': serializer.toJson<String>(category),
      'profession': serializer.toJson<String>(profession),
      'name': serializer.toJson<String>(name),
      'defaultPrice': serializer.toJson<double?>(defaultPrice),
      'orderIndex': serializer.toJson<int>(orderIndex),
      'isActive': serializer.toJson<bool>(isActive),
    };
  }

  CatalogItem copyWith(
          {String? id,
          String? salonId,
          String? type,
          String? category,
          String? profession,
          String? name,
          Value<double?> defaultPrice = const Value.absent(),
          int? orderIndex,
          bool? isActive}) =>
      CatalogItem(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        type: type ?? this.type,
        category: category ?? this.category,
        profession: profession ?? this.profession,
        name: name ?? this.name,
        defaultPrice:
            defaultPrice.present ? defaultPrice.value : this.defaultPrice,
        orderIndex: orderIndex ?? this.orderIndex,
        isActive: isActive ?? this.isActive,
      );
  CatalogItem copyWithCompanion(CatalogItemsCompanion data) {
    return CatalogItem(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      type: data.type.present ? data.type.value : this.type,
      category: data.category.present ? data.category.value : this.category,
      profession:
          data.profession.present ? data.profession.value : this.profession,
      name: data.name.present ? data.name.value : this.name,
      defaultPrice: data.defaultPrice.present
          ? data.defaultPrice.value
          : this.defaultPrice,
      orderIndex:
          data.orderIndex.present ? data.orderIndex.value : this.orderIndex,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CatalogItem(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('type: $type, ')
          ..write('category: $category, ')
          ..write('profession: $profession, ')
          ..write('name: $name, ')
          ..write('defaultPrice: $defaultPrice, ')
          ..write('orderIndex: $orderIndex, ')
          ..write('isActive: $isActive')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, salonId, type, category, profession, name,
      defaultPrice, orderIndex, isActive);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CatalogItem &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.type == this.type &&
          other.category == this.category &&
          other.profession == this.profession &&
          other.name == this.name &&
          other.defaultPrice == this.defaultPrice &&
          other.orderIndex == this.orderIndex &&
          other.isActive == this.isActive);
}

class CatalogItemsCompanion extends UpdateCompanion<CatalogItem> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<String> type;
  final Value<String> category;
  final Value<String> profession;
  final Value<String> name;
  final Value<double?> defaultPrice;
  final Value<int> orderIndex;
  final Value<bool> isActive;
  final Value<int> rowid;
  const CatalogItemsCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.type = const Value.absent(),
    this.category = const Value.absent(),
    this.profession = const Value.absent(),
    this.name = const Value.absent(),
    this.defaultPrice = const Value.absent(),
    this.orderIndex = const Value.absent(),
    this.isActive = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CatalogItemsCompanion.insert({
    required String id,
    required String salonId,
    required String type,
    required String category,
    required String profession,
    required String name,
    this.defaultPrice = const Value.absent(),
    this.orderIndex = const Value.absent(),
    this.isActive = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        type = Value(type),
        category = Value(category),
        profession = Value(profession),
        name = Value(name);
  static Insertable<CatalogItem> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<String>? type,
    Expression<String>? category,
    Expression<String>? profession,
    Expression<String>? name,
    Expression<double>? defaultPrice,
    Expression<int>? orderIndex,
    Expression<bool>? isActive,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (type != null) 'type': type,
      if (category != null) 'category': category,
      if (profession != null) 'profession': profession,
      if (name != null) 'name': name,
      if (defaultPrice != null) 'default_price': defaultPrice,
      if (orderIndex != null) 'order_index': orderIndex,
      if (isActive != null) 'is_active': isActive,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CatalogItemsCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<String>? type,
      Value<String>? category,
      Value<String>? profession,
      Value<String>? name,
      Value<double?>? defaultPrice,
      Value<int>? orderIndex,
      Value<bool>? isActive,
      Value<int>? rowid}) {
    return CatalogItemsCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      type: type ?? this.type,
      category: category ?? this.category,
      profession: profession ?? this.profession,
      name: name ?? this.name,
      defaultPrice: defaultPrice ?? this.defaultPrice,
      orderIndex: orderIndex ?? this.orderIndex,
      isActive: isActive ?? this.isActive,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (category.present) {
      map['category'] = Variable<String>(category.value);
    }
    if (profession.present) {
      map['profession'] = Variable<String>(profession.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (defaultPrice.present) {
      map['default_price'] = Variable<double>(defaultPrice.value);
    }
    if (orderIndex.present) {
      map['order_index'] = Variable<int>(orderIndex.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CatalogItemsCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('type: $type, ')
          ..write('category: $category, ')
          ..write('profession: $profession, ')
          ..write('name: $name, ')
          ..write('defaultPrice: $defaultPrice, ')
          ..write('orderIndex: $orderIndex, ')
          ..write('isActive: $isActive, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AttributeOptionsTable extends AttributeOptions
    with TableInfo<$AttributeOptionsTable, AttributeOption> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AttributeOptionsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _salonIdMeta =
      const VerificationMeta('salonId');
  @override
  late final GeneratedColumn<String> salonId = GeneratedColumn<String>(
      'salon_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _valueMeta = const VerificationMeta('value');
  @override
  late final GeneratedColumn<String> value = GeneratedColumn<String>(
      'value', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _orderIndexMeta =
      const VerificationMeta('orderIndex');
  @override
  late final GeneratedColumn<int> orderIndex = GeneratedColumn<int>(
      'order_index', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  @override
  List<GeneratedColumn> get $columns =>
      [id, salonId, type, value, orderIndex, isActive];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'attribute_options';
  @override
  VerificationContext validateIntegrity(Insertable<AttributeOption> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('salon_id')) {
      context.handle(_salonIdMeta,
          salonId.isAcceptableOrUnknown(data['salon_id']!, _salonIdMeta));
    } else if (isInserting) {
      context.missing(_salonIdMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('value')) {
      context.handle(
          _valueMeta, value.isAcceptableOrUnknown(data['value']!, _valueMeta));
    } else if (isInserting) {
      context.missing(_valueMeta);
    }
    if (data.containsKey('order_index')) {
      context.handle(
          _orderIndexMeta,
          orderIndex.isAcceptableOrUnknown(
              data['order_index']!, _orderIndexMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AttributeOption map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AttributeOption(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      salonId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salon_id'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      value: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}value'])!,
      orderIndex: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}order_index'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
    );
  }

  @override
  $AttributeOptionsTable createAlias(String alias) {
    return $AttributeOptionsTable(attachedDatabase, alias);
  }
}

class AttributeOption extends DataClass implements Insertable<AttributeOption> {
  final String id;
  final String salonId;
  final String type;
  final String value;
  final int orderIndex;
  final bool isActive;
  const AttributeOption(
      {required this.id,
      required this.salonId,
      required this.type,
      required this.value,
      required this.orderIndex,
      required this.isActive});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['salon_id'] = Variable<String>(salonId);
    map['type'] = Variable<String>(type);
    map['value'] = Variable<String>(value);
    map['order_index'] = Variable<int>(orderIndex);
    map['is_active'] = Variable<bool>(isActive);
    return map;
  }

  AttributeOptionsCompanion toCompanion(bool nullToAbsent) {
    return AttributeOptionsCompanion(
      id: Value(id),
      salonId: Value(salonId),
      type: Value(type),
      value: Value(value),
      orderIndex: Value(orderIndex),
      isActive: Value(isActive),
    );
  }

  factory AttributeOption.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AttributeOption(
      id: serializer.fromJson<String>(json['id']),
      salonId: serializer.fromJson<String>(json['salonId']),
      type: serializer.fromJson<String>(json['type']),
      value: serializer.fromJson<String>(json['value']),
      orderIndex: serializer.fromJson<int>(json['orderIndex']),
      isActive: serializer.fromJson<bool>(json['isActive']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'salonId': serializer.toJson<String>(salonId),
      'type': serializer.toJson<String>(type),
      'value': serializer.toJson<String>(value),
      'orderIndex': serializer.toJson<int>(orderIndex),
      'isActive': serializer.toJson<bool>(isActive),
    };
  }

  AttributeOption copyWith(
          {String? id,
          String? salonId,
          String? type,
          String? value,
          int? orderIndex,
          bool? isActive}) =>
      AttributeOption(
        id: id ?? this.id,
        salonId: salonId ?? this.salonId,
        type: type ?? this.type,
        value: value ?? this.value,
        orderIndex: orderIndex ?? this.orderIndex,
        isActive: isActive ?? this.isActive,
      );
  AttributeOption copyWithCompanion(AttributeOptionsCompanion data) {
    return AttributeOption(
      id: data.id.present ? data.id.value : this.id,
      salonId: data.salonId.present ? data.salonId.value : this.salonId,
      type: data.type.present ? data.type.value : this.type,
      value: data.value.present ? data.value.value : this.value,
      orderIndex:
          data.orderIndex.present ? data.orderIndex.value : this.orderIndex,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AttributeOption(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('type: $type, ')
          ..write('value: $value, ')
          ..write('orderIndex: $orderIndex, ')
          ..write('isActive: $isActive')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, salonId, type, value, orderIndex, isActive);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AttributeOption &&
          other.id == this.id &&
          other.salonId == this.salonId &&
          other.type == this.type &&
          other.value == this.value &&
          other.orderIndex == this.orderIndex &&
          other.isActive == this.isActive);
}

class AttributeOptionsCompanion extends UpdateCompanion<AttributeOption> {
  final Value<String> id;
  final Value<String> salonId;
  final Value<String> type;
  final Value<String> value;
  final Value<int> orderIndex;
  final Value<bool> isActive;
  final Value<int> rowid;
  const AttributeOptionsCompanion({
    this.id = const Value.absent(),
    this.salonId = const Value.absent(),
    this.type = const Value.absent(),
    this.value = const Value.absent(),
    this.orderIndex = const Value.absent(),
    this.isActive = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AttributeOptionsCompanion.insert({
    required String id,
    required String salonId,
    required String type,
    required String value,
    this.orderIndex = const Value.absent(),
    this.isActive = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        salonId = Value(salonId),
        type = Value(type),
        value = Value(value);
  static Insertable<AttributeOption> custom({
    Expression<String>? id,
    Expression<String>? salonId,
    Expression<String>? type,
    Expression<String>? value,
    Expression<int>? orderIndex,
    Expression<bool>? isActive,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (salonId != null) 'salon_id': salonId,
      if (type != null) 'type': type,
      if (value != null) 'value': value,
      if (orderIndex != null) 'order_index': orderIndex,
      if (isActive != null) 'is_active': isActive,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AttributeOptionsCompanion copyWith(
      {Value<String>? id,
      Value<String>? salonId,
      Value<String>? type,
      Value<String>? value,
      Value<int>? orderIndex,
      Value<bool>? isActive,
      Value<int>? rowid}) {
    return AttributeOptionsCompanion(
      id: id ?? this.id,
      salonId: salonId ?? this.salonId,
      type: type ?? this.type,
      value: value ?? this.value,
      orderIndex: orderIndex ?? this.orderIndex,
      isActive: isActive ?? this.isActive,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (salonId.present) {
      map['salon_id'] = Variable<String>(salonId.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (value.present) {
      map['value'] = Variable<String>(value.value);
    }
    if (orderIndex.present) {
      map['order_index'] = Variable<int>(orderIndex.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AttributeOptionsCompanion(')
          ..write('id: $id, ')
          ..write('salonId: $salonId, ')
          ..write('type: $type, ')
          ..write('value: $value, ')
          ..write('orderIndex: $orderIndex, ')
          ..write('isActive: $isActive, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EntryLinesTable extends EntryLines
    with TableInfo<$EntryLinesTable, EntryLine> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EntryLinesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entryIdMeta =
      const VerificationMeta('entryId');
  @override
  late final GeneratedColumn<String> entryId = GeneratedColumn<String>(
      'entry_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _catalogItemIdMeta =
      const VerificationMeta('catalogItemId');
  @override
  late final GeneratedColumn<String> catalogItemId = GeneratedColumn<String>(
      'catalog_item_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _lineTypeMeta =
      const VerificationMeta('lineType');
  @override
  late final GeneratedColumn<String> lineType = GeneratedColumn<String>(
      'line_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _qtyMeta = const VerificationMeta('qty');
  @override
  late final GeneratedColumn<int> qty = GeneratedColumn<int>(
      'qty', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _metaJsonMeta =
      const VerificationMeta('metaJson');
  @override
  late final GeneratedColumn<String> metaJson = GeneratedColumn<String>(
      'meta_json', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, entryId, catalogItemId, lineType, qty, metaJson, createdAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'entry_lines';
  @override
  VerificationContext validateIntegrity(Insertable<EntryLine> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('entry_id')) {
      context.handle(_entryIdMeta,
          entryId.isAcceptableOrUnknown(data['entry_id']!, _entryIdMeta));
    } else if (isInserting) {
      context.missing(_entryIdMeta);
    }
    if (data.containsKey('catalog_item_id')) {
      context.handle(
          _catalogItemIdMeta,
          catalogItemId.isAcceptableOrUnknown(
              data['catalog_item_id']!, _catalogItemIdMeta));
    } else if (isInserting) {
      context.missing(_catalogItemIdMeta);
    }
    if (data.containsKey('line_type')) {
      context.handle(_lineTypeMeta,
          lineType.isAcceptableOrUnknown(data['line_type']!, _lineTypeMeta));
    } else if (isInserting) {
      context.missing(_lineTypeMeta);
    }
    if (data.containsKey('qty')) {
      context.handle(
          _qtyMeta, qty.isAcceptableOrUnknown(data['qty']!, _qtyMeta));
    }
    if (data.containsKey('meta_json')) {
      context.handle(_metaJsonMeta,
          metaJson.isAcceptableOrUnknown(data['meta_json']!, _metaJsonMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EntryLine map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EntryLine(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      entryId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entry_id'])!,
      catalogItemId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}catalog_item_id'])!,
      lineType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}line_type'])!,
      qty: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}qty'])!,
      metaJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}meta_json']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $EntryLinesTable createAlias(String alias) {
    return $EntryLinesTable(attachedDatabase, alias);
  }
}

class EntryLine extends DataClass implements Insertable<EntryLine> {
  final String id;
  final String entryId;
  final String catalogItemId;
  final String lineType;
  final int qty;
  final String? metaJson;
  final DateTime createdAt;
  const EntryLine(
      {required this.id,
      required this.entryId,
      required this.catalogItemId,
      required this.lineType,
      required this.qty,
      this.metaJson,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['entry_id'] = Variable<String>(entryId);
    map['catalog_item_id'] = Variable<String>(catalogItemId);
    map['line_type'] = Variable<String>(lineType);
    map['qty'] = Variable<int>(qty);
    if (!nullToAbsent || metaJson != null) {
      map['meta_json'] = Variable<String>(metaJson);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  EntryLinesCompanion toCompanion(bool nullToAbsent) {
    return EntryLinesCompanion(
      id: Value(id),
      entryId: Value(entryId),
      catalogItemId: Value(catalogItemId),
      lineType: Value(lineType),
      qty: Value(qty),
      metaJson: metaJson == null && nullToAbsent
          ? const Value.absent()
          : Value(metaJson),
      createdAt: Value(createdAt),
    );
  }

  factory EntryLine.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EntryLine(
      id: serializer.fromJson<String>(json['id']),
      entryId: serializer.fromJson<String>(json['entryId']),
      catalogItemId: serializer.fromJson<String>(json['catalogItemId']),
      lineType: serializer.fromJson<String>(json['lineType']),
      qty: serializer.fromJson<int>(json['qty']),
      metaJson: serializer.fromJson<String?>(json['metaJson']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'entryId': serializer.toJson<String>(entryId),
      'catalogItemId': serializer.toJson<String>(catalogItemId),
      'lineType': serializer.toJson<String>(lineType),
      'qty': serializer.toJson<int>(qty),
      'metaJson': serializer.toJson<String?>(metaJson),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  EntryLine copyWith(
          {String? id,
          String? entryId,
          String? catalogItemId,
          String? lineType,
          int? qty,
          Value<String?> metaJson = const Value.absent(),
          DateTime? createdAt}) =>
      EntryLine(
        id: id ?? this.id,
        entryId: entryId ?? this.entryId,
        catalogItemId: catalogItemId ?? this.catalogItemId,
        lineType: lineType ?? this.lineType,
        qty: qty ?? this.qty,
        metaJson: metaJson.present ? metaJson.value : this.metaJson,
        createdAt: createdAt ?? this.createdAt,
      );
  EntryLine copyWithCompanion(EntryLinesCompanion data) {
    return EntryLine(
      id: data.id.present ? data.id.value : this.id,
      entryId: data.entryId.present ? data.entryId.value : this.entryId,
      catalogItemId: data.catalogItemId.present
          ? data.catalogItemId.value
          : this.catalogItemId,
      lineType: data.lineType.present ? data.lineType.value : this.lineType,
      qty: data.qty.present ? data.qty.value : this.qty,
      metaJson: data.metaJson.present ? data.metaJson.value : this.metaJson,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EntryLine(')
          ..write('id: $id, ')
          ..write('entryId: $entryId, ')
          ..write('catalogItemId: $catalogItemId, ')
          ..write('lineType: $lineType, ')
          ..write('qty: $qty, ')
          ..write('metaJson: $metaJson, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, entryId, catalogItemId, lineType, qty, metaJson, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EntryLine &&
          other.id == this.id &&
          other.entryId == this.entryId &&
          other.catalogItemId == this.catalogItemId &&
          other.lineType == this.lineType &&
          other.qty == this.qty &&
          other.metaJson == this.metaJson &&
          other.createdAt == this.createdAt);
}

class EntryLinesCompanion extends UpdateCompanion<EntryLine> {
  final Value<String> id;
  final Value<String> entryId;
  final Value<String> catalogItemId;
  final Value<String> lineType;
  final Value<int> qty;
  final Value<String?> metaJson;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const EntryLinesCompanion({
    this.id = const Value.absent(),
    this.entryId = const Value.absent(),
    this.catalogItemId = const Value.absent(),
    this.lineType = const Value.absent(),
    this.qty = const Value.absent(),
    this.metaJson = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EntryLinesCompanion.insert({
    required String id,
    required String entryId,
    required String catalogItemId,
    required String lineType,
    this.qty = const Value.absent(),
    this.metaJson = const Value.absent(),
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        entryId = Value(entryId),
        catalogItemId = Value(catalogItemId),
        lineType = Value(lineType),
        createdAt = Value(createdAt);
  static Insertable<EntryLine> custom({
    Expression<String>? id,
    Expression<String>? entryId,
    Expression<String>? catalogItemId,
    Expression<String>? lineType,
    Expression<int>? qty,
    Expression<String>? metaJson,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (entryId != null) 'entry_id': entryId,
      if (catalogItemId != null) 'catalog_item_id': catalogItemId,
      if (lineType != null) 'line_type': lineType,
      if (qty != null) 'qty': qty,
      if (metaJson != null) 'meta_json': metaJson,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EntryLinesCompanion copyWith(
      {Value<String>? id,
      Value<String>? entryId,
      Value<String>? catalogItemId,
      Value<String>? lineType,
      Value<int>? qty,
      Value<String?>? metaJson,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return EntryLinesCompanion(
      id: id ?? this.id,
      entryId: entryId ?? this.entryId,
      catalogItemId: catalogItemId ?? this.catalogItemId,
      lineType: lineType ?? this.lineType,
      qty: qty ?? this.qty,
      metaJson: metaJson ?? this.metaJson,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (entryId.present) {
      map['entry_id'] = Variable<String>(entryId.value);
    }
    if (catalogItemId.present) {
      map['catalog_item_id'] = Variable<String>(catalogItemId.value);
    }
    if (lineType.present) {
      map['line_type'] = Variable<String>(lineType.value);
    }
    if (qty.present) {
      map['qty'] = Variable<int>(qty.value);
    }
    if (metaJson.present) {
      map['meta_json'] = Variable<String>(metaJson.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EntryLinesCompanion(')
          ..write('id: $id, ')
          ..write('entryId: $entryId, ')
          ..write('catalogItemId: $catalogItemId, ')
          ..write('lineType: $lineType, ')
          ..write('qty: $qty, ')
          ..write('metaJson: $metaJson, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $SalonsTable salons = $SalonsTable(this);
  late final $UsersTable users = $UsersTable(this);
  late final $SyncOutboxTable syncOutbox = $SyncOutboxTable(this);
  late final $SyncStateTable syncState = $SyncStateTable(this);
  late final $SalonSettingsTable salonSettings = $SalonSettingsTable(this);
  late final $SalonWorkHoursTable salonWorkHours = $SalonWorkHoursTable(this);
  late final $StaffColumnsTable staffColumns = $StaffColumnsTable(this);
  late final $WorkDaysTable workDays = $WorkDaysTable(this);
  late final $TimeSlotEntriesTable timeSlotEntries =
      $TimeSlotEntriesTable(this);
  late final $EntryMoneyTable entryMoney = $EntryMoneyTable(this);
  late final $CatalogItemsTable catalogItems = $CatalogItemsTable(this);
  late final $AttributeOptionsTable attributeOptions =
      $AttributeOptionsTable(this);
  late final $EntryLinesTable entryLines = $EntryLinesTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        salons,
        users,
        syncOutbox,
        syncState,
        salonSettings,
        salonWorkHours,
        staffColumns,
        workDays,
        timeSlotEntries,
        entryMoney,
        catalogItems,
        attributeOptions,
        entryLines
      ];
}

typedef $$SalonsTableCreateCompanionBuilder = SalonsCompanion Function({
  required String id,
  required String name,
  Value<int> rowid,
});
typedef $$SalonsTableUpdateCompanionBuilder = SalonsCompanion Function({
  Value<String> id,
  Value<String> name,
  Value<int> rowid,
});

class $$SalonsTableFilterComposer
    extends Composer<_$AppDatabase, $SalonsTable> {
  $$SalonsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));
}

class $$SalonsTableOrderingComposer
    extends Composer<_$AppDatabase, $SalonsTable> {
  $$SalonsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));
}

class $$SalonsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SalonsTable> {
  $$SalonsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);
}

class $$SalonsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SalonsTable,
    Salon,
    $$SalonsTableFilterComposer,
    $$SalonsTableOrderingComposer,
    $$SalonsTableAnnotationComposer,
    $$SalonsTableCreateCompanionBuilder,
    $$SalonsTableUpdateCompanionBuilder,
    (Salon, BaseReferences<_$AppDatabase, $SalonsTable, Salon>),
    Salon,
    PrefetchHooks Function()> {
  $$SalonsTableTableManager(_$AppDatabase db, $SalonsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SalonsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SalonsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SalonsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SalonsCompanion(
            id: id,
            name: name,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String name,
            Value<int> rowid = const Value.absent(),
          }) =>
              SalonsCompanion.insert(
            id: id,
            name: name,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SalonsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SalonsTable,
    Salon,
    $$SalonsTableFilterComposer,
    $$SalonsTableOrderingComposer,
    $$SalonsTableAnnotationComposer,
    $$SalonsTableCreateCompanionBuilder,
    $$SalonsTableUpdateCompanionBuilder,
    (Salon, BaseReferences<_$AppDatabase, $SalonsTable, Salon>),
    Salon,
    PrefetchHooks Function()>;
typedef $$UsersTableCreateCompanionBuilder = UsersCompanion Function({
  required String id,
  required String salonId,
  required String username,
  Value<String?> usernameNorm,
  required String password,
  Value<bool> isActive,
  Value<bool> isAdmin,
  Value<int> rowid,
});
typedef $$UsersTableUpdateCompanionBuilder = UsersCompanion Function({
  Value<String> id,
  Value<String> salonId,
  Value<String> username,
  Value<String?> usernameNorm,
  Value<String> password,
  Value<bool> isActive,
  Value<bool> isAdmin,
  Value<int> rowid,
});

class $$UsersTableFilterComposer extends Composer<_$AppDatabase, $UsersTable> {
  $$UsersTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get username => $composableBuilder(
      column: $table.username, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get usernameNorm => $composableBuilder(
      column: $table.usernameNorm, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get password => $composableBuilder(
      column: $table.password, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isAdmin => $composableBuilder(
      column: $table.isAdmin, builder: (column) => ColumnFilters(column));
}

class $$UsersTableOrderingComposer
    extends Composer<_$AppDatabase, $UsersTable> {
  $$UsersTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get username => $composableBuilder(
      column: $table.username, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get usernameNorm => $composableBuilder(
      column: $table.usernameNorm,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get password => $composableBuilder(
      column: $table.password, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isAdmin => $composableBuilder(
      column: $table.isAdmin, builder: (column) => ColumnOrderings(column));
}

class $$UsersTableAnnotationComposer
    extends Composer<_$AppDatabase, $UsersTable> {
  $$UsersTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<String> get username =>
      $composableBuilder(column: $table.username, builder: (column) => column);

  GeneratedColumn<String> get usernameNorm => $composableBuilder(
      column: $table.usernameNorm, builder: (column) => column);

  GeneratedColumn<String> get password =>
      $composableBuilder(column: $table.password, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<bool> get isAdmin =>
      $composableBuilder(column: $table.isAdmin, builder: (column) => column);
}

class $$UsersTableTableManager extends RootTableManager<
    _$AppDatabase,
    $UsersTable,
    User,
    $$UsersTableFilterComposer,
    $$UsersTableOrderingComposer,
    $$UsersTableAnnotationComposer,
    $$UsersTableCreateCompanionBuilder,
    $$UsersTableUpdateCompanionBuilder,
    (User, BaseReferences<_$AppDatabase, $UsersTable, User>),
    User,
    PrefetchHooks Function()> {
  $$UsersTableTableManager(_$AppDatabase db, $UsersTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$UsersTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$UsersTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$UsersTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<String> username = const Value.absent(),
            Value<String?> usernameNorm = const Value.absent(),
            Value<String> password = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<bool> isAdmin = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              UsersCompanion(
            id: id,
            salonId: salonId,
            username: username,
            usernameNorm: usernameNorm,
            password: password,
            isActive: isActive,
            isAdmin: isAdmin,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required String username,
            Value<String?> usernameNorm = const Value.absent(),
            required String password,
            Value<bool> isActive = const Value.absent(),
            Value<bool> isAdmin = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              UsersCompanion.insert(
            id: id,
            salonId: salonId,
            username: username,
            usernameNorm: usernameNorm,
            password: password,
            isActive: isActive,
            isAdmin: isAdmin,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$UsersTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $UsersTable,
    User,
    $$UsersTableFilterComposer,
    $$UsersTableOrderingComposer,
    $$UsersTableAnnotationComposer,
    $$UsersTableCreateCompanionBuilder,
    $$UsersTableUpdateCompanionBuilder,
    (User, BaseReferences<_$AppDatabase, $UsersTable, User>),
    User,
    PrefetchHooks Function()>;
typedef $$SyncOutboxTableCreateCompanionBuilder = SyncOutboxCompanion Function({
  required String opId,
  required String salonId,
  required String entityType,
  required String entityId,
  required String op,
  Value<int> baseVersion,
  Value<String> payloadJson,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$SyncOutboxTableUpdateCompanionBuilder = SyncOutboxCompanion Function({
  Value<String> opId,
  Value<String> salonId,
  Value<String> entityType,
  Value<String> entityId,
  Value<String> op,
  Value<int> baseVersion,
  Value<String> payloadJson,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$SyncOutboxTableFilterComposer
    extends Composer<_$AppDatabase, $SyncOutboxTable> {
  $$SyncOutboxTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get opId => $composableBuilder(
      column: $table.opId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get op => $composableBuilder(
      column: $table.op, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get baseVersion => $composableBuilder(
      column: $table.baseVersion, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$SyncOutboxTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncOutboxTable> {
  $$SyncOutboxTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get opId => $composableBuilder(
      column: $table.opId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get op => $composableBuilder(
      column: $table.op, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get baseVersion => $composableBuilder(
      column: $table.baseVersion, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$SyncOutboxTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncOutboxTable> {
  $$SyncOutboxTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get opId =>
      $composableBuilder(column: $table.opId, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<String> get op =>
      $composableBuilder(column: $table.op, builder: (column) => column);

  GeneratedColumn<int> get baseVersion => $composableBuilder(
      column: $table.baseVersion, builder: (column) => column);

  GeneratedColumn<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$SyncOutboxTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncOutboxTable,
    SyncOutboxData,
    $$SyncOutboxTableFilterComposer,
    $$SyncOutboxTableOrderingComposer,
    $$SyncOutboxTableAnnotationComposer,
    $$SyncOutboxTableCreateCompanionBuilder,
    $$SyncOutboxTableUpdateCompanionBuilder,
    (
      SyncOutboxData,
      BaseReferences<_$AppDatabase, $SyncOutboxTable, SyncOutboxData>
    ),
    SyncOutboxData,
    PrefetchHooks Function()> {
  $$SyncOutboxTableTableManager(_$AppDatabase db, $SyncOutboxTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncOutboxTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncOutboxTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncOutboxTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> opId = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<String> op = const Value.absent(),
            Value<int> baseVersion = const Value.absent(),
            Value<String> payloadJson = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncOutboxCompanion(
            opId: opId,
            salonId: salonId,
            entityType: entityType,
            entityId: entityId,
            op: op,
            baseVersion: baseVersion,
            payloadJson: payloadJson,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String opId,
            required String salonId,
            required String entityType,
            required String entityId,
            required String op,
            Value<int> baseVersion = const Value.absent(),
            Value<String> payloadJson = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncOutboxCompanion.insert(
            opId: opId,
            salonId: salonId,
            entityType: entityType,
            entityId: entityId,
            op: op,
            baseVersion: baseVersion,
            payloadJson: payloadJson,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncOutboxTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncOutboxTable,
    SyncOutboxData,
    $$SyncOutboxTableFilterComposer,
    $$SyncOutboxTableOrderingComposer,
    $$SyncOutboxTableAnnotationComposer,
    $$SyncOutboxTableCreateCompanionBuilder,
    $$SyncOutboxTableUpdateCompanionBuilder,
    (
      SyncOutboxData,
      BaseReferences<_$AppDatabase, $SyncOutboxTable, SyncOutboxData>
    ),
    SyncOutboxData,
    PrefetchHooks Function()>;
typedef $$SyncStateTableCreateCompanionBuilder = SyncStateCompanion Function({
  required String salonId,
  Value<int> lastToken,
  Value<String?> deviceId,
  Value<DateTime?> lastSyncedAt,
  Value<int> rowid,
});
typedef $$SyncStateTableUpdateCompanionBuilder = SyncStateCompanion Function({
  Value<String> salonId,
  Value<int> lastToken,
  Value<String?> deviceId,
  Value<DateTime?> lastSyncedAt,
  Value<int> rowid,
});

class $$SyncStateTableFilterComposer
    extends Composer<_$AppDatabase, $SyncStateTable> {
  $$SyncStateTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lastToken => $composableBuilder(
      column: $table.lastToken, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deviceId => $composableBuilder(
      column: $table.deviceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get lastSyncedAt => $composableBuilder(
      column: $table.lastSyncedAt, builder: (column) => ColumnFilters(column));
}

class $$SyncStateTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncStateTable> {
  $$SyncStateTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lastToken => $composableBuilder(
      column: $table.lastToken, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deviceId => $composableBuilder(
      column: $table.deviceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get lastSyncedAt => $composableBuilder(
      column: $table.lastSyncedAt,
      builder: (column) => ColumnOrderings(column));
}

class $$SyncStateTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncStateTable> {
  $$SyncStateTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<int> get lastToken =>
      $composableBuilder(column: $table.lastToken, builder: (column) => column);

  GeneratedColumn<String> get deviceId =>
      $composableBuilder(column: $table.deviceId, builder: (column) => column);

  GeneratedColumn<DateTime> get lastSyncedAt => $composableBuilder(
      column: $table.lastSyncedAt, builder: (column) => column);
}

class $$SyncStateTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncStateTable,
    SyncStateData,
    $$SyncStateTableFilterComposer,
    $$SyncStateTableOrderingComposer,
    $$SyncStateTableAnnotationComposer,
    $$SyncStateTableCreateCompanionBuilder,
    $$SyncStateTableUpdateCompanionBuilder,
    (
      SyncStateData,
      BaseReferences<_$AppDatabase, $SyncStateTable, SyncStateData>
    ),
    SyncStateData,
    PrefetchHooks Function()> {
  $$SyncStateTableTableManager(_$AppDatabase db, $SyncStateTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncStateTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncStateTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncStateTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> salonId = const Value.absent(),
            Value<int> lastToken = const Value.absent(),
            Value<String?> deviceId = const Value.absent(),
            Value<DateTime?> lastSyncedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncStateCompanion(
            salonId: salonId,
            lastToken: lastToken,
            deviceId: deviceId,
            lastSyncedAt: lastSyncedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String salonId,
            Value<int> lastToken = const Value.absent(),
            Value<String?> deviceId = const Value.absent(),
            Value<DateTime?> lastSyncedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncStateCompanion.insert(
            salonId: salonId,
            lastToken: lastToken,
            deviceId: deviceId,
            lastSyncedAt: lastSyncedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncStateTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncStateTable,
    SyncStateData,
    $$SyncStateTableFilterComposer,
    $$SyncStateTableOrderingComposer,
    $$SyncStateTableAnnotationComposer,
    $$SyncStateTableCreateCompanionBuilder,
    $$SyncStateTableUpdateCompanionBuilder,
    (
      SyncStateData,
      BaseReferences<_$AppDatabase, $SyncStateTable, SyncStateData>
    ),
    SyncStateData,
    PrefetchHooks Function()>;
typedef $$SalonSettingsTableCreateCompanionBuilder = SalonSettingsCompanion
    Function({
  required String salonId,
  required int dayStartMinute,
  required int dayEndMinute,
  required int slotMinutes,
  Value<int> rowid,
});
typedef $$SalonSettingsTableUpdateCompanionBuilder = SalonSettingsCompanion
    Function({
  Value<String> salonId,
  Value<int> dayStartMinute,
  Value<int> dayEndMinute,
  Value<int> slotMinutes,
  Value<int> rowid,
});

class $$SalonSettingsTableFilterComposer
    extends Composer<_$AppDatabase, $SalonSettingsTable> {
  $$SalonSettingsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get dayStartMinute => $composableBuilder(
      column: $table.dayStartMinute,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get dayEndMinute => $composableBuilder(
      column: $table.dayEndMinute, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get slotMinutes => $composableBuilder(
      column: $table.slotMinutes, builder: (column) => ColumnFilters(column));
}

class $$SalonSettingsTableOrderingComposer
    extends Composer<_$AppDatabase, $SalonSettingsTable> {
  $$SalonSettingsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get dayStartMinute => $composableBuilder(
      column: $table.dayStartMinute,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get dayEndMinute => $composableBuilder(
      column: $table.dayEndMinute,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get slotMinutes => $composableBuilder(
      column: $table.slotMinutes, builder: (column) => ColumnOrderings(column));
}

class $$SalonSettingsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SalonSettingsTable> {
  $$SalonSettingsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<int> get dayStartMinute => $composableBuilder(
      column: $table.dayStartMinute, builder: (column) => column);

  GeneratedColumn<int> get dayEndMinute => $composableBuilder(
      column: $table.dayEndMinute, builder: (column) => column);

  GeneratedColumn<int> get slotMinutes => $composableBuilder(
      column: $table.slotMinutes, builder: (column) => column);
}

class $$SalonSettingsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SalonSettingsTable,
    SalonSetting,
    $$SalonSettingsTableFilterComposer,
    $$SalonSettingsTableOrderingComposer,
    $$SalonSettingsTableAnnotationComposer,
    $$SalonSettingsTableCreateCompanionBuilder,
    $$SalonSettingsTableUpdateCompanionBuilder,
    (
      SalonSetting,
      BaseReferences<_$AppDatabase, $SalonSettingsTable, SalonSetting>
    ),
    SalonSetting,
    PrefetchHooks Function()> {
  $$SalonSettingsTableTableManager(_$AppDatabase db, $SalonSettingsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SalonSettingsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SalonSettingsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SalonSettingsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> salonId = const Value.absent(),
            Value<int> dayStartMinute = const Value.absent(),
            Value<int> dayEndMinute = const Value.absent(),
            Value<int> slotMinutes = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SalonSettingsCompanion(
            salonId: salonId,
            dayStartMinute: dayStartMinute,
            dayEndMinute: dayEndMinute,
            slotMinutes: slotMinutes,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String salonId,
            required int dayStartMinute,
            required int dayEndMinute,
            required int slotMinutes,
            Value<int> rowid = const Value.absent(),
          }) =>
              SalonSettingsCompanion.insert(
            salonId: salonId,
            dayStartMinute: dayStartMinute,
            dayEndMinute: dayEndMinute,
            slotMinutes: slotMinutes,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SalonSettingsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SalonSettingsTable,
    SalonSetting,
    $$SalonSettingsTableFilterComposer,
    $$SalonSettingsTableOrderingComposer,
    $$SalonSettingsTableAnnotationComposer,
    $$SalonSettingsTableCreateCompanionBuilder,
    $$SalonSettingsTableUpdateCompanionBuilder,
    (
      SalonSetting,
      BaseReferences<_$AppDatabase, $SalonSettingsTable, SalonSetting>
    ),
    SalonSetting,
    PrefetchHooks Function()>;
typedef $$SalonWorkHoursTableCreateCompanionBuilder = SalonWorkHoursCompanion
    Function({
  required String id,
  required String salonId,
  required int weekday,
  required int startMinute,
  required int endMinute,
  Value<int> rowid,
});
typedef $$SalonWorkHoursTableUpdateCompanionBuilder = SalonWorkHoursCompanion
    Function({
  Value<String> id,
  Value<String> salonId,
  Value<int> weekday,
  Value<int> startMinute,
  Value<int> endMinute,
  Value<int> rowid,
});

class $$SalonWorkHoursTableFilterComposer
    extends Composer<_$AppDatabase, $SalonWorkHoursTable> {
  $$SalonWorkHoursTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get weekday => $composableBuilder(
      column: $table.weekday, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get startMinute => $composableBuilder(
      column: $table.startMinute, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get endMinute => $composableBuilder(
      column: $table.endMinute, builder: (column) => ColumnFilters(column));
}

class $$SalonWorkHoursTableOrderingComposer
    extends Composer<_$AppDatabase, $SalonWorkHoursTable> {
  $$SalonWorkHoursTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get weekday => $composableBuilder(
      column: $table.weekday, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get startMinute => $composableBuilder(
      column: $table.startMinute, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get endMinute => $composableBuilder(
      column: $table.endMinute, builder: (column) => ColumnOrderings(column));
}

class $$SalonWorkHoursTableAnnotationComposer
    extends Composer<_$AppDatabase, $SalonWorkHoursTable> {
  $$SalonWorkHoursTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<int> get weekday =>
      $composableBuilder(column: $table.weekday, builder: (column) => column);

  GeneratedColumn<int> get startMinute => $composableBuilder(
      column: $table.startMinute, builder: (column) => column);

  GeneratedColumn<int> get endMinute =>
      $composableBuilder(column: $table.endMinute, builder: (column) => column);
}

class $$SalonWorkHoursTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SalonWorkHoursTable,
    SalonWorkHour,
    $$SalonWorkHoursTableFilterComposer,
    $$SalonWorkHoursTableOrderingComposer,
    $$SalonWorkHoursTableAnnotationComposer,
    $$SalonWorkHoursTableCreateCompanionBuilder,
    $$SalonWorkHoursTableUpdateCompanionBuilder,
    (
      SalonWorkHour,
      BaseReferences<_$AppDatabase, $SalonWorkHoursTable, SalonWorkHour>
    ),
    SalonWorkHour,
    PrefetchHooks Function()> {
  $$SalonWorkHoursTableTableManager(
      _$AppDatabase db, $SalonWorkHoursTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SalonWorkHoursTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SalonWorkHoursTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SalonWorkHoursTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<int> weekday = const Value.absent(),
            Value<int> startMinute = const Value.absent(),
            Value<int> endMinute = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SalonWorkHoursCompanion(
            id: id,
            salonId: salonId,
            weekday: weekday,
            startMinute: startMinute,
            endMinute: endMinute,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required int weekday,
            required int startMinute,
            required int endMinute,
            Value<int> rowid = const Value.absent(),
          }) =>
              SalonWorkHoursCompanion.insert(
            id: id,
            salonId: salonId,
            weekday: weekday,
            startMinute: startMinute,
            endMinute: endMinute,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SalonWorkHoursTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SalonWorkHoursTable,
    SalonWorkHour,
    $$SalonWorkHoursTableFilterComposer,
    $$SalonWorkHoursTableOrderingComposer,
    $$SalonWorkHoursTableAnnotationComposer,
    $$SalonWorkHoursTableCreateCompanionBuilder,
    $$SalonWorkHoursTableUpdateCompanionBuilder,
    (
      SalonWorkHour,
      BaseReferences<_$AppDatabase, $SalonWorkHoursTable, SalonWorkHour>
    ),
    SalonWorkHour,
    PrefetchHooks Function()>;
typedef $$StaffColumnsTableCreateCompanionBuilder = StaffColumnsCompanion
    Function({
  required String id,
  required String salonId,
  required String userId,
  required String displayName,
  required String profession,
  Value<int> orderIndex,
  required DateTime activeFrom,
  Value<DateTime?> activeTo,
  Value<int> rowid,
});
typedef $$StaffColumnsTableUpdateCompanionBuilder = StaffColumnsCompanion
    Function({
  Value<String> id,
  Value<String> salonId,
  Value<String> userId,
  Value<String> displayName,
  Value<String> profession,
  Value<int> orderIndex,
  Value<DateTime> activeFrom,
  Value<DateTime?> activeTo,
  Value<int> rowid,
});

class $$StaffColumnsTableFilterComposer
    extends Composer<_$AppDatabase, $StaffColumnsTable> {
  $$StaffColumnsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get profession => $composableBuilder(
      column: $table.profession, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get activeFrom => $composableBuilder(
      column: $table.activeFrom, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get activeTo => $composableBuilder(
      column: $table.activeTo, builder: (column) => ColumnFilters(column));
}

class $$StaffColumnsTableOrderingComposer
    extends Composer<_$AppDatabase, $StaffColumnsTable> {
  $$StaffColumnsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get profession => $composableBuilder(
      column: $table.profession, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get activeFrom => $composableBuilder(
      column: $table.activeFrom, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get activeTo => $composableBuilder(
      column: $table.activeTo, builder: (column) => ColumnOrderings(column));
}

class $$StaffColumnsTableAnnotationComposer
    extends Composer<_$AppDatabase, $StaffColumnsTable> {
  $$StaffColumnsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => column);

  GeneratedColumn<String> get profession => $composableBuilder(
      column: $table.profession, builder: (column) => column);

  GeneratedColumn<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => column);

  GeneratedColumn<DateTime> get activeFrom => $composableBuilder(
      column: $table.activeFrom, builder: (column) => column);

  GeneratedColumn<DateTime> get activeTo =>
      $composableBuilder(column: $table.activeTo, builder: (column) => column);
}

class $$StaffColumnsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $StaffColumnsTable,
    StaffColumn,
    $$StaffColumnsTableFilterComposer,
    $$StaffColumnsTableOrderingComposer,
    $$StaffColumnsTableAnnotationComposer,
    $$StaffColumnsTableCreateCompanionBuilder,
    $$StaffColumnsTableUpdateCompanionBuilder,
    (
      StaffColumn,
      BaseReferences<_$AppDatabase, $StaffColumnsTable, StaffColumn>
    ),
    StaffColumn,
    PrefetchHooks Function()> {
  $$StaffColumnsTableTableManager(_$AppDatabase db, $StaffColumnsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$StaffColumnsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$StaffColumnsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$StaffColumnsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> displayName = const Value.absent(),
            Value<String> profession = const Value.absent(),
            Value<int> orderIndex = const Value.absent(),
            Value<DateTime> activeFrom = const Value.absent(),
            Value<DateTime?> activeTo = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StaffColumnsCompanion(
            id: id,
            salonId: salonId,
            userId: userId,
            displayName: displayName,
            profession: profession,
            orderIndex: orderIndex,
            activeFrom: activeFrom,
            activeTo: activeTo,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required String userId,
            required String displayName,
            required String profession,
            Value<int> orderIndex = const Value.absent(),
            required DateTime activeFrom,
            Value<DateTime?> activeTo = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              StaffColumnsCompanion.insert(
            id: id,
            salonId: salonId,
            userId: userId,
            displayName: displayName,
            profession: profession,
            orderIndex: orderIndex,
            activeFrom: activeFrom,
            activeTo: activeTo,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$StaffColumnsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $StaffColumnsTable,
    StaffColumn,
    $$StaffColumnsTableFilterComposer,
    $$StaffColumnsTableOrderingComposer,
    $$StaffColumnsTableAnnotationComposer,
    $$StaffColumnsTableCreateCompanionBuilder,
    $$StaffColumnsTableUpdateCompanionBuilder,
    (
      StaffColumn,
      BaseReferences<_$AppDatabase, $StaffColumnsTable, StaffColumn>
    ),
    StaffColumn,
    PrefetchHooks Function()>;
typedef $$WorkDaysTableCreateCompanionBuilder = WorkDaysCompanion Function({
  required String id,
  required String salonId,
  required DateTime date,
  Value<String> currencyCode,
  Value<int> rowid,
});
typedef $$WorkDaysTableUpdateCompanionBuilder = WorkDaysCompanion Function({
  Value<String> id,
  Value<String> salonId,
  Value<DateTime> date,
  Value<String> currencyCode,
  Value<int> rowid,
});

class $$WorkDaysTableFilterComposer
    extends Composer<_$AppDatabase, $WorkDaysTable> {
  $$WorkDaysTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get date => $composableBuilder(
      column: $table.date, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get currencyCode => $composableBuilder(
      column: $table.currencyCode, builder: (column) => ColumnFilters(column));
}

class $$WorkDaysTableOrderingComposer
    extends Composer<_$AppDatabase, $WorkDaysTable> {
  $$WorkDaysTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get date => $composableBuilder(
      column: $table.date, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get currencyCode => $composableBuilder(
      column: $table.currencyCode,
      builder: (column) => ColumnOrderings(column));
}

class $$WorkDaysTableAnnotationComposer
    extends Composer<_$AppDatabase, $WorkDaysTable> {
  $$WorkDaysTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<DateTime> get date =>
      $composableBuilder(column: $table.date, builder: (column) => column);

  GeneratedColumn<String> get currencyCode => $composableBuilder(
      column: $table.currencyCode, builder: (column) => column);
}

class $$WorkDaysTableTableManager extends RootTableManager<
    _$AppDatabase,
    $WorkDaysTable,
    WorkDay,
    $$WorkDaysTableFilterComposer,
    $$WorkDaysTableOrderingComposer,
    $$WorkDaysTableAnnotationComposer,
    $$WorkDaysTableCreateCompanionBuilder,
    $$WorkDaysTableUpdateCompanionBuilder,
    (WorkDay, BaseReferences<_$AppDatabase, $WorkDaysTable, WorkDay>),
    WorkDay,
    PrefetchHooks Function()> {
  $$WorkDaysTableTableManager(_$AppDatabase db, $WorkDaysTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$WorkDaysTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$WorkDaysTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$WorkDaysTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<DateTime> date = const Value.absent(),
            Value<String> currencyCode = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              WorkDaysCompanion(
            id: id,
            salonId: salonId,
            date: date,
            currencyCode: currencyCode,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required DateTime date,
            Value<String> currencyCode = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              WorkDaysCompanion.insert(
            id: id,
            salonId: salonId,
            date: date,
            currencyCode: currencyCode,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$WorkDaysTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $WorkDaysTable,
    WorkDay,
    $$WorkDaysTableFilterComposer,
    $$WorkDaysTableOrderingComposer,
    $$WorkDaysTableAnnotationComposer,
    $$WorkDaysTableCreateCompanionBuilder,
    $$WorkDaysTableUpdateCompanionBuilder,
    (WorkDay, BaseReferences<_$AppDatabase, $WorkDaysTable, WorkDay>),
    WorkDay,
    PrefetchHooks Function()>;
typedef $$TimeSlotEntriesTableCreateCompanionBuilder = TimeSlotEntriesCompanion
    Function({
  required String id,
  required String salonId,
  required String workDayId,
  required String staffColumnId,
  required int slotMinute,
  Value<bool> locked,
  Value<DateTime?> confirmedAt,
  Value<String?> confirmedByUserId,
  required DateTime createdAt,
  required DateTime updatedAt,
  Value<int> rowid,
});
typedef $$TimeSlotEntriesTableUpdateCompanionBuilder = TimeSlotEntriesCompanion
    Function({
  Value<String> id,
  Value<String> salonId,
  Value<String> workDayId,
  Value<String> staffColumnId,
  Value<int> slotMinute,
  Value<bool> locked,
  Value<DateTime?> confirmedAt,
  Value<String?> confirmedByUserId,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$TimeSlotEntriesTableFilterComposer
    extends Composer<_$AppDatabase, $TimeSlotEntriesTable> {
  $$TimeSlotEntriesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get workDayId => $composableBuilder(
      column: $table.workDayId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get staffColumnId => $composableBuilder(
      column: $table.staffColumnId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get slotMinute => $composableBuilder(
      column: $table.slotMinute, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get locked => $composableBuilder(
      column: $table.locked, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get confirmedAt => $composableBuilder(
      column: $table.confirmedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get confirmedByUserId => $composableBuilder(
      column: $table.confirmedByUserId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$TimeSlotEntriesTableOrderingComposer
    extends Composer<_$AppDatabase, $TimeSlotEntriesTable> {
  $$TimeSlotEntriesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get workDayId => $composableBuilder(
      column: $table.workDayId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get staffColumnId => $composableBuilder(
      column: $table.staffColumnId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get slotMinute => $composableBuilder(
      column: $table.slotMinute, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get locked => $composableBuilder(
      column: $table.locked, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get confirmedAt => $composableBuilder(
      column: $table.confirmedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get confirmedByUserId => $composableBuilder(
      column: $table.confirmedByUserId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$TimeSlotEntriesTableAnnotationComposer
    extends Composer<_$AppDatabase, $TimeSlotEntriesTable> {
  $$TimeSlotEntriesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<String> get workDayId =>
      $composableBuilder(column: $table.workDayId, builder: (column) => column);

  GeneratedColumn<String> get staffColumnId => $composableBuilder(
      column: $table.staffColumnId, builder: (column) => column);

  GeneratedColumn<int> get slotMinute => $composableBuilder(
      column: $table.slotMinute, builder: (column) => column);

  GeneratedColumn<bool> get locked =>
      $composableBuilder(column: $table.locked, builder: (column) => column);

  GeneratedColumn<DateTime> get confirmedAt => $composableBuilder(
      column: $table.confirmedAt, builder: (column) => column);

  GeneratedColumn<String> get confirmedByUserId => $composableBuilder(
      column: $table.confirmedByUserId, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$TimeSlotEntriesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $TimeSlotEntriesTable,
    TimeSlotEntry,
    $$TimeSlotEntriesTableFilterComposer,
    $$TimeSlotEntriesTableOrderingComposer,
    $$TimeSlotEntriesTableAnnotationComposer,
    $$TimeSlotEntriesTableCreateCompanionBuilder,
    $$TimeSlotEntriesTableUpdateCompanionBuilder,
    (
      TimeSlotEntry,
      BaseReferences<_$AppDatabase, $TimeSlotEntriesTable, TimeSlotEntry>
    ),
    TimeSlotEntry,
    PrefetchHooks Function()> {
  $$TimeSlotEntriesTableTableManager(
      _$AppDatabase db, $TimeSlotEntriesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TimeSlotEntriesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TimeSlotEntriesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TimeSlotEntriesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<String> workDayId = const Value.absent(),
            Value<String> staffColumnId = const Value.absent(),
            Value<int> slotMinute = const Value.absent(),
            Value<bool> locked = const Value.absent(),
            Value<DateTime?> confirmedAt = const Value.absent(),
            Value<String?> confirmedByUserId = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              TimeSlotEntriesCompanion(
            id: id,
            salonId: salonId,
            workDayId: workDayId,
            staffColumnId: staffColumnId,
            slotMinute: slotMinute,
            locked: locked,
            confirmedAt: confirmedAt,
            confirmedByUserId: confirmedByUserId,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required String workDayId,
            required String staffColumnId,
            required int slotMinute,
            Value<bool> locked = const Value.absent(),
            Value<DateTime?> confirmedAt = const Value.absent(),
            Value<String?> confirmedByUserId = const Value.absent(),
            required DateTime createdAt,
            required DateTime updatedAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              TimeSlotEntriesCompanion.insert(
            id: id,
            salonId: salonId,
            workDayId: workDayId,
            staffColumnId: staffColumnId,
            slotMinute: slotMinute,
            locked: locked,
            confirmedAt: confirmedAt,
            confirmedByUserId: confirmedByUserId,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$TimeSlotEntriesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $TimeSlotEntriesTable,
    TimeSlotEntry,
    $$TimeSlotEntriesTableFilterComposer,
    $$TimeSlotEntriesTableOrderingComposer,
    $$TimeSlotEntriesTableAnnotationComposer,
    $$TimeSlotEntriesTableCreateCompanionBuilder,
    $$TimeSlotEntriesTableUpdateCompanionBuilder,
    (
      TimeSlotEntry,
      BaseReferences<_$AppDatabase, $TimeSlotEntriesTable, TimeSlotEntry>
    ),
    TimeSlotEntry,
    PrefetchHooks Function()>;
typedef $$EntryMoneyTableCreateCompanionBuilder = EntryMoneyCompanion Function({
  required String entryId,
  Value<double> servicesTotal,
  Value<double> productsTotal,
  Value<String> currencyCode,
  Value<int> rowid,
});
typedef $$EntryMoneyTableUpdateCompanionBuilder = EntryMoneyCompanion Function({
  Value<String> entryId,
  Value<double> servicesTotal,
  Value<double> productsTotal,
  Value<String> currencyCode,
  Value<int> rowid,
});

class $$EntryMoneyTableFilterComposer
    extends Composer<_$AppDatabase, $EntryMoneyTable> {
  $$EntryMoneyTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get entryId => $composableBuilder(
      column: $table.entryId, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get servicesTotal => $composableBuilder(
      column: $table.servicesTotal, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get productsTotal => $composableBuilder(
      column: $table.productsTotal, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get currencyCode => $composableBuilder(
      column: $table.currencyCode, builder: (column) => ColumnFilters(column));
}

class $$EntryMoneyTableOrderingComposer
    extends Composer<_$AppDatabase, $EntryMoneyTable> {
  $$EntryMoneyTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get entryId => $composableBuilder(
      column: $table.entryId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get servicesTotal => $composableBuilder(
      column: $table.servicesTotal,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get productsTotal => $composableBuilder(
      column: $table.productsTotal,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get currencyCode => $composableBuilder(
      column: $table.currencyCode,
      builder: (column) => ColumnOrderings(column));
}

class $$EntryMoneyTableAnnotationComposer
    extends Composer<_$AppDatabase, $EntryMoneyTable> {
  $$EntryMoneyTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get entryId =>
      $composableBuilder(column: $table.entryId, builder: (column) => column);

  GeneratedColumn<double> get servicesTotal => $composableBuilder(
      column: $table.servicesTotal, builder: (column) => column);

  GeneratedColumn<double> get productsTotal => $composableBuilder(
      column: $table.productsTotal, builder: (column) => column);

  GeneratedColumn<String> get currencyCode => $composableBuilder(
      column: $table.currencyCode, builder: (column) => column);
}

class $$EntryMoneyTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EntryMoneyTable,
    EntryMoneyData,
    $$EntryMoneyTableFilterComposer,
    $$EntryMoneyTableOrderingComposer,
    $$EntryMoneyTableAnnotationComposer,
    $$EntryMoneyTableCreateCompanionBuilder,
    $$EntryMoneyTableUpdateCompanionBuilder,
    (
      EntryMoneyData,
      BaseReferences<_$AppDatabase, $EntryMoneyTable, EntryMoneyData>
    ),
    EntryMoneyData,
    PrefetchHooks Function()> {
  $$EntryMoneyTableTableManager(_$AppDatabase db, $EntryMoneyTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EntryMoneyTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EntryMoneyTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EntryMoneyTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> entryId = const Value.absent(),
            Value<double> servicesTotal = const Value.absent(),
            Value<double> productsTotal = const Value.absent(),
            Value<String> currencyCode = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EntryMoneyCompanion(
            entryId: entryId,
            servicesTotal: servicesTotal,
            productsTotal: productsTotal,
            currencyCode: currencyCode,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String entryId,
            Value<double> servicesTotal = const Value.absent(),
            Value<double> productsTotal = const Value.absent(),
            Value<String> currencyCode = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EntryMoneyCompanion.insert(
            entryId: entryId,
            servicesTotal: servicesTotal,
            productsTotal: productsTotal,
            currencyCode: currencyCode,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EntryMoneyTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EntryMoneyTable,
    EntryMoneyData,
    $$EntryMoneyTableFilterComposer,
    $$EntryMoneyTableOrderingComposer,
    $$EntryMoneyTableAnnotationComposer,
    $$EntryMoneyTableCreateCompanionBuilder,
    $$EntryMoneyTableUpdateCompanionBuilder,
    (
      EntryMoneyData,
      BaseReferences<_$AppDatabase, $EntryMoneyTable, EntryMoneyData>
    ),
    EntryMoneyData,
    PrefetchHooks Function()>;
typedef $$CatalogItemsTableCreateCompanionBuilder = CatalogItemsCompanion
    Function({
  required String id,
  required String salonId,
  required String type,
  required String category,
  required String profession,
  required String name,
  Value<double?> defaultPrice,
  Value<int> orderIndex,
  Value<bool> isActive,
  Value<int> rowid,
});
typedef $$CatalogItemsTableUpdateCompanionBuilder = CatalogItemsCompanion
    Function({
  Value<String> id,
  Value<String> salonId,
  Value<String> type,
  Value<String> category,
  Value<String> profession,
  Value<String> name,
  Value<double?> defaultPrice,
  Value<int> orderIndex,
  Value<bool> isActive,
  Value<int> rowid,
});

class $$CatalogItemsTableFilterComposer
    extends Composer<_$AppDatabase, $CatalogItemsTable> {
  $$CatalogItemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get profession => $composableBuilder(
      column: $table.profession, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get defaultPrice => $composableBuilder(
      column: $table.defaultPrice, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));
}

class $$CatalogItemsTableOrderingComposer
    extends Composer<_$AppDatabase, $CatalogItemsTable> {
  $$CatalogItemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get profession => $composableBuilder(
      column: $table.profession, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get defaultPrice => $composableBuilder(
      column: $table.defaultPrice,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));
}

class $$CatalogItemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $CatalogItemsTable> {
  $$CatalogItemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get category =>
      $composableBuilder(column: $table.category, builder: (column) => column);

  GeneratedColumn<String> get profession => $composableBuilder(
      column: $table.profession, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<double> get defaultPrice => $composableBuilder(
      column: $table.defaultPrice, builder: (column) => column);

  GeneratedColumn<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);
}

class $$CatalogItemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CatalogItemsTable,
    CatalogItem,
    $$CatalogItemsTableFilterComposer,
    $$CatalogItemsTableOrderingComposer,
    $$CatalogItemsTableAnnotationComposer,
    $$CatalogItemsTableCreateCompanionBuilder,
    $$CatalogItemsTableUpdateCompanionBuilder,
    (
      CatalogItem,
      BaseReferences<_$AppDatabase, $CatalogItemsTable, CatalogItem>
    ),
    CatalogItem,
    PrefetchHooks Function()> {
  $$CatalogItemsTableTableManager(_$AppDatabase db, $CatalogItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CatalogItemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CatalogItemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CatalogItemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<String> category = const Value.absent(),
            Value<String> profession = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<double?> defaultPrice = const Value.absent(),
            Value<int> orderIndex = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CatalogItemsCompanion(
            id: id,
            salonId: salonId,
            type: type,
            category: category,
            profession: profession,
            name: name,
            defaultPrice: defaultPrice,
            orderIndex: orderIndex,
            isActive: isActive,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required String type,
            required String category,
            required String profession,
            required String name,
            Value<double?> defaultPrice = const Value.absent(),
            Value<int> orderIndex = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CatalogItemsCompanion.insert(
            id: id,
            salonId: salonId,
            type: type,
            category: category,
            profession: profession,
            name: name,
            defaultPrice: defaultPrice,
            orderIndex: orderIndex,
            isActive: isActive,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$CatalogItemsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CatalogItemsTable,
    CatalogItem,
    $$CatalogItemsTableFilterComposer,
    $$CatalogItemsTableOrderingComposer,
    $$CatalogItemsTableAnnotationComposer,
    $$CatalogItemsTableCreateCompanionBuilder,
    $$CatalogItemsTableUpdateCompanionBuilder,
    (
      CatalogItem,
      BaseReferences<_$AppDatabase, $CatalogItemsTable, CatalogItem>
    ),
    CatalogItem,
    PrefetchHooks Function()>;
typedef $$AttributeOptionsTableCreateCompanionBuilder
    = AttributeOptionsCompanion Function({
  required String id,
  required String salonId,
  required String type,
  required String value,
  Value<int> orderIndex,
  Value<bool> isActive,
  Value<int> rowid,
});
typedef $$AttributeOptionsTableUpdateCompanionBuilder
    = AttributeOptionsCompanion Function({
  Value<String> id,
  Value<String> salonId,
  Value<String> type,
  Value<String> value,
  Value<int> orderIndex,
  Value<bool> isActive,
  Value<int> rowid,
});

class $$AttributeOptionsTableFilterComposer
    extends Composer<_$AppDatabase, $AttributeOptionsTable> {
  $$AttributeOptionsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));
}

class $$AttributeOptionsTableOrderingComposer
    extends Composer<_$AppDatabase, $AttributeOptionsTable> {
  $$AttributeOptionsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get salonId => $composableBuilder(
      column: $table.salonId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));
}

class $$AttributeOptionsTableAnnotationComposer
    extends Composer<_$AppDatabase, $AttributeOptionsTable> {
  $$AttributeOptionsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get salonId =>
      $composableBuilder(column: $table.salonId, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get value =>
      $composableBuilder(column: $table.value, builder: (column) => column);

  GeneratedColumn<int> get orderIndex => $composableBuilder(
      column: $table.orderIndex, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);
}

class $$AttributeOptionsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AttributeOptionsTable,
    AttributeOption,
    $$AttributeOptionsTableFilterComposer,
    $$AttributeOptionsTableOrderingComposer,
    $$AttributeOptionsTableAnnotationComposer,
    $$AttributeOptionsTableCreateCompanionBuilder,
    $$AttributeOptionsTableUpdateCompanionBuilder,
    (
      AttributeOption,
      BaseReferences<_$AppDatabase, $AttributeOptionsTable, AttributeOption>
    ),
    AttributeOption,
    PrefetchHooks Function()> {
  $$AttributeOptionsTableTableManager(
      _$AppDatabase db, $AttributeOptionsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AttributeOptionsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AttributeOptionsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AttributeOptionsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> salonId = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<String> value = const Value.absent(),
            Value<int> orderIndex = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AttributeOptionsCompanion(
            id: id,
            salonId: salonId,
            type: type,
            value: value,
            orderIndex: orderIndex,
            isActive: isActive,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String salonId,
            required String type,
            required String value,
            Value<int> orderIndex = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AttributeOptionsCompanion.insert(
            id: id,
            salonId: salonId,
            type: type,
            value: value,
            orderIndex: orderIndex,
            isActive: isActive,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$AttributeOptionsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $AttributeOptionsTable,
    AttributeOption,
    $$AttributeOptionsTableFilterComposer,
    $$AttributeOptionsTableOrderingComposer,
    $$AttributeOptionsTableAnnotationComposer,
    $$AttributeOptionsTableCreateCompanionBuilder,
    $$AttributeOptionsTableUpdateCompanionBuilder,
    (
      AttributeOption,
      BaseReferences<_$AppDatabase, $AttributeOptionsTable, AttributeOption>
    ),
    AttributeOption,
    PrefetchHooks Function()>;
typedef $$EntryLinesTableCreateCompanionBuilder = EntryLinesCompanion Function({
  required String id,
  required String entryId,
  required String catalogItemId,
  required String lineType,
  Value<int> qty,
  Value<String?> metaJson,
  required DateTime createdAt,
  Value<int> rowid,
});
typedef $$EntryLinesTableUpdateCompanionBuilder = EntryLinesCompanion Function({
  Value<String> id,
  Value<String> entryId,
  Value<String> catalogItemId,
  Value<String> lineType,
  Value<int> qty,
  Value<String?> metaJson,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$EntryLinesTableFilterComposer
    extends Composer<_$AppDatabase, $EntryLinesTable> {
  $$EntryLinesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entryId => $composableBuilder(
      column: $table.entryId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get catalogItemId => $composableBuilder(
      column: $table.catalogItemId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lineType => $composableBuilder(
      column: $table.lineType, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get qty => $composableBuilder(
      column: $table.qty, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get metaJson => $composableBuilder(
      column: $table.metaJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$EntryLinesTableOrderingComposer
    extends Composer<_$AppDatabase, $EntryLinesTable> {
  $$EntryLinesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entryId => $composableBuilder(
      column: $table.entryId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get catalogItemId => $composableBuilder(
      column: $table.catalogItemId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lineType => $composableBuilder(
      column: $table.lineType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get qty => $composableBuilder(
      column: $table.qty, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get metaJson => $composableBuilder(
      column: $table.metaJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$EntryLinesTableAnnotationComposer
    extends Composer<_$AppDatabase, $EntryLinesTable> {
  $$EntryLinesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get entryId =>
      $composableBuilder(column: $table.entryId, builder: (column) => column);

  GeneratedColumn<String> get catalogItemId => $composableBuilder(
      column: $table.catalogItemId, builder: (column) => column);

  GeneratedColumn<String> get lineType =>
      $composableBuilder(column: $table.lineType, builder: (column) => column);

  GeneratedColumn<int> get qty =>
      $composableBuilder(column: $table.qty, builder: (column) => column);

  GeneratedColumn<String> get metaJson =>
      $composableBuilder(column: $table.metaJson, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$EntryLinesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EntryLinesTable,
    EntryLine,
    $$EntryLinesTableFilterComposer,
    $$EntryLinesTableOrderingComposer,
    $$EntryLinesTableAnnotationComposer,
    $$EntryLinesTableCreateCompanionBuilder,
    $$EntryLinesTableUpdateCompanionBuilder,
    (EntryLine, BaseReferences<_$AppDatabase, $EntryLinesTable, EntryLine>),
    EntryLine,
    PrefetchHooks Function()> {
  $$EntryLinesTableTableManager(_$AppDatabase db, $EntryLinesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EntryLinesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EntryLinesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EntryLinesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> entryId = const Value.absent(),
            Value<String> catalogItemId = const Value.absent(),
            Value<String> lineType = const Value.absent(),
            Value<int> qty = const Value.absent(),
            Value<String?> metaJson = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EntryLinesCompanion(
            id: id,
            entryId: entryId,
            catalogItemId: catalogItemId,
            lineType: lineType,
            qty: qty,
            metaJson: metaJson,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String entryId,
            required String catalogItemId,
            required String lineType,
            Value<int> qty = const Value.absent(),
            Value<String?> metaJson = const Value.absent(),
            required DateTime createdAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              EntryLinesCompanion.insert(
            id: id,
            entryId: entryId,
            catalogItemId: catalogItemId,
            lineType: lineType,
            qty: qty,
            metaJson: metaJson,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EntryLinesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EntryLinesTable,
    EntryLine,
    $$EntryLinesTableFilterComposer,
    $$EntryLinesTableOrderingComposer,
    $$EntryLinesTableAnnotationComposer,
    $$EntryLinesTableCreateCompanionBuilder,
    $$EntryLinesTableUpdateCompanionBuilder,
    (EntryLine, BaseReferences<_$AppDatabase, $EntryLinesTable, EntryLine>),
    EntryLine,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$SalonsTableTableManager get salons =>
      $$SalonsTableTableManager(_db, _db.salons);
  $$UsersTableTableManager get users =>
      $$UsersTableTableManager(_db, _db.users);
  $$SyncOutboxTableTableManager get syncOutbox =>
      $$SyncOutboxTableTableManager(_db, _db.syncOutbox);
  $$SyncStateTableTableManager get syncState =>
      $$SyncStateTableTableManager(_db, _db.syncState);
  $$SalonSettingsTableTableManager get salonSettings =>
      $$SalonSettingsTableTableManager(_db, _db.salonSettings);
  $$SalonWorkHoursTableTableManager get salonWorkHours =>
      $$SalonWorkHoursTableTableManager(_db, _db.salonWorkHours);
  $$StaffColumnsTableTableManager get staffColumns =>
      $$StaffColumnsTableTableManager(_db, _db.staffColumns);
  $$WorkDaysTableTableManager get workDays =>
      $$WorkDaysTableTableManager(_db, _db.workDays);
  $$TimeSlotEntriesTableTableManager get timeSlotEntries =>
      $$TimeSlotEntriesTableTableManager(_db, _db.timeSlotEntries);
  $$EntryMoneyTableTableManager get entryMoney =>
      $$EntryMoneyTableTableManager(_db, _db.entryMoney);
  $$CatalogItemsTableTableManager get catalogItems =>
      $$CatalogItemsTableTableManager(_db, _db.catalogItems);
  $$AttributeOptionsTableTableManager get attributeOptions =>
      $$AttributeOptionsTableTableManager(_db, _db.attributeOptions);
  $$EntryLinesTableTableManager get entryLines =>
      $$EntryLinesTableTableManager(_db, _db.entryLines);
}
