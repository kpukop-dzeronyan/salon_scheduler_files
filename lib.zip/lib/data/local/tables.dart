import 'package:drift/drift.dart';

class SalonSettings extends Table {
  TextColumn get salonId => text()();
  // Legacy single interval for the whole day. Kept for migrations/backfill.
  IntColumn get dayStartMinute => integer()();
  IntColumn get dayEndMinute => integer()();
  IntColumn get slotMinutes => integer()();
  @override
  Set<Column> get primaryKey => {salonId};
}

/// Per-salon working hours, per weekday.
/// weekday follows Dart's DateTime.weekday: 1=Mon ... 7=Sun
class SalonWorkHours extends Table {
  TextColumn get id => text()(); // e.g. wh-<salonId>-<weekday>
  TextColumn get salonId => text()();
  IntColumn get weekday => integer()();
  IntColumn get startMinute => integer()();
  IntColumn get endMinute => integer()();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {salonId, weekday},
      ];
}

class StaffColumns extends Table {
  TextColumn get id => text()();
  TextColumn get salonId => text()();
  TextColumn get userId => text()();
  TextColumn get displayName => text()();
  TextColumn get profession => text()(); // hairdresser/manicurist
  IntColumn get orderIndex => integer().withDefault(const Constant(0))();
  DateTimeColumn get activeFrom => dateTime()();
  DateTimeColumn get activeTo => dateTime().nullable()(); // exclusive
  @override
  Set<Column> get primaryKey => {id};
}

class WorkDays extends Table {
  TextColumn get id => text()();
  TextColumn get salonId => text()();
  DateTimeColumn get date => dateTime()(); // dateOnly
  TextColumn get currencyCode => text().withDefault(const Constant('EUR'))();
  @override
  Set<Column> get primaryKey => {id};
}

class TimeSlotEntries extends Table {
  TextColumn get id => text()();
  TextColumn get salonId => text()();
  TextColumn get workDayId => text()();
  TextColumn get staffColumnId => text()();
  IntColumn get slotMinute => integer()(); // 0..1439
  BoolColumn get locked => boolean().withDefault(const Constant(false))();
  DateTimeColumn get confirmedAt => dateTime().nullable()();
  TextColumn get confirmedByUserId => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
  @override
  Set<Column> get primaryKey => {id};
}

class EntryMoney extends Table {
  TextColumn get entryId => text()(); // PK/FK
  RealColumn get servicesTotal => real().withDefault(const Constant(0.0))();
  RealColumn get productsTotal => real().withDefault(const Constant(0.0))();
  TextColumn get currencyCode => text().withDefault(const Constant('EUR'))();
  @override
  Set<Column> get primaryKey => {entryId};
}

// Auth + salons

class Salons extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  @override
  Set<Column> get primaryKey => {id};
}

class Users extends Table {
  TextColumn get id => text()();
  TextColumn get salonId => text()();
  TextColumn get username => text()(); // unique per salon (Cyrillic ok)
  TextColumn get usernameNorm => text().nullable()(); // normalized for login (lowercased in Dart)
  TextColumn get password => text()(); // demo only
  /// Soft-disable. Inactive users cannot login and their staff column is hidden.
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  BoolColumn get isAdmin => boolean().withDefault(const Constant(false))();
  @override
  Set<Column> get primaryKey => {id};

  // IMPORTANT:
  // We intentionally do NOT enforce a unique constraint for (salonId, username)
  // at the database level because we want to allow reusing the same username
  // after an older user becomes inactive.
  // Uniqueness is enforced in Dart only for active users:
  //   SELECT count(*) FROM users WHERE username_norm=? AND salon_id=? AND is_active=1
}

// Catalog + lines

class CatalogItems extends Table {
  TextColumn get id => text()();
  TextColumn get salonId => text()();
  TextColumn get type => text()(); // service/product
  TextColumn get category => text()();
  TextColumn get profession => text()(); // hairdresser/manicurist
  TextColumn get name => text()();
  RealColumn get defaultPrice => real().nullable()();
  IntColumn get orderIndex => integer().withDefault(const Constant(0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  @override
  Set<Column> get primaryKey => {id};
}

class AttributeOptions extends Table {
  TextColumn get id => text()();
  TextColumn get salonId => text()();
  TextColumn get type => text()(); // dye_code/crystal_name
  TextColumn get value => text()();
  IntColumn get orderIndex => integer().withDefault(const Constant(0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  @override
  Set<Column> get primaryKey => {id};
}

class EntryLines extends Table {
  TextColumn get id => text()();
  TextColumn get entryId => text()();
  TextColumn get catalogItemId => text()();
  TextColumn get lineType => text()(); // service/product
  IntColumn get qty => integer().withDefault(const Constant(1))();
  TextColumn get metaJson => text().nullable()();
  DateTimeColumn get createdAt => dateTime()();
  @override
  Set<Column> get primaryKey => {id};
}
