import 'dart:convert';
import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart';

import 'tables.dart';
import 'sync_tables.dart';
import 'package:uuid/uuid.dart';

import '../../services/sync_service.dart';

part 'app_db.g.dart';

class TimeSlotEntryWithMoney {
  final TimeSlotEntry entry;
  final EntryMoneyData? money;
  const TimeSlotEntryWithMoney(this.entry, this.money);
}

class LineDraft {
  final String id;
  final String catalogItemId;
  final String lineType; // 'service' / 'product'
  final int qty;
  final String? metaJson;

  const LineDraft({
    required this.id,
    required this.catalogItemId,
    required this.lineType,
    this.qty = 1,
    this.metaJson,
  });
}
class EntryEditorData {
  final TimeSlotEntry? entry;
  final EntryMoneyData? money;
  final List<EntryLine> lines;
  const EntryEditorData({
    required this.entry,
    required this.money,
    required this.lines,
  });
}





/// Lightweight DTO used for rendering entry "pills" in the schedule grid.
class EntryLineDisplay {
  final String name;
  final String lineType; // 'service' / 'product'
  final String? variant; // e.g. hair color code like "7.1"

  const EntryLineDisplay({
    required this.name,
    required this.lineType,
    this.variant,
  });
}

/// Map keyed by entryId -> list of display lines.
typedef WorkDayEntryLineMap = Map<String, List<EntryLineDisplay>>;

@DriftDatabase(tables: [
  // Auth / base
  Salons,
  Users,

  // Sync
  SyncOutbox,
  SyncState,

  // Schedule core
  SalonSettings,
  SalonWorkHours,
  StaffColumns,
  WorkDays,
  TimeSlotEntries,
  EntryMoney,

  // Catalog / lines
  CatalogItems,
  AttributeOptions,
  EntryLines,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  static const String globalSalonId = 'GLOBAL';

  @override
  int get schemaVersion => 10;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await m.createAll();
        },
        onUpgrade: (m, from, to) async {
          // NOTE: For development we usually reinstall the app / clear storage.
          // Still, keep a simple forward-only migration for missing tables.
          if (from < 2) {
            await m.createTable(catalogItems);
            await m.createTable(attributeOptions);
            await m.createTable(entryLines);
          }
          if (from < 3) {
            await m.createTable(salons);
            await m.createTable(users);
          }
          // from < 4: no structural change that needs SQL here (uniqueKeys are applied on create).
          if (from < 5) {
            await m.addColumn(users, users.usernameNorm);
          }
          if (from < 6) {
            await m.createTable(salonWorkHours);
            // Backfill work hours from legacy single-interval settings.
            final settingsRows = await customSelect(
              'SELECT salon_id, day_start_minute, day_end_minute FROM salon_settings',
              readsFrom: {salonSettings},
            ).get();

            for (final r in settingsRows) {
              final salonId = r.read<String>('salon_id');
              final start = r.read<int>('day_start_minute');
              final end = r.read<int>('day_end_minute');
              for (var weekday = 1; weekday <= 7; weekday++) {
                await into(salonWorkHours).insertOnConflictUpdate(
                  SalonWorkHoursCompanion.insert(
                    id: 'wh-$salonId-$weekday',
                    salonId: salonId,
                    weekday: weekday,
                    startMinute: start,
                    endMinute: end,
                  ),
                );
              }
            }
          }

          if (from < 7) {
            // Add soft-active flag for users.
            await m.addColumn(users, users.isActive);

            // Drop the old UNIQUE(salon_id, username) constraint/index if it exists.
            // We now allow reusing usernames after a user becomes inactive.
            try {
              final idx = await customSelect("PRAGMA index_list('users')").get();
              for (final r in idx) {
                final name = r.read<String>('name');
                final unique = r.read<int>('unique');
                if (unique != 1) continue;
                final info = await customSelect("PRAGMA index_info('$name')").get();
                final cols = info.map((e) => e.read<String>('name')).toList();
                if (cols.length == 2 && cols.contains('salon_id') && cols.contains('username')) {
                  await customStatement('DROP INDEX IF EXISTS "$name"');
                }
              }
            } catch (_) {
              // Ignore; some sqlite builds / drift versions may differ.
            }
          }

          if (from < 8) {
            await transaction(() async {
              // 1) Renumber salons to simple numeric ids: "1", "2", ...
              final salonsRows = await customSelect(
                'SELECT rowid AS rid, id FROM salons ORDER BY rid ASC',
                readsFrom: {salons},
              ).get();

              final allNumeric = salonsRows.every((r) => int.tryParse(r.read<String>('id')) != null);
              if (!allNumeric) {
                final mapping = <String, String>{};
                var next = 1;
                for (final r in salonsRows) {
                  final oldId = r.read<String>('id');
                  mapping[oldId] = next.toString();
                  next++;
                }

                for (final e in mapping.entries) {
                  final oldId = e.key;
                  final newId = e.value;
                  await customStatement('UPDATE salons SET id = ? WHERE id = ?', [newId, oldId]);
                  await customStatement('UPDATE users SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE staff_columns SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE work_days SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE time_slot_entries SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE salon_settings SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE salon_work_hours SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE catalog_items SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                  await customStatement('UPDATE attribute_options SET salon_id = ? WHERE salon_id = ?', [newId, oldId]);
                }
              }

              // 2) Professions: move from GLOBAL to per-salon scope.
              final globalProf = await (select(attributeOptions)
                    ..where((t) => t.salonId.equals(globalSalonId) & t.type.equals('profession'))
                    ..orderBy([
                      (t) => OrderingTerm(expression: t.orderIndex),
                      (t) => OrderingTerm(expression: t.value),
                    ]))
                  .get();

              final salonList = await (select(salons)..orderBy([(t) => OrderingTerm(expression: t.id)])).get();
              for (final s in salonList) {
                final hasAny = await (select(attributeOptions)
                      ..where((t) => t.salonId.equals(s.id) & t.type.equals('profession'))
                      ..limit(1))
                    .getSingleOrNull();
                if (hasAny != null) continue;

                if (globalProf.isNotEmpty) {
                  for (final p in globalProf) {
                    await into(attributeOptions).insertOnConflictUpdate(
                      AttributeOptionsCompanion.insert(
                        id: 'prof-${s.id}-${p.orderIndex}-${p.value}',
                        salonId: s.id,
                        type: 'profession',
                        value: p.value,
                        orderIndex: Value(p.orderIndex),
                        isActive: Value(p.isActive),
                      ),
                    );
                  }
                } else {
                  await into(attributeOptions).insertOnConflictUpdate(
                    AttributeOptionsCompanion.insert(
                      id: 'prof-${s.id}-1',
                      salonId: s.id,
                      type: 'profession',
                      value: 'Професия 1',
                      orderIndex: const Value(1),
                      isActive: const Value(true),
                    ),
                  );
                  await into(attributeOptions).insertOnConflictUpdate(
                    AttributeOptionsCompanion.insert(
                      id: 'prof-${s.id}-2',
                      salonId: s.id,
                      type: 'profession',
                      value: 'Професия 2',
                      orderIndex: const Value(2),
                      isActive: const Value(true),
                    ),
                  );
                }
              }

              // 3) Legacy profession-code normalization removed.
              // Professions are now treated as free-form strings and must be preserved as entered.
            });
          }

          if (from < 9) {
            await m.createTable(syncOutbox);
            await m.createTable(syncState);
          }

          if (from < 10) {
            // Migrate local synthetic ids to UUIDs for users and catalog items.
            // This prevents sync mismatches (e.g. u-*, ser-*, pro-*) and allows us to use the same ids as the server.
            // NOTE: If you have pending items in syncOutbox referencing old ids, clear the outbox before upgrading.
            await transaction(() async {
              const uuid = Uuid();

              bool _isUuid(String s) {
                final r = RegExp(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$');
                return r.hasMatch(s);
              }

              // --- Users: migrate ids like "u-..." to UUIDs and update staff columns + confirmations.
              final userRows = await select(users).get();
              final userMap = <String, String>{}; // old -> new
              for (final u in userRows) {
                final oldId = u.id;
                if (_isUuid(oldId)) continue;
                userMap[oldId] = uuid.v4();
              }

              for (final e in userMap.entries) {
                final oldId = e.key;
                final newId = e.value;

                await customStatement('UPDATE users SET id=? WHERE id=?', [newId, oldId]);

                final scRows = await customSelect(
                  'SELECT id, salon_id FROM staff_columns WHERE user_id=?',
                  variables: [Variable<String>(oldId)],
                  readsFrom: {staffColumns},
                ).get();

                for (final r in scRows) {
                  final oldColId = r.read<String>('id');
                  final salonId = r.read<String>('salon_id');
                  final newColId = 'col-$salonId-$newId';

                  await customStatement('UPDATE staff_columns SET user_id=?, id=? WHERE id=?', [newId, newColId, oldColId]);
                  await customStatement('UPDATE time_slot_entries SET staff_column_id=? WHERE staff_column_id=?', [newColId, oldColId]);
                }

                await customStatement('UPDATE time_slot_entries SET confirmed_by_user_id=? WHERE confirmed_by_user_id=?', [newId, oldId]);
              }

              // --- Catalog items: migrate ids like "ser-*", "pro-*" to UUIDs and update entry lines.
              final catRows = await select(catalogItems).get();
              final catMap = <String, String>{}; // old -> new
              for (final c in catRows) {
                final oldId = c.id;
                if (_isUuid(oldId)) continue;
                catMap[oldId] = uuid.v4();
              }

              for (final e in catMap.entries) {
                final oldId = e.key;
                final newId = e.value;

                await customStatement('UPDATE catalog_items SET id=? WHERE id=?', [newId, oldId]);
                await customStatement('UPDATE entry_lines SET catalog_item_id=? WHERE catalog_item_id=?', [newId, oldId]);
              }
            });
          }

        },
      );

  Future<int> getNextSalonNumber() async {
    final rows = await customSelect('SELECT id FROM salons', readsFrom: {salons}).get();
    var maxId = 0;
    for (final r in rows) {
      final v = int.tryParse(r.read<String>('id'));
      if (v != null && v > maxId) maxId = v;
    }
    return maxId + 1;
  }

  static DateTime dateOnly(DateTime dt) => DateTime(dt.year, dt.month, dt.day);

  static bool isUuidString(String? s) {
    if (s == null) return false;
    final r = RegExp(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$');
    return r.hasMatch(s);
  }

  String _stableUuid(String input) {
    return const Uuid().v5(Uuid.NAMESPACE_URL, 'salon_scheduler:$input');
  }

  Future<String> _ensureCatalogItemUuidById(String id) async {
    if (isUuidString(id)) return id;
    final row = await (select(catalogItems)..where((t) => t.id.equals(id))).getSingleOrNull();
    if (row == null) return id;
    final newId = _stableUuid('catalog_item:${row.salonId}:${row.type}:${row.profession}:${row.name}:$id');
    await transaction(() async {
      await customStatement('UPDATE catalog_items SET id=? WHERE id=?', [newId, id]);
      await customStatement('UPDATE entry_lines SET catalog_item_id=? WHERE catalog_item_id=?', [newId, id]);
    });
    return newId;
  }

  Future<String> _ensureAttributeOptionUuidById(String id) async {
    if (isUuidString(id)) return id;
    final row = await (select(attributeOptions)..where((t) => t.id.equals(id))).getSingleOrNull();
    if (row == null) return id;
    final newId = _stableUuid('attribute_option:${row.salonId}:${row.type}:${row.value}:$id');
    await customStatement('UPDATE attribute_options SET id=? WHERE id=?', [newId, id]);
    return newId;
  }

  // ---------------------------
  // Salons / Auth
  // ---------------------------

  Stream<List<Salon>> watchSalons() {
    final q = select(salons)..orderBy([(t) => OrderingTerm(expression: t.name)]);
    return q.watch();
  }

  Future<Salon?> getSalonById(String salonId) {
    return (select(salons)..where((t) => t.id.equals(salonId))).getSingleOrNull();
  }

  Future<Salon?> getFirstSalon() async {
    final q = select(salons)..orderBy([(t) => OrderingTerm(expression: t.name)]);
    return q.getSingleOrNull();
  }

  Future<List<Salon>> getAllSalons() {
    final q = select(salons)..orderBy([(t) => OrderingTerm(expression: t.name)]);
    return q.get();
  }

  /// Creates a new salon and initializes its settings + work hours.
  ///
  /// If [templateSalonId] is provided (and exists), settings + work hours are copied.
  /// Otherwise we create defaults:
  /// - work hours Mon–Sun: 08:00–22:00
  /// - slotMinutes: 10
  ///
  /// Returns the created [Salon].
  Future<Salon> createSalonWithTemplate({
    required String salonId,
    required String name,
    String? templateSalonId,
  }) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) {
      throw ArgumentError('Salon name cannot be empty');
    }

    final newId = salonId.trim();
    if (newId.isEmpty) {
      throw ArgumentError('Salon id cannot be empty');
    }
    final today = dateOnly(DateTime.now());

    return transaction(() async {
      final exists = await (select(salons)..where((t) => t.id.equals(newId))).getSingleOrNull();
      if (exists != null) {
        throw ArgumentError('Salon id already exists');
      }

      await into(salons).insert(
        SalonsCompanion.insert(id: newId, name: trimmed),
      );

      // Copy settings (slot/dayStart/dayEnd) if possible.
      final tplSettings = (templateSalonId == null)
          ? null
          : await (select(salonSettings)..where((t) => t.salonId.equals(templateSalonId)))
              .getSingleOrNull();

      final settingsRow = SalonSettingsCompanion.insert(
        salonId: newId,
        dayStartMinute: tplSettings?.dayStartMinute ?? 480,
        dayEndMinute: tplSettings?.dayEndMinute ?? 1320,
        slotMinutes: tplSettings?.slotMinutes ?? 10,
      );
      await into(salonSettings).insert(settingsRow);

      // Copy professions (template) or seed defaults.
      if (templateSalonId != null) {
        final tplProf = await (select(attributeOptions)
              ..where((t) => t.salonId.equals(templateSalonId) & t.type.equals('profession'))
              ..orderBy([
                (t) => OrderingTerm(expression: t.orderIndex),
                (t) => OrderingTerm(expression: t.value),
              ]))
            .get();
        for (final p in tplProf) {
          await into(attributeOptions).insertOnConflictUpdate(
            AttributeOptionsCompanion.insert(
              id: 'prof-$newId-${p.orderIndex}-${p.value}',
              salonId: newId,
              type: 'profession',
              value: p.value,
              orderIndex: Value(p.orderIndex),
              isActive: Value(p.isActive),
            ),
          );
        }
      } else {
        // Default professions if salon starts without template.
        await into(attributeOptions).insertOnConflictUpdate(
          AttributeOptionsCompanion.insert(
            id: 'prof-$newId-1',
            salonId: newId,
            type: 'profession',
            value: 'Професия 1',
            orderIndex: const Value(1),
            isActive: const Value(true),
          ),
        );
        await into(attributeOptions).insertOnConflictUpdate(
          AttributeOptionsCompanion.insert(
            id: 'prof-$newId-2',
            salonId: newId,
            type: 'profession',
            value: 'Професия 2',
            orderIndex: const Value(2),
            isActive: const Value(true),
          ),
        );
      }

      // Copy catalog items (services/products) only when a template is selected.
      // When no template: catalog is empty by design.
      if (templateSalonId != null) {
        final tplItems = await (select(catalogItems)
              ..where((t) => t.salonId.equals(templateSalonId))
              ..orderBy([
                (t) => OrderingTerm(expression: t.type),
                (t) => OrderingTerm(expression: t.profession),
                (t) => OrderingTerm(expression: t.orderIndex),
              ]))
            .get();
        for (final it in tplItems) {
          await into(catalogItems).insertOnConflictUpdate(
            CatalogItemsCompanion.insert(
              id: '$newId-${it.id}',
              salonId: newId,
              type: it.type,
              category: it.category,
              profession: it.profession,
              name: it.name,
              defaultPrice: it.defaultPrice == null ? const Value.absent() : Value(it.defaultPrice!),
              orderIndex: Value(it.orderIndex),
              isActive: Value(it.isActive),
            ),
          );
        }
      }

      // Copy work hours Mon–Sun if possible; otherwise create defaults.
      final List<SalonWorkHour> tplHours;
      if (templateSalonId != null) {
        tplHours = await (select(salonWorkHours)
              ..where((t) => t.salonId.equals(templateSalonId))
              ..orderBy([(t) => OrderingTerm(expression: t.weekday)]))
            .get();
      } else {
        tplHours = const [];
      }

      if (tplHours.isNotEmpty) {
        for (final h in tplHours) {
          await into(salonWorkHours).insert(
            SalonWorkHoursCompanion.insert(
              id: 'wh-$newId-${h.weekday}',
              salonId: newId,
              weekday: h.weekday,
              startMinute: h.startMinute,
              endMinute: h.endMinute,
            ),
          );
        }
      } else {
        for (int weekday = 1; weekday <= 7; weekday++) {
          await into(salonWorkHours).insert(
            SalonWorkHoursCompanion.insert(
              id: 'wh-$newId-$weekday',
              salonId: newId,
              weekday: weekday,
              startMinute: 480,
              endMinute: 1320,
            ),
          );
        }
      }

      // Seed an initial empty workday for today (optional, but helps UX).
      // Only if no workday exists yet.
      final existingToday = await (select(workDays)
            ..where((t) => t.salonId.equals(newId) & t.date.equals(today)))
          .getSingleOrNull();
      if (existingToday == null) {
        await into(workDays).insert(
          WorkDaysCompanion.insert(
            id: 'wd-$newId-${today.toIso8601String().substring(0, 10)}',
            salonId: newId,
            date: today,
            currencyCode: const Value('EUR'),
          ),
        );
      }

      return (await getSalonById(newId))!;
    });
  }

  Future<void> renameSalon({
    required String salonId,
    required String newName,
    required int salonNumber,
  }) async {
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return;
    await (update(salons)..where((t) => t.id.equals(salonId))).write(
      SalonsCompanion(name: Value(trimmed)),
    );

    await _enqueueSyncOp(
      salonId: salonId,
      entityType: 'salon',
      entityId: salonId,
      op: 'upsert',
      baseVersion: 0,
      payload: {
        'id': salonId,
        'name': trimmed,
        'salon_number': salonNumber,
      },
    );
  }

  Future<(int startMinute, int endMinute)> getSalonHoursForDate({
    required String salonId,
    required DateTime date,
  }) async {
    final weekday = date.weekday;
    final wh = await (select(salonWorkHours)
          ..where((t) => t.salonId.equals(salonId) & t.weekday.equals(weekday)))
        .getSingleOrNull();

    if (wh != null) return (wh.startMinute, wh.endMinute);

    // Fallback to legacy settings
    final s = await (select(salonSettings)..where((t) => t.salonId.equals(salonId)))
        .getSingleOrNull();
    return (s?.dayStartMinute ?? 480, s?.dayEndMinute ?? 1320);
  }

  Future<User?> authenticate({
    required String salonId,
    required String username,
    required String password,
  }) {
    final uRaw = username.trim();
    final uNorm = uRaw.toLowerCase(); // Unicode-aware in Dart (works for Cyrillic)
    final p = password.trim();

    // Prefer usernameNorm if available; fallback to exact username match for legacy rows.
    return (select(users)
          ..where((t) =>
              t.salonId.equals(salonId) &
              t.isActive.equals(true) &
              (t.usernameNorm.equals(uNorm) |
                  (t.usernameNorm.isNull() & t.username.equals(uRaw))) &
              t.password.equals(p)))
        .getSingleOrNull();
  }

  // ---------------------------
  // Admin: Users + Professions
  // ---------------------------

  /// Watches users for a given salon scope.
  /// - For global admins, pass [globalSalonId].
  /// - For salon users, pass the salon id.
  Stream<List<User>> watchUsersBySalon(String salonId) {
    final q = select(users)
      ..where((t) => t.salonId.equals(salonId))
      ..orderBy([
        (t) => OrderingTerm(expression: t.isActive, mode: OrderingMode.desc),
        (t) => OrderingTerm(expression: t.isAdmin, mode: OrderingMode.desc),
        (t) => OrderingTerm(expression: t.usernameNorm),
        (t) => OrderingTerm(expression: t.username),
      ]);
    return q.watch();
  }

  Future<User?> getUserById(String id) {
    return (select(users)..where((t) => t.id.equals(id))).getSingleOrNull();
  }

  Future<StaffColumn?> getStaffColumnForUser({
    required String salonId,
    required String userId,
  }) {
    return (select(staffColumns)
          ..where((t) => t.salonId.equals(salonId) & t.userId.equals(userId))
          ..limit(1))
        .getSingleOrNull();
  }

  /// Queue an upsert for a user (and their salon membership).
  /// This is the "proper" way to make the server aware of new/edited users,
  /// instead of relying on placeholder users created during entry push.
  Future<void> enqueueUserUpsert({
    required String userId,
    required String salonId,
  }) async {
    final u = await getUserById(userId);
    if (u == null) return;

    final col = await getStaffColumnForUser(salonId: salonId, userId: userId);

    final payload = <String, dynamic>{
      'id': userId,
      'salon_id': salonId,
      'username': u.username,
      'password': u.password, // server will hash
      'is_active': u.isActive,
      'role': u.isAdmin ? 'admin' : 'user',
      'display_name': (col?.displayName ?? u.username).trim().isEmpty
          ? u.username
          : (col?.displayName ?? u.username).trim(),
      'profession': ((col?.profession ?? '').trim().isEmpty
		? ''
		: (col?.profession ?? '').trim()),
      'sort_order': col?.orderIndex ?? 0,
    };

    await _enqueueSyncOp(
      salonId: salonId,
      entityType: 'user',
      entityId: userId,
      op: 'upsert',
      baseVersion: 0,
      payload: payload,
    );
  }

  /// Queue a delete for a user. (Server can soft-delete membership or mark inactive.)
  Future<void> enqueueUserDelete({
    required String userId,
    required String salonId,
  }) async {
    await _enqueueSyncOp(
      salonId: salonId,
      entityType: 'user',
      entityId: userId,
      op: 'delete',
      baseVersion: 0,
      payload: {'id': userId, 'salon_id': salonId},
    );
  }


  /// Creates or updates a user. For non-admin users, also ensures a staff column exists.
  ///
  /// Notes:
  /// - [salonId] is ignored when [isAdmin] is true (admins are stored under [globalSalonId]).
  /// - Username is unique per salon (so the same username can exist in another salon).
  Future<void> upsertUserWithOptionalStaffColumn({
    String? id,
    required String salonId,
    required String username,
    required String password,
    required bool isAdmin,
    bool isActive = true,
    required String? profession, // required for non-admin
  }) async {
    final nowId = id ?? const Uuid().v4();
    final scopeSalonId = isAdmin ? globalSalonId : salonId;
    final uRaw = username.trim();
    final uNorm = uRaw.toLowerCase();
    final p = password.trim();

    // Validate uniqueness rules:
    // - Admins: username unique globally (GLOBAL), among active admins.
    // - Salon users: username unique within the salon, among active users.
    // NOTE: DB does not enforce this; we do it in Dart.
    final conflictCount = await customSelect(
      isAdmin
          ? 'SELECT COUNT(*) AS c FROM users WHERE salon_id = ? AND is_admin = 1 AND is_active = 1 AND username_norm = ? AND id != ?'
          : 'SELECT COUNT(*) AS c FROM users WHERE salon_id = ? AND is_admin = 0 AND is_active = 1 AND username_norm = ? AND id != ?',
      variables: [Variable<String>(scopeSalonId), Variable<String>(uNorm), Variable<String>(nowId)],
      readsFrom: {users},
    ).getSingle();
    if (conflictCount.read<int>('c') > 0) {
      throw StateError('USERNAME_TAKEN');
    }

    await transaction(() async {
      await into(users).insertOnConflictUpdate(
        UsersCompanion(
          id: Value(nowId),
          salonId: Value(scopeSalonId),
          username: Value(uRaw),
          usernameNorm: Value(uNorm),
          password: Value(p),
          isActive: Value(isAdmin ? true : isActive),
          isAdmin: Value(isAdmin),
        ),
      );

      if (!isAdmin) {
        final prof = (profession ?? '').trim();

        // Ensure staff column exists.
        await ensureStaffColumnForUser(
          salonId: scopeSalonId,
          userId: nowId,
          displayName: uRaw,
          profession: prof,
        );

        // Sync staff column active state.
        final today = dateOnly(DateTime.now());
        if (isActive) {
          await (update(staffColumns)
                ..where((t) => t.salonId.equals(scopeSalonId) & t.userId.equals(nowId)))
              .write(StaffColumnsCompanion(activeTo: Value(null)));
        } else {
          await (update(staffColumns)
                ..where((t) => t.salonId.equals(scopeSalonId) & t.userId.equals(nowId)))
              .write(StaffColumnsCompanion(activeTo: Value(today)));
        }
      }
    });
  }

  Future<void> setUserActive({
    required String userId,
    required bool isActive,
  }) async {
    final u = await getUserById(userId);
    if (u == null) return;
    if (u.isAdmin) {
      // Keep admins always active.
      return;
    }
    final today = dateOnly(DateTime.now());

    await transaction(() async {
      await (update(users)..where((t) => t.id.equals(userId))).write(
        UsersCompanion(isActive: Value(isActive)),
      );

      await (update(staffColumns)
            ..where((t) => t.salonId.equals(u.salonId) & t.userId.equals(u.id)))
          .write(
        isActive
            ? StaffColumnsCompanion(activeTo: Value(null))
            : StaffColumnsCompanion(activeTo: Value(today)),
      );
    });
  }

  Future<void> updateUserPassword({
    required String userId,
    required String newPassword,
  }) async {
    final p = newPassword.trim();
    if (p.isEmpty) return;
    await (update(users)..where((t) => t.id.equals(userId))).write(
      UsersCompanion(password: Value(p)),
    );
  }

  /// Deletes a user. If the user is a salon user (not global admin),
  /// we also close their staff column (activeTo = today) to keep the grid clean.
  Future<void> deleteUserAndCloseStaffColumn({
    required String userId,
  }) async {
    final u = await getUserById(userId);
    if (u == null) return;
    final today = dateOnly(DateTime.now());

    await transaction(() async {
      if (!u.isAdmin) {
        await (update(staffColumns)
              ..where((t) => t.salonId.equals(u.salonId) & t.userId.equals(u.id)))
            .write(StaffColumnsCompanion(activeTo: Value(today)));
      }
      await (delete(users)..where((t) => t.id.equals(u.id))).go();
    });
  }

  /// Professions are stored in [attributeOptions] per salon with type = 'profession'.
  Stream<List<AttributeOption>> watchProfessionsBySalon(String salonId) {
    final q = select(attributeOptions)
      ..where((t) => t.salonId.equals(salonId) & t.type.equals('profession'))
      ..orderBy([
        (t) => OrderingTerm(expression: t.orderIndex),
        (t) => OrderingTerm(expression: t.value),
      ]);
    return q.watch();
  }

  Future<void> upsertProfession({
    required String salonId,
    String? id,
    required String value,
  }) async {
    final v = value.trim();
    if (v.isEmpty) return;

    final existing = await (select(attributeOptions)
          ..where((t) =>
              t.salonId.equals(salonId) &
              t.type.equals('profession') &
              t.value.equals(v))
          ..limit(1))
        .getSingleOrNull();
    if (existing != null) return;

    // Put at the end.
    final maxOrder = await (select(attributeOptions)
          ..where((t) => t.salonId.equals(salonId) & t.type.equals('profession')))
        .get()
        .then((rows) => rows.isEmpty ? 0 : rows.map((e) => e.orderIndex).reduce((a, b) => a > b ? a : b));

    final rid = id ?? const Uuid().v4();
    await into(attributeOptions).insertOnConflictUpdate(
      AttributeOptionsCompanion.insert(
        id: rid,
        salonId: salonId,
        type: 'profession',
        value: v,
        orderIndex: Value(maxOrder + 1),
        isActive: const Value(true),
      ),
    );
    await enqueueAttributeOptionUpsertById(rid);
  }

  Future<void> updateProfession({
    required String id,
    String? value,
    bool? isActive,
    int? orderIndex,
  }) async {
    final v = value?.trim();
    await (update(attributeOptions)..where((t) => t.id.equals(id))).write(
      AttributeOptionsCompanion(
        value: v == null ? const Value.absent() : Value(v),
        isActive: isActive == null ? const Value.absent() : Value(isActive),
        orderIndex: orderIndex == null ? const Value.absent() : Value(orderIndex),
      ),
    );
    await enqueueAttributeOptionUpsertById(id);
  }

  Future<void> reorderProfession({
    required String salonId,
    required String id,
    required int direction, // -1 up, +1 down
  }) async {
    final rows = await (select(attributeOptions)
          ..where((t) => t.salonId.equals(salonId) & t.type.equals('profession'))
          ..orderBy([(t) => OrderingTerm(expression: t.orderIndex), (t) => OrderingTerm(expression: t.value)]))
        .get();
    final idx = rows.indexWhere((e) => e.id == id);
    if (idx == -1) return;
    final swapWith = idx + direction;
    if (swapWith < 0 || swapWith >= rows.length) return;
    final a = rows[idx];
    final b = rows[swapWith];
    await transaction(() async {
      await updateProfession(id: a.id, orderIndex: b.orderIndex);
      await updateProfession(id: b.id, orderIndex: a.orderIndex);
    });
  }


  // ---------------------------
  // Schedule queries
  // ---------------------------

  Stream<SalonSetting?> watchSalonSettingsBySalon(String salonId) {
    return (select(salonSettings)..where((t) => t.salonId.equals(salonId)))
        .watchSingleOrNull();
  }
  
  /// Ordered Mon..Sun (weekday 1..7). If a salon has no rows yet, this returns an empty list.
  Stream<List<SalonWorkHour>> watchSalonWorkHoursBySalon(String salonId) {
    final q = select(salonWorkHours)
      ..where((t) => t.salonId.equals(salonId))
      ..orderBy([(t) => OrderingTerm(expression: t.weekday)]);
    return q.watch();
  }

  /// Admin helper: upsert Mon..Sun work hours + slotMinutes in one transaction.
  ///
  /// [hoursByWeekday] must contain keys 1..7.
  Future<void> upsertSalonWorkHoursAndSlotMinutes({
    required String salonId,
    required Map<int, ({int startMinute, int endMinute})> hoursByWeekday,
    required int slotMinutes,
  }) async {
    final minStart = hoursByWeekday.values
        .map((e) => e.startMinute)
        .reduce((a, b) => a < b ? a : b);
    final maxEnd = hoursByWeekday.values
        .map((e) => e.endMinute)
        .reduce((a, b) => a > b ? a : b);

    await transaction(() async {
      // Keep legacy single-interval fields in sync for safety/backfill.
      await into(salonSettings).insertOnConflictUpdate(
        SalonSettingsCompanion(
          salonId: Value(salonId),
          dayStartMinute: Value(minStart),
          dayEndMinute: Value(maxEnd),
          slotMinutes: Value(slotMinutes),
        ),
      );

      for (var weekday = 1; weekday <= 7; weekday++) {
        final h = hoursByWeekday[weekday];
        if (h == null) continue;
        await into(salonWorkHours).insertOnConflictUpdate(
          SalonWorkHoursCompanion.insert(
            id: 'wh-$salonId-$weekday',
            salonId: salonId,
            weekday: weekday,
            startMinute: h.startMinute,
            endMinute: h.endMinute,
          ),
        );
      }
    });

    await _enqueueSyncOp(
      salonId: salonId,
      entityType: 'salon_settings',
      entityId: salonId,
      op: 'upsert',
      baseVersion: 0,
      payload: {
        'salon_id': salonId,
        'day_start_minute': minStart,
        'day_end_minute': maxEnd,
        'slot_minutes': slotMinutes,
      },
    );

    for (var weekday = 1; weekday <= 7; weekday++) {
      final h = hoursByWeekday[weekday];
      if (h == null) continue;
      await _enqueueSyncOp(
        salonId: salonId,
        entityType: 'salon_work_hours',
        entityId: 'wh-$salonId-$weekday',
        op: 'upsert',
        baseVersion: 0,
        payload: {
          'id': 'wh-$salonId-$weekday',
          'salon_id': salonId,
          'weekday': weekday,
          'start_minute': h.startMinute,
          'end_minute': h.endMinute,
        },
      );
    }
  }

  Future<void> ensureStaffColumnForUser({
    required String salonId,
    required String userId,
    required String displayName,
    required String profession,
  }) async {
    final today = dateOnly(DateTime.now());
    final cleanName = displayName.trim().isEmpty ? '(unknown)' : displayName.trim();

    final existing = await (select(staffColumns)
          ..where((t) => t.salonId.equals(salonId) & t.userId.equals(userId))
          ..limit(1))
        .getSingleOrNull();

    final incomingProfession = profession.trim();
    final cleanProfession = incomingProfession.isNotEmpty
        ? incomingProfession
        : (existing?.profession.trim() ?? '');

    if (existing != null) {
      await (update(staffColumns)..where((t) => t.id.equals(existing.id))).write(
        StaffColumnsCompanion(
          displayName: Value(cleanName),
          profession: Value(cleanProfession),
          activeTo: const Value(null),
        ),
      );
      return;
    }

    // Put at the end.
    final maxOrder = await (select(staffColumns)
          ..where((t) => t.salonId.equals(salonId)))
        .get()
        .then((rows) => rows.isEmpty ? 0 : rows.map((e) => e.orderIndex).reduce((a, b) => a > b ? a : b));

    await into(staffColumns).insertOnConflictUpdate(
      StaffColumnsCompanion.insert(
        id: 'col-$salonId-$userId',
        salonId: salonId,
        userId: userId,
        displayName: cleanName,
        profession: cleanProfession,
        orderIndex: Value(maxOrder + 1),
        activeFrom: today,
        activeTo: const Value(null),
      ),
    );
  }

  Stream<List<StaffColumn>> watchStaffColumnsForDate({
    required String salonId,
    required DateTime date,
  }) {
    // Show a staff column only inside its active window for the requested day.
    // This keeps the schedule grid clean even if many employees have come and gone.
    final d = dateOnly(date);

    final q = select(staffColumns)
      ..where((t) =>
          t.salonId.equals(salonId) &
          t.activeFrom.isSmallerOrEqualValue(d) &
          (t.activeTo.isNull() | t.activeTo.isBiggerOrEqualValue(d)))
      ..orderBy([
        (t) => OrderingTerm(expression: t.orderIndex),
        (t) => OrderingTerm(expression: t.displayName),
      ]);

    return q.watch();
  }

  /// Reorders staff columns (and therefore user columns) within a salon.
  /// This affects the grid and also the Users screen ordering.
  Future<void> moveStaffColumn({
    required String salonId,
    required String userId,
    required bool up,
  }) async {
    final col = await (select(staffColumns)
          ..where((t) => t.salonId.equals(salonId) & t.userId.equals(userId))
          ..limit(1))
        .getSingleOrNull();
    if (col == null) return;

    final neighbors = await (select(staffColumns)
          ..where((t) => t.salonId.equals(salonId))
          ..orderBy([(t) => OrderingTerm(expression: t.orderIndex), (t) => OrderingTerm(expression: t.displayName)]))
        .get();

    final idx = neighbors.indexWhere((e) => e.id == col.id);
    if (idx < 0) return;
    final swapIdx = up ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= neighbors.length) return;

    final other = neighbors[swapIdx];
    await transaction(() async {
      await (update(staffColumns)..where((t) => t.id.equals(col.id))).write(
        StaffColumnsCompanion(orderIndex: Value(other.orderIndex)),
      );
      await (update(staffColumns)..where((t) => t.id.equals(other.id))).write(
        StaffColumnsCompanion(orderIndex: Value(col.orderIndex)),
      );
    });

    await enqueueUserUpsert(userId: col.userId, salonId: salonId);
    await enqueueUserUpsert(userId: other.userId, salonId: salonId);
  }

  Future<WorkDay> ensureWorkDay({
    required String salonId,
    required DateTime date,
  }) async {
    final d = dateOnly(date);

    final existing = await (select(workDays)
          ..where((t) => t.salonId.equals(salonId) & t.date.equals(d)))
        .getSingleOrNull();

    if (existing != null) return existing;

    final id = 'wd-$salonId-${d.toIso8601String().substring(0, 10)}';

    await into(workDays).insert(
      WorkDaysCompanion.insert(
        id: id,
        salonId: salonId,
        date: d,
        currencyCode: const Value('EUR'),
      ),
    );

    return (await (select(workDays)..where((t) => t.id.equals(id))).getSingle());
  }

  Stream<List<TimeSlotEntryWithMoney>> watchEntriesWithMoney({
    required String workDayId,
  }) {
    final joinQuery = select(timeSlotEntries).join([
      leftOuterJoin(entryMoney, entryMoney.entryId.equalsExp(timeSlotEntries.id)),
    ])
      ..where(timeSlotEntries.workDayId.equals(workDayId));

    return joinQuery.watch().map((rows) {
      return rows.map((r) {
        final e = r.readTable(timeSlotEntries);
        final m = r.readTableOrNull(entryMoney);
        return TimeSlotEntryWithMoney(e, m);
      }).toList();
    });
  }

  /// Watches all entry lines for a work day and returns a map keyed by entryId.
  ///
  /// This is used for rendering pills inside the schedule grid without doing
  /// per-cell queries.
  Stream<WorkDayEntryLineMap> watchEntryLineDisplaysForWorkDay({
    required String workDayId,
  }) {
    final joinQuery = select(entryLines).join([
      innerJoin(timeSlotEntries, timeSlotEntries.id.equalsExp(entryLines.entryId)),
      leftOuterJoin(catalogItems, catalogItems.id.equalsExp(entryLines.catalogItemId)),
    ])
      ..where(timeSlotEntries.workDayId.equals(workDayId));

    return joinQuery.watch().map((rows) {
      final map = <String, List<EntryLineDisplay>>{};
      for (final r in rows) {
        final line = r.readTable(entryLines);
        final entry = r.readTable(timeSlotEntries);
        final item = r.readTableOrNull(catalogItems);

        final name = item?.name ?? line.catalogItemId;

        String? variant;
        final mj = line.metaJson;
        if (mj != null && mj.isNotEmpty) {
          try {
            final obj = jsonDecode(mj);
            if (obj is Map && obj['variant'] is String) {
              variant = obj['variant'] as String;
            }
          } catch (_) {
            // ignore malformed json
          }
        }

        (map[entry.id] ??= <EntryLineDisplay>[]).add(
          EntryLineDisplay(name: name, lineType: line.lineType, variant: variant),
        );
      }

      // Keep a stable order within each entry.
      for (final e in map.entries) {
        e.value.sort((a, b) => a.name.compareTo(b.name));
      }
      return map;
    });
  }

  // ---------------------------
  // Catalog / entry lines
  // ---------------------------

  Stream<List<CatalogItem>> watchCatalog({
    required String salonId,
    required String profession,
    required String type, // 'service'/'product' (product also includes 'product_category')
  }) {
    final q = select(catalogItems)
      ..where((t) {
        final base = t.salonId.equals(salonId) & t.profession.equals(profession) & t.isActive.equals(true);
        if (type == 'product') {
          return base & (t.type.equals('product') | t.type.equals('product_category'));
        }
        return base & t.type.equals(type);
      })
      ..orderBy([
        (t) => OrderingTerm(expression: t.orderIndex),
        (t) => OrderingTerm(expression: t.name),
      ]);

    return q.watch();
  }


  /// Admin view: watch catalog items for a salon and type.
  /// If [profession] is provided, filters by it.
  Stream<List<CatalogItem>> watchCatalogAdmin({
    required String salonId,
    required String type, // 'service'/'product' (product also includes 'product_category')
    String? profession,
    bool activeOnly = true,
  }) {
    final q = select(catalogItems)
      ..where((t) {
        if (type == 'product') {
          return t.salonId.equals(salonId) & (t.type.equals('product') | t.type.equals('product_category'));
        }
        return t.salonId.equals(salonId) & t.type.equals(type);
      });

    if (profession != null) {
      q.where((t) => t.profession.equals(profession));
    }
    if (activeOnly) {
      q.where((t) => t.isActive.equals(true));
    }

    q.orderBy([
      (t) => OrderingTerm(expression: t.orderIndex),
      (t) => OrderingTerm(expression: t.name),
    ]);

    return q.watch();
  }

  Future<void> upsertCatalogItem({
    String? id,
    required String salonId,
    required String type, // 'service'/'product'
    required String profession,
    String category = '',
    required String name,
    double? defaultPrice,
    int orderIndex = 0,
    bool isActive = true,
  }) async {
    final nowId = id ?? const Uuid().v4();

    // If we're inserting a new item and no order is specified, append it at the end.
    if (id == null && orderIndex == 0) {
      final existing = await (select(catalogItems)
            ..where((t) =>
                t.salonId.equals(salonId) &
                t.type.equals(type) &
                t.profession.equals(profession))
            ..orderBy([(t) => OrderingTerm(expression: t.orderIndex, mode: OrderingMode.desc)])
            ..limit(1))
          .getSingleOrNull();
      orderIndex = (existing?.orderIndex ?? 0) + 1;
    }

    await into(catalogItems).insertOnConflictUpdate(
      CatalogItemsCompanion.insert(
        id: nowId,
        salonId: salonId,
        type: type,
        category: category,
        profession: profession,
        name: name,
        defaultPrice: defaultPrice == null ? const Value.absent() : Value(defaultPrice),
        orderIndex: Value(orderIndex),
        isActive: Value(isActive),
      ),
    );
    await enqueueCatalogItemUpsertById(nowId);
  }

  Future<void> setCatalogItemActive({required String id, required bool isActive}) async {
    await (update(catalogItems)..where((t) => t.id.equals(id))).write(CatalogItemsCompanion(isActive: Value(isActive)));
    await enqueueCatalogItemUpsertById(id);
  }

  Future<void> reorderCatalogItem({
    required String salonId,
    required String type,
    required String profession,
    required String id,
    required int direction, // -1 up, +1 down
  }) async {
    final rows = await (select(catalogItems)
          ..where((t) {
            final base = t.salonId.equals(salonId) & t.profession.equals(profession) & t.isActive.equals(true);
            if (type == 'product') {
              return base & (t.type.equals('product') | t.type.equals('product_category'));
            }
            return base & t.type.equals(type);
          })
          ..orderBy([
            (t) => OrderingTerm(expression: t.orderIndex),
            (t) => OrderingTerm(expression: t.name),
          ]))
        .get();
    final idx = rows.indexWhere((e) => e.id == id);
    if (idx == -1) return;
    final j = idx + direction;
    if (j < 0 || j >= rows.length) return;
    final a = rows[idx];
    final b = rows[j];
    await transaction(() async {
      await (update(catalogItems)..where((t) => t.id.equals(a.id))).write(CatalogItemsCompanion(orderIndex: Value(b.orderIndex)));
      await (update(catalogItems)..where((t) => t.id.equals(b.id))).write(CatalogItemsCompanion(orderIndex: Value(a.orderIndex)));
    });
    await enqueueCatalogItemUpsertById(a.id);
    await enqueueCatalogItemUpsertById(b.id);
  }

  Future<void> enqueueCatalogItemUpsertById(String id) async {
    id = await _ensureCatalogItemUuidById(id);
    final item = await (select(catalogItems)..where((t) => t.id.equals(id))).getSingleOrNull();
    if (item == null) return;
    await _enqueueSyncOp(
      salonId: item.salonId,
      entityType: 'catalog_item',
      entityId: item.id,
      op: 'upsert',
      baseVersion: 0,
      payload: {
        'id': item.id,
        'salon_id': item.salonId,
        'type': item.type,
        'category': item.category,
        'profession': item.profession,
        'name': item.name,
        'default_price': item.defaultPrice,
        'order_index': item.orderIndex,
        'is_active': item.isActive,
      },
    );
  }

  Future<void> enqueueAttributeOptionUpsertById(String id) async {
    id = await _ensureAttributeOptionUuidById(id);
    final row = await (select(attributeOptions)..where((t) => t.id.equals(id))).getSingleOrNull();
    if (row == null) return;
    await _enqueueSyncOp(
      salonId: row.salonId,
      entityType: 'attribute_option',
      entityId: row.id,
      op: 'upsert',
      baseVersion: 0,
      payload: {
        'id': row.id,
        'salon_id': row.salonId,
        'type': row.type,
        'value': row.value,
        'order_index': row.orderIndex,
        'is_active': row.isActive,
      },
    );
  }


  Future<void> enqueueAllCatalogItemsForSalon(String salonId) async {
    final rows = await (select(catalogItems)..where((t) => t.salonId.equals(salonId))).get();
    for (final row in rows) {
      await enqueueCatalogItemUpsertById(row.id);
    }
  }

  Future<void> enqueueAllAttributeOptionsForSalon(String salonId) async {
    final rows = await (select(attributeOptions)..where((t) => t.salonId.equals(salonId))).get();
    for (final row in rows) {
      await enqueueAttributeOptionUpsertById(row.id);
    }
  }

  Future<void> enqueueAllSyncableConfigForSalon(String salonId, {int? salonNumber}) async {
    final salon = await getSalonById(salonId);
    if (salon != null) {
      await _enqueueSyncOp(
        salonId: salonId,
        entityType: 'salon',
        entityId: salonId,
        op: 'upsert',
        baseVersion: 0,
        payload: {
          'id': salon.id,
          'name': salon.name,
          'salon_number': salonNumber,
        },
      );
    }

    await enqueueAllCatalogItemsForSalon(salonId);
    await enqueueAllAttributeOptionsForSalon(salonId);

    final s = await (select(salonSettings)..where((t) => t.salonId.equals(salonId))).getSingleOrNull();
    if (s != null) {
      await _enqueueSyncOp(
        salonId: salonId,
        entityType: 'salon_settings',
        entityId: salonId,
        op: 'upsert',
        baseVersion: 0,
        payload: {
          'salon_id': salonId,
          'day_start_minute': s.dayStartMinute,
          'day_end_minute': s.dayEndMinute,
          'slot_minutes': s.slotMinutes,
        },
      );
    }

    final whRows = await (select(salonWorkHours)..where((t) => t.salonId.equals(salonId))).get();
    for (final h in whRows) {
      await _enqueueSyncOp(
        salonId: salonId,
        entityType: 'salon_work_hours',
        entityId: h.id,
        op: 'upsert',
        baseVersion: 0,
        payload: {
          'id': h.id,
          'salon_id': h.salonId,
          'weekday': h.weekday,
          'start_minute': h.startMinute,
          'end_minute': h.endMinute,
        },
      );
    }
  }

  // ---------------------------
  // Salon setting: preset prices (stored as attribute option to avoid schema churn)
  // ---------------------------

  static const String _presetSettingType = 'setting_use_preset_prices';

  Stream<bool> watchUsePresetPrices(String salonId) {
    final q = select(attributeOptions)
      ..where((t) => t.salonId.equals(salonId) & t.type.equals(_presetSettingType) & t.isActive.equals(true))
      ..limit(1);
    return q.watch().map((rows) => rows.isNotEmpty && rows.first.value == '1');
  }

  Future<bool> getUsePresetPrices(String salonId) async {
    final row = await (select(attributeOptions)
          ..where((t) => t.salonId.equals(salonId) & t.type.equals(_presetSettingType) & t.isActive.equals(true))
          ..limit(1))
        .getSingleOrNull();
    return row != null && row.value == '1';
  }

  Future<List<CatalogItem>> getCatalogItemsByIds(List<String> ids) {
    if (ids.isEmpty) return Future.value(const <CatalogItem>[]);
    return (select(catalogItems)..where((t) => t.id.isIn(ids))).get();
  }

  // ---------------------------
  // Product variants (for category products like "Бои" / "Кристали")
  // Stored as AttributeOptions rows with type = 'variant:<parentItemId>'
  // ---------------------------

  static String _variantType(String parentItemId) => 'variant:$parentItemId';

  Stream<List<AttributeOption>> watchCatalogVariants({required String salonId, required String parentItemId}) {
    final q = (select(attributeOptions)
          ..where((t) => t.salonId.equals(salonId) & t.type.equals(_variantType(parentItemId)) & t.isActive.equals(true))
          ..orderBy([
            (t) => OrderingTerm(expression: t.orderIndex),
            (t) => OrderingTerm(expression: t.value),
          ]));
    return q.watch();
  }

  /// Admin view: includes inactive variants (so we never delete history).
  Stream<List<AttributeOption>> watchCatalogVariantsAdmin({required String salonId, required String parentItemId}) {
    final q = (select(attributeOptions)
          ..where((t) => t.salonId.equals(salonId) & t.type.equals(_variantType(parentItemId)))
          ..orderBy([
            (t) => OrderingTerm(expression: t.orderIndex),
            (t) => OrderingTerm(expression: t.value),
          ]));
    return q.watch();
  }

  Future<void> updateCatalogVariant({
    required String id,
    String? value,
    bool? isActive,
    int? orderIndex,
  }) async {
    final v = value?.trim();
    await (update(attributeOptions)..where((t) => t.id.equals(id))).write(
      AttributeOptionsCompanion(
        value: v == null ? const Value.absent() : Value(v),
        isActive: isActive == null ? const Value.absent() : Value(isActive),
        orderIndex: orderIndex == null ? const Value.absent() : Value(orderIndex),
      ),
    );
    await enqueueAttributeOptionUpsertById(id);
  }

  Future<void> reorderCatalogVariant({
    required String salonId,
    required String parentItemId,
    required String id,
    required int direction, // -1 up, +1 down
  }) async {
    final rows = await (select(attributeOptions)
          ..where((t) => t.salonId.equals(salonId) & t.type.equals(_variantType(parentItemId)))
          ..orderBy([
            (t) => OrderingTerm(expression: t.orderIndex),
            (t) => OrderingTerm(expression: t.value),
          ]))
        .get();
    final idx = rows.indexWhere((e) => e.id == id);
    if (idx == -1) return;
    final swapWith = idx + direction;
    if (swapWith < 0 || swapWith >= rows.length) return;
    final a = rows[idx];
    final b = rows[swapWith];
    await transaction(() async {
      await updateCatalogVariant(id: a.id, orderIndex: b.orderIndex);
      await updateCatalogVariant(id: b.id, orderIndex: a.orderIndex);
    });
  }

  Future<void> upsertCatalogVariant({
    required String salonId,
    required String parentItemId,
    String? id,
    required String value,
    int orderIndex = 0,
    bool isActive = true,
  }) async {
    final rid = id ?? const Uuid().v4();
    await into(attributeOptions).insertOnConflictUpdate(
      AttributeOptionsCompanion.insert(
        id: rid,
        salonId: salonId,
        type: _variantType(parentItemId),
        value: value,
        orderIndex: Value(orderIndex),
        isActive: Value(isActive),
      ),
    );
    await enqueueAttributeOptionUpsertById(rid);
  }

  // Intentionally no deleteCatalogVariant: keep history. Use isActive=false instead.

  Future<void> setUsePresetPrices({required String salonId, required bool enabled}) async {
    final id = _stableUuid('preset:$salonId');
    await into(attributeOptions).insertOnConflictUpdate(
      AttributeOptionsCompanion.insert(
        id: id,
        salonId: salonId,
        type: _presetSettingType,
        value: enabled ? '1' : '0',
        orderIndex: const Value(0),
        isActive: const Value(true),
      ),
    );
    await enqueueAttributeOptionUpsertById(id);
  }


  Future<TimeSlotEntry?> findEntryByCell({
    required String workDayId,
    required String staffColumnId,
    required int slotMinute,
  }) {
    return (select(timeSlotEntries)
          ..where((t) =>
              t.workDayId.equals(workDayId) &
              t.staffColumnId.equals(staffColumnId) &
              t.slotMinute.equals(slotMinute)))
        .getSingleOrNull();
  }

  Future<EntryEditorData> getEntryEditorDataByCell({
    required String workDayId,
    required String staffColumnId,
    required int slotMinute,
  }) async {
    final entry = await findEntryByCell(
      workDayId: workDayId,
      staffColumnId: staffColumnId,
      slotMinute: slotMinute,
    );

    if (entry == null) {
      return const EntryEditorData(entry: null, money: null, lines: <EntryLine>[]);
    }

    final money = await (select(entryMoney)..where((t) => t.entryId.equals(entry.id))).getSingleOrNull();
    final lines = await (select(entryLines)..where((t) => t.entryId.equals(entry.id))).get();
    return EntryEditorData(entry: entry, money: money, lines: lines);
  }



  /// Deletes a single entry by its cell key (workDay + staffColumn + slotMinute),
  /// including its lines and money row.
  Future<void> deleteEntryByCell({
    required String workDayId,
    required String staffColumnId,
    required int slotMinute,
  }) async {
    final existing = await findEntryByCell(
      workDayId: workDayId,
      staffColumnId: staffColumnId,
      slotMinute: slotMinute,
    );

    if (existing == null) return;

    // Capture salonId before deleting.
    final salonId = existing.salonId;

    await transaction(() async {
      await (delete(entryLines)..where((t) => t.entryId.equals(existing.id))).go();
      await (delete(entryMoney)..where((t) => t.entryId.equals(existing.id))).go();
      await (delete(timeSlotEntries)..where((t) => t.id.equals(existing.id))).go();
    });

    // Queue sync delete (best-effort).
    await _enqueueSyncOp(
      salonId: salonId,
      entityType: 'entry',
      entityId: existing.id,
      op: 'delete',
      baseVersion: 0,
      payload: {'id': existing.id},
    );
  }

  Future<String> upsertEntryAndReplaceLines({
    required String salonId,
    required String workDayId,
    required String staffColumnId,
    required int slotMinute,
    required String byUserId,
    required double servicesTotal,
    required double productsTotal,
    required String currencyCode,
    required List<LineDraft> lines,
  }) async {
    final now = DateTime.now();

    final existing = await findEntryByCell(
      workDayId: workDayId,
      staffColumnId: staffColumnId,
      slotMinute: slotMinute,
    );

    final entryId = existing?.id ?? const Uuid().v4();

    await into(timeSlotEntries).insertOnConflictUpdate(
      TimeSlotEntriesCompanion.insert(
        id: entryId,
        salonId: salonId,
        workDayId: workDayId,
        staffColumnId: staffColumnId,
        slotMinute: slotMinute,
        locked: const Value(true),
        confirmedAt: Value(now),
        confirmedByUserId: Value(byUserId),
        createdAt: now,
        updatedAt: now,
      ),
    );

    await into(entryMoney).insertOnConflictUpdate(
      EntryMoneyCompanion(
        entryId: Value(entryId),
        servicesTotal: Value(servicesTotal),
        productsTotal: Value(productsTotal),
        currencyCode: Value(currencyCode),
      ),
    );

    await transaction(() async {
      await (delete(entryLines)..where((t) => t.entryId.equals(entryId))).go();

      for (final l in lines) {
        await into(entryLines).insert(
          EntryLinesCompanion.insert(
            id: l.id,
            entryId: entryId,
            catalogItemId: l.catalogItemId,
            lineType: l.lineType,
            qty: Value(l.qty),
            metaJson: Value(l.metaJson),
            createdAt: now,
          ),
        );
      }
    });

    // Queue sync upsert (best-effort). We send server staff_id = staffColumns.userId (UUID).
    // If you still use demo ids like "col-1", the server will reject. We'll fix mapping
    // after we start pulling staff from the backend.
    final wd = await (select(workDays)..where((t) => t.id.equals(workDayId))).getSingleOrNull();
    final dateStr = wd == null
        ? null
        : '${wd.date.year.toString().padLeft(4, '0')}-${wd.date.month.toString().padLeft(2, '0')}-${wd.date.day.toString().padLeft(2, '0')}';

    // Snapshot catalog data into the sync payload so the server can store stable history
    // (title + unit_price) without needing a server-side catalog.
    final itemIds = lines.map((l) => l.catalogItemId).toSet().toList();
    final items = await getCatalogItemsByIds(itemIds);
    final itemById = <String, CatalogItem>{for (final it in items) it.id: it};

    // Map local staffColumnId -> server staff_id (staff.id == users.id)
    final col = await (select(staffColumns)..where((t) => t.id.equals(staffColumnId))).getSingleOrNull();
    final staffUserId = col?.userId ?? byUserId;


    final serviceDrafts = lines.where((l) => l.lineType == 'service').toList();
    final productDrafts = lines.where((l) => l.lineType == 'product').toList();

    double _resolveLineUnitPrice(LineDraft l) {
      final it = itemById[l.catalogItemId];

      // 1) Explicit unit_price from metaJson wins.
      if (l.metaJson != null && l.metaJson!.trim().isNotEmpty) {
        try {
          final mj = jsonDecode(l.metaJson!) as Object?;
          if (mj is Map) {
            final raw = mj['unit_price'];
            if (raw is num) return raw.toDouble();
            if (raw is String) {
              final n = double.tryParse(raw.replaceAll(',', '.'));
              if (n != null) return n;
            }
          }
        } catch (_) {
          // ignore malformed metaJson
        }
      }

      // 2) Catalog default price.
      final defaultPrice = it?.defaultPrice;
      if (defaultPrice != null && defaultPrice > 0) return defaultPrice;

      // 3) Fallback for manual-total mode:
      // when exactly one line exists in a section, assign the whole section total to it.
      if (l.lineType == 'service' && serviceDrafts.length == 1 && servicesTotal > 0) {
        return servicesTotal;
      }
      if (l.lineType == 'product' && productDrafts.length == 1 && productsTotal > 0) {
        return productsTotal;
      }

      return 0;
    }

    await _enqueueSyncOp(
      salonId: salonId,
      entityType: 'entry',
      entityId: entryId,
      op: 'upsert',
      baseVersion: 0,
      payload: {
        'id': entryId,
        // Prefer date so server can auto-create work_day.
        if (dateStr != null) 'date': dateStr,
        'work_day_id': workDayId,
        'staff_id': staffUserId,
        'start_min': slotMinute,
        'end_min': slotMinute,
        'status': 0,
        'client_name': '',
        'notes': '',
        'services_total': servicesTotal,
        'products_total': productsTotal,
        'price_total': servicesTotal + productsTotal,
        'lines': lines
            .map((l) {
                  final it = itemById[l.catalogItemId];
                  final variants = <Map<String, dynamic>>[];
                  if (l.lineType == 'product' && l.metaJson != null && l.metaJson!.trim().isNotEmpty) {
                    try {
                      final mj = jsonDecode(l.metaJson!) as Object?;
                      if (mj is Map && mj['variant'] is String) {
                        final v = (mj['variant'] as String).trim();
                        if (v.isNotEmpty) {
                          variants.add({
                            'id': const Uuid().v4(),
                            // variant_ref_id can be a non-UUID (e.g. code like "7.1"); SyncService will normalize.
                            'variant_ref_id': v,
                            'title': v,
                            'qty': 1,
                            'unit_price': 0,
                          });
                        }
                      }
                    } catch (_) {
                      // ignore malformed metaJson
                    }
                  }

                  return {
                    'id': l.id,
                    'line_type': l.lineType,
                    'ref_id': l.catalogItemId,
                    'title': it?.name ?? '',
                    'qty': l.qty,
                    'unit_price': _resolveLineUnitPrice(l),
                    'discount': 0,
                    if (variants.isNotEmpty) 'variants': variants,
                  };
                })
            .toList(),
      },
    );

    return entryId;
  }

  Future<void> _enqueueSyncOp({
    required String salonId,
    required String entityType,
    required String entityId,
    required String op,
    required int baseVersion,
    required Map<String, dynamic> payload,
  }) async {
    try {
      final opId = const Uuid().v4();
      await into(syncOutbox).insert(
        SyncOutboxCompanion.insert(
          opId: opId,
          salonId: salonId,
          entityType: entityType,
          entityId: entityId,
          op: op,
          baseVersion: Value(baseVersion),
          payloadJson: Value(jsonEncode(payload)),
        ),
        mode: InsertMode.insertOrIgnore,
      );
      debugPrint('[OUTBOX] queued entityType=$entityType entityId=$entityId salonId=$salonId');
      SyncService.instance?.markDirty();
    } catch (e, st) {
      debugPrint('[OUTBOX] failed entityType=$entityType entityId=$entityId: $e\n$st');
      rethrow;
    }
  }

  // ---------------------------
  // Seed (production bootstrap)
  // ---------------------------

  /// Bootstraps the database with a single global admin user, if (and only if)
  /// the database is empty.
  ///
  /// This intentionally does NOT create demo salons, users, professions, catalog
  /// items, or sample entries.
  Future<void> seedDemoData() async {
    // Intentionally no-op. Production/testing data should come from server sync
    // or explicit SQL seed, not from hardcoded local demo users.
    return;
  }

  Future<void> _seedSalonScheduleBasics({required String salonId}) async {
    final today = dateOnly(DateTime.now());

    await into(salonSettings).insertOnConflictUpdate(
      SalonSettingsCompanion(
        salonId: Value(salonId),
        dayStartMinute: const Value(480),
        dayEndMinute: const Value(1320),
        slotMinutes: const Value(10),
      ),
    );

    // Default work hours: Mon-Sun 08:00-22:00 (can be changed per salon later)
    for (var weekday = 1; weekday <= 7; weekday++) {
      await into(salonWorkHours).insertOnConflictUpdate(
        SalonWorkHoursCompanion.insert(
          id: 'wh-$salonId-$weekday',
          salonId: salonId,
          weekday: weekday,
          startMinute: 480,
          endMinute: 1320,
        ),
      );
    }

    // Staff columns only for salon "1" demo
    if (salonId != '1') return;

    await into(staffColumns).insertOnConflictUpdate(
      StaffColumnsCompanion.insert(
        id: 'col-1',
        salonId: salonId,
        userId: 'u-cveti',
        displayName: 'Цвети',
        profession: 'Фризьор',
        orderIndex: const Value(1),
        activeFrom: today,
        activeTo: const Value(null),
      ),
    );

    await into(staffColumns).insertOnConflictUpdate(
      StaffColumnsCompanion.insert(
        id: 'col-2',
        salonId: salonId,
        userId: 'u-sisa',
        displayName: 'Сиса',
        profession: 'Маникюрист',
        orderIndex: const Value(2),
        activeFrom: today,
        activeTo: const Value(null),
      ),
    );

    // Work day and one sample entry
    final workDay = await ensureWorkDay(salonId: salonId, date: today);

    const entryId = 'entry-1';
    final now = DateTime.now();

    await into(timeSlotEntries).insertOnConflictUpdate(
      TimeSlotEntriesCompanion.insert(
        id: entryId,
        salonId: salonId,
        workDayId: workDay.id,
        staffColumnId: 'col-1',
        slotMinute: 520, // 08:40
        locked: const Value(true),
        confirmedAt: Value(now),
        confirmedByUserId: const Value('u-cveti'),
        createdAt: now,
        updatedAt: now,
      ),
    );

    await into(entryMoney).insertOnConflictUpdate(
      const EntryMoneyCompanion(
        entryId: Value(entryId),
        servicesTotal: Value(10.0),
        productsTotal: Value(0.0),
        currencyCode: Value('EUR'),
      ),
    );

    // minimal catalog for editor sheet
    await into(catalogItems).insertOnConflictUpdate(
      CatalogItemsCompanion.insert(
        id: 'svc-1',
        salonId: salonId,
        type: 'service',
        category: '',
        profession: 'Фризьор',
        name: 'Мъжко подстригване',
        defaultPrice: const Value(10.0),
        orderIndex: const Value(1),
      ),
    );

    await into(catalogItems).insertOnConflictUpdate(
      CatalogItemsCompanion.insert(
        id: 'prd-1',
        salonId: salonId,
        type: 'product',
        category: 'Бои',
        profession: 'Фризьор',
        name: 'Боя',
        defaultPrice: const Value(5.0),
        orderIndex: const Value(1),
      ),
    );
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'krasenstyle_db.sqlite'));
    return NativeDatabase(file);
  });
}