import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'auth_state.dart';
import 'data/local/app_db.dart';
import 'ui/screens/login_screen.dart';
import 'ui/screens/daily_schedule_screen.dart';
import 'services/sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  final db = AppDatabase();
  await db.seedDemoData();

  final auth = AuthState(db: db);

  // UI scale (text/icons)
  await auth.loadUiScale();

  // Theme mode (light/dark/system)
  await auth.loadThemeMode();

  // Remember me (local offline session)
  await auth.tryRestoreSession();

  // API session (Phase 2 sync) - optional
  await auth.tryRestoreApiSession();
  await auth.loadApiCredentials();

  final sync = SyncService(db);
  if (auth.accessToken != null && auth.deviceId != null && auth.currentSalonId != null) {
    sync.configureSession(
      salonId: auth.currentSalonId!,
      token: auth.accessToken!,
      deviceId: auth.deviceId!,
    );
    sync.startAutoSync();
  }

  runApp(MyApp(db: db, auth: auth));
}

class MyApp extends StatelessWidget {
  final AppDatabase db;
  final AuthState auth;

  const MyApp({super.key, required this.db, required this.auth});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: auth,
      builder: (context, _) {
        // POS-like palette
        const serviceColor = Color(0xFF75C6E0);
        const productColor = Color(0xFFEDB563);

        final baseLight = ThemeData(
          useMaterial3: true,
          brightness: Brightness.light,
          colorScheme: ColorScheme.fromSeed(
            seedColor: serviceColor,
            brightness: Brightness.light,
          ).copyWith(
            primary: serviceColor,
            secondary: productColor,
          ),
        );

        final baseDark = ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: serviceColor,
            brightness: Brightness.dark,
          ).copyWith(
            primary: serviceColor,
            secondary: productColor,
          ),
        );

        final scaledLight = baseLight.copyWith(
          iconTheme: baseLight.iconTheme.copyWith(size: 24 * auth.uiScale),
          primaryIconTheme: baseLight.primaryIconTheme.copyWith(size: 24 * auth.uiScale),
        );
        final scaledDark = baseDark.copyWith(
          iconTheme: baseDark.iconTheme.copyWith(size: 24 * auth.uiScale),
          primaryIconTheme: baseDark.primaryIconTheme.copyWith(size: 24 * auth.uiScale),
        );

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'KrasenStyle',
          theme: scaledLight,
          darkTheme: scaledDark,
          themeMode: auth.themeMode,
          builder: (context, child) {
            final mq = MediaQuery.of(context);
            return MediaQuery(
              data: mq.copyWith(
                textScaler: TextScaler.linear(auth.uiScale),
              ),
              child: child ?? const SizedBox.shrink(),
            );
          },
          home: auth.isLoggedIn
              ? DailyScheduleScreen(db: db, auth: auth)
              : LoginScreen(auth: auth),
        );
      },
    );
  }
}
