import 'package:flutter/material.dart';

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import 'catalog_variants_screen.dart';

class CatalogItemsAdminScreen extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;
  final String type; // 'service' or 'product'

  const CatalogItemsAdminScreen({
    super.key,
    required this.db,
    required this.auth,
    required this.type,
  });

  @override
  State<CatalogItemsAdminScreen> createState() => _CatalogItemsAdminScreenState();
}

class _CatalogItemsAdminScreenState extends State<CatalogItemsAdminScreen> {
  String? _profession; // filter (profession name)
  bool _showInactive = false;

  String get _title => widget.type == 'service' ? 'Услуги' : 'Продукти';

  @override
  Widget build(BuildContext context) {
    final activeSalonId = widget.auth.activeSalonId;
    if (activeSalonId == null) {
      return Scaffold(
        appBar: AppBar(title: Text(_title)),
        body: const Center(child: Text('Моля, избери салон от менюто „Смени салон“.')),
      );
    }
    final String salonId = activeSalonId;

    return Scaffold(
      appBar: AppBar(
        title: Text(_title),
        actions: [
          IconButton(
            tooltip: 'Добави',
            onPressed: () => _openEditor(context, salonId: salonId),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          StreamBuilder<List<AttributeOption>>(
            stream: widget.db.watchProfessionsBySalon(salonId),
            builder: (context, snap) {
              final profs = (snap.data ?? const <AttributeOption>[]).where((p) => p.isActive).toList();
              if (profs.isNotEmpty && (_profession == null || !profs.any((p) => p.value == _profession))) {
                // default to first available
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (!mounted) return;
                  setState(() => _profession = profs.first.value);
                });
              }

              return DropdownButtonFormField<String>(
                value: _profession,
                decoration: const InputDecoration(
                  labelText: 'Професия',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                items: profs
                    .map((p) => DropdownMenuItem<String>(
                          value: p.value,
                          child: Text(p.value),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _profession = v),
              );
            },
          ),
          const SizedBox(height: 8),

          // Preset prices toggle (per salon)
          StreamBuilder<bool>(
            stream: widget.db.watchUsePresetPrices(salonId),
            builder: (context, snap) {
              final enabled = snap.data ?? false;
              return SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Предварително зададени цени'),
                subtitle: const Text('Ако е включено, сумите в записите се изчисляват автоматично по зададените цени.'),
                value: enabled,
                onChanged: (v) => widget.db.setUsePresetPrices(salonId: salonId, enabled: v),
              );
            },
          ),

          const Divider(height: 24),

          Row(
            children: [
              Expanded(
                child: Text(
                  _showInactive ? 'Активни + неактивни' : 'Активни',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              TextButton.icon(
                onPressed: () => setState(() => _showInactive = !_showInactive),
                icon: Icon(_showInactive ? Icons.visibility_off : Icons.visibility),
                label: Text(_showInactive ? 'Скрий неактивни' : 'Покажи неактивни'),
              ),
            ],
          ),
          const SizedBox(height: 6),

          StreamBuilder<List<CatalogItem>>(
            stream: widget.db.watchCatalogAdmin(
              salonId: salonId,
              type: widget.type,
              profession: _profession ?? '',
              activeOnly: !_showInactive,
            ),
            builder: (context, snap) {
              final items = snap.data ?? const <CatalogItem>[];
              if (items.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Center(child: Text('Няма позиции')),
                );
              }

              return Column(
                children: [
                  for (var i = 0; i < items.length; i++)
                    _CatalogItemTile(
                      item: items[i],
                      showCategory: false,
                      onTap: () => _openEditor(context, salonId: salonId, existing: items[i]),
                      onEditVariants: (items[i].type == 'product_category')
                          ? () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => CatalogVariantsScreen(
                                    db: widget.db,
                                    salonId: salonId,
                                    parentItem: items[i],
                                  ),
                                ),
                              );
                            }
                          : null,
                      onToggleActive: () => widget.db.setCatalogItemActive(id: items[i].id, isActive: !items[i].isActive),
                      onMoveUp: (_profession == null)
                          ? null
                          : () => widget.db.reorderCatalogItem(
                                salonId: salonId,
                                type: widget.type,
                                profession: _profession!,
                                id: items[i].id,
                                direction: -1,
                              ),
                      onMoveDown: (_profession == null)
                          ? null
                          : () => widget.db.reorderCatalogItem(
                                salonId: salonId,
                                type: widget.type,
                                profession: _profession!,
                                id: items[i].id,
                                direction: 1,
                              ),
                    ),
                ],
              );
            },
          ),
          const SizedBox(height: 60),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(context, salonId: salonId),
        icon: const Icon(Icons.add),
        label: const Text('Добави'),
      ),
    );
  }

  Future<void> _openEditor(BuildContext context, {required String salonId, CatalogItem? existing}) async {
    if (_profession == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Няма професии за този салон. Добави от „Професии“.')));
      return;
    }
    final res = await showModalBottomSheet<_CatalogEditResult>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _CatalogItemEditorSheet(
        type: widget.type,
        profession: _profession!,
        existing: existing,
      ),
    );

    if (res == null) return;

    await widget.db.upsertCatalogItem(
      id: existing?.id,
      salonId: salonId,
      type: res.itemType,
      profession: res.profession,
      category: res.category,
      name: res.name,
      defaultPrice: res.defaultPrice,
      orderIndex: res.orderIndex,
      isActive: res.isActive,
    );
  }
}

class _CatalogItemTile extends StatelessWidget {
  final CatalogItem item;
  final VoidCallback onTap;
  final VoidCallback onToggleActive;
  final VoidCallback? onEditVariants;
  final VoidCallback? onMoveUp;
  final VoidCallback? onMoveDown;
  final bool showCategory;

  const _CatalogItemTile({
    required this.item,
    required this.onTap,
    required this.onToggleActive,
    required this.showCategory,
    this.onEditVariants,
    this.onMoveUp,
    this.onMoveDown,
  });

  @override
  Widget build(BuildContext context) {
    final price = item.defaultPrice;
    final cat = item.category.trim();
    final subtitle = showCategory
        ? ((cat.isEmpty) ? item.profession : '$cat • ${item.profession}')
        : item.profession;
    return Card(
      child: ListTile(
        onTap: onTap,
        title: Text(item.name),
        subtitle: Text(subtitle),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (item.type == 'product_category')
              IconButton(
                tooltip: 'Номера/кодове',
                onPressed: onEditVariants,
                icon: const Icon(Icons.list_alt),
              ),
            IconButton(
              tooltip: 'Нагоре',
              onPressed: onMoveUp,
              icon: const Icon(Icons.arrow_upward),
            ),
            IconButton(
              tooltip: 'Надолу',
              onPressed: onMoveDown,
              icon: const Icon(Icons.arrow_downward),
            ),
            if (price != null) Text(price.toStringAsFixed(2)),
            const SizedBox(width: 8),
            IconButton(
              tooltip: item.isActive ? 'Деактивирай' : 'Активирай',
              onPressed: onToggleActive,
              icon: Icon(item.isActive ? Icons.visibility : Icons.visibility_off),
            ),
          ],
        ),
      ),
    );
  }
}

class _CatalogEditResult {
  final String name;
  final String category;
  final String profession;
  final String itemType; // 'service' / 'product' / 'product_category'
  final double? defaultPrice;
  final int orderIndex;
  final bool isActive;

  const _CatalogEditResult({
    required this.name,
    required this.category,
    required this.profession,
    required this.itemType,
    required this.defaultPrice,
    required this.orderIndex,
    required this.isActive,
  });
}

class _CatalogItemEditorSheet extends StatefulWidget {
  final String type;
  final String profession;
  final CatalogItem? existing;

  const _CatalogItemEditorSheet({
    required this.type,
    required this.profession,
    this.existing,
  });

  @override
  State<_CatalogItemEditorSheet> createState() => _CatalogItemEditorSheetState();
}

class _CatalogItemEditorSheetState extends State<_CatalogItemEditorSheet> {
  late final TextEditingController _name;
  late final TextEditingController _cat;
  late final TextEditingController _price;
  bool _active = true;
  bool _isCategoryProduct = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _cat = TextEditingController(text: e?.category ?? '');
    _price = TextEditingController(text: e?.defaultPrice?.toStringAsFixed(2) ?? '');
    _active = e?.isActive ?? true;
    _isCategoryProduct = (widget.type == 'product') && (e?.type == 'product_category');
  }

  @override
  void dispose() {
    _name.dispose();
    _cat.dispose();
    _price.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 12, bottom: bottom + 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.existing == null ? 'Добави' : 'Редакция', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Име', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          if (widget.type == 'product') ...[
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Категория (Бои/Кристали)') ,
              subtitle: const Text('Ако е включено, при избор се избира и конкретен номер/код на отделен екран.'),
              value: _isCategoryProduct,
              onChanged: (v) => setState(() => _isCategoryProduct = v),
            ),
            const SizedBox(height: 10),
          ],
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _price,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Цена (по желание)', border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Активна позиция'),
            value: _active,
            onChanged: (v) => setState(() => _active = v),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                final name = _name.text.trim();
                final cat = _cat.text.trim();
                if (name.isEmpty) {
                  Navigator.of(context).pop();
                  return;
                }
                final price = double.tryParse(_price.text.trim().replaceAll(',', '.'));
                final order = widget.existing?.orderIndex ?? 0;

                Navigator.of(context).pop(
                  _CatalogEditResult(
                    name: name,
                    category: cat,
                    profession: widget.profession,
                    itemType: (widget.type == 'product' && _isCategoryProduct) ? 'product_category' : widget.type,
                    defaultPrice: price,
                    orderIndex: order,
                    isActive: _active,
                  ),
                );
              },
              child: const Text('Запази'),
            ),
          ),
        ],
      ),
    );
  }
}