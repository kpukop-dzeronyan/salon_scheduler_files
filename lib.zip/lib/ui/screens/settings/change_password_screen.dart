import 'package:flutter/material.dart';

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import '../../../services/sync_service.dart';

class ChangePasswordScreen extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;

  const ChangePasswordScreen({super.key, required this.db, required this.auth});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _new1 = TextEditingController();
  final _new2 = TextEditingController();

  final _targetNew1 = TextEditingController();
  final _targetNew2 = TextEditingController();

  String _scope = '';
  String? _targetUserId;

  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final u = widget.auth.user;
    if (u != null) {
      _scope = u.homeSalonId;
      _targetUserId = u.id;
    }
  }

  @override
  void dispose() {
    _new1.dispose();
    _new2.dispose();
    _targetNew1.dispose();
    _targetNew2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = widget.auth.user;
    if (session == null) {
      return const Scaffold(body: Center(child: Text('Няма сесия.')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Смяна на парола')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Моята парола', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          TextField(
            controller: _new1,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'Нова парола',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _new2,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'Повтори новата парола',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _saving ? null : () => _saveForUser(session.id, _new1.text, _new2.text),
            icon: const Icon(Icons.save),
            label: const Text('Запази моята парола'),
          ),
          const SizedBox(height: 18),

          if (session.isAdmin) ...[
            const Divider(),
            Text('Парола на потребител', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            _ScopePickerInline(
              db: widget.db,
              value: _scope,
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  _scope = v;
                  _targetUserId = null;
                });
              },
            ),
            const SizedBox(height: 10),
            StreamBuilder<List<User>>(
              stream: widget.db.watchUsersBySalon(_scope),
              builder: (context, snap) {
                final users = snap.data ?? const <User>[];
                final items = users
                    .map((u) => DropdownMenuItem<String>(
                          value: u.id,
                          child: Text(u.isActive ? u.username : '${u.username} (inactive)'),
                        ))
                    .toList();

                // If the previously selected user is not in this scope, clear selection.
                if (_targetUserId != null && !users.any((u) => u.id == _targetUserId)) {
                  _targetUserId = null;
                }

                final effective = _targetUserId ?? (users.isNotEmpty ? users.first.id : null);
                if (effective != _targetUserId) {
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!mounted) return;
                    setState(() => _targetUserId = effective);
                  });
                }

                final allowedUsers = items.map((e) => e.value).whereType<String>().toSet();
                final safeValue = (effective != null && allowedUsers.contains(effective)) ? effective : null;

                return DropdownButtonFormField<String>(
                  value: safeValue,
                  items: items,
                  onChanged: (v) => setState(() => _targetUserId = v),
                  decoration: const InputDecoration(
                    labelText: 'Потребител',
                    border: OutlineInputBorder(),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _targetNew1,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Нова парола',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _targetNew2,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Повтори новата парола',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _saving || _targetUserId == null
                  ? null
                  : () => _saveForUser(_targetUserId!, _targetNew1.text, _targetNew2.text),
              icon: const Icon(Icons.save),
              label: const Text('Запази парола'),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _saveForUser(String userId, String p1, String p2) async {
    final a = p1.trim();
    final b = p2.trim();
    if (a.isEmpty || b.isEmpty) {
      _snack('Попълнете двете полета.');
      return;
    }
    if (a != b) {
      _snack('Двете пароли не съвпадат.');
      return;
    }
    setState(() => _saving = true);
    try {
      await widget.db.updateUserPassword(userId: userId, newPassword: a);
      final target = await widget.db.getUserById(userId);
      if (target != null) {
        final salonId = widget.auth.activeSalonId;

		if (salonId == null) {
		  throw Exception('No active salon');
		}
        await widget.db.enqueueUserUpsert(userId: userId, salonId: salonId);
      }
      final sync = SyncService.instance;
      if (sync != null &&
          widget.auth.accessToken != null &&
          widget.auth.deviceId != null &&
          widget.auth.activeSalonId != null) {
        sync.configureSession(
          salonId: widget.auth.activeSalonId!,
          token: widget.auth.accessToken!,
          deviceId: widget.auth.deviceId!,
        );
        await sync.scheduleSync(reason: 'change-password');
      }
      _snack('Запазено.');
    } catch (e) {
      _snack('Грешка: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class _ScopePickerInline extends StatelessWidget {
  final AppDatabase db;
  final String value;
  final ValueChanged<String?> onChanged;

  const _ScopePickerInline({required this.db, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Salon>>(
      stream: db.watchSalons(),
      builder: (context, snap) {
        final salons = snap.data ?? const <Salon>[];
        final items = <DropdownMenuItem<String>>[
          for (final s in salons)
            DropdownMenuItem(value: s.id, child: Text(s.name, overflow: TextOverflow.ellipsis)),
        ];
        final allowed = items.map((e) => e.value).whereType<String>().toSet();
        final effective = allowed.contains(value) ? value : (salons.isNotEmpty ? salons.first.id : '');
        if (effective != value) {
          WidgetsBinding.instance.addPostFrameCallback((_) => onChanged(effective));
        }
        return DropdownButtonFormField<String>(
          value: allowed.contains(value) ? value : (effective.isEmpty ? null : effective),
          items: items,

          onChanged: onChanged,
          decoration: const InputDecoration(
            labelText: 'Група',
            border: OutlineInputBorder(),
          ),
        );
      },
    );
  }
}
