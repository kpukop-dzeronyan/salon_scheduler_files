import 'package:flutter/material.dart';

import '../../../data/local/app_db.dart';

class CatalogVariantsScreen extends StatefulWidget {
  final AppDatabase db;
  final String salonId;
  final CatalogItem parentItem;

  const CatalogVariantsScreen({
    super.key,
    required this.db,
    required this.salonId,
    required this.parentItem,
  });

  @override
  State<CatalogVariantsScreen> createState() => _CatalogVariantsScreenState();
}

class _CatalogVariantsScreenState extends State<CatalogVariantsScreen> {
  Future<void> _addOrEdit({AttributeOption? existing}) async {
    final ctrl = TextEditingController(text: existing?.value ?? '');
    final res = await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(existing == null ? 'Добави номер/код' : 'Редакция на номер/код'),
          content: TextField(
            controller: ctrl,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'Напр. 7.1 / 10.0 / Crystal 01'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отказ')),
            FilledButton(
              onPressed: () => Navigator.pop(context, ctrl.text.trim()),
              child: const Text('Запази'),
            ),
          ],
        );
      },
    );
    if (res == null || res.isEmpty) return;

    if (existing == null) {
      // Put at the end.
      final rows = await widget.db
          .watchCatalogVariantsAdmin(salonId: widget.salonId, parentItemId: widget.parentItem.id)
          .first;
      final maxOrder = rows.isEmpty
          ? 0
          : rows.map((e) => e.orderIndex).reduce((a, b) => a > b ? a : b);
      await widget.db.upsertCatalogVariant(
        salonId: widget.salonId,
        parentItemId: widget.parentItem.id,
        value: res,
        orderIndex: maxOrder + 1,
        isActive: true,
      );
    } else {
      await widget.db.updateCatalogVariant(id: existing.id, value: res);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Номера/кодове • ${widget.parentItem.name}'),
        actions: [
          IconButton(onPressed: () => _addOrEdit(), icon: const Icon(Icons.add)),
        ],
      ),
      body: StreamBuilder<List<AttributeOption>>(
        stream: widget.db.watchCatalogVariantsAdmin(salonId: widget.salonId, parentItemId: widget.parentItem.id),
        builder: (context, snap) {
          final rows = snap.data ?? const <AttributeOption>[];
          if (rows.isEmpty) {
            return const Center(child: Text('Няма добавени номера/кодове'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final r = rows[i];
              return Card(
                child: ListTile(
                  title: Text(
                    r.isActive ? r.value : '${r.value} (inactive)',
                    style: r.isActive ? null : TextStyle(color: Theme.of(context).disabledColor),
                  ),
                  subtitle: Text('Подредба: ${r.orderIndex}'),
                  trailing: Wrap(
                    spacing: 4,
                    children: [
                      IconButton(
                        tooltip: 'Нагоре',
                        icon: const Icon(Icons.arrow_upward),
                        onPressed: () => widget.db.reorderCatalogVariant(
                          salonId: widget.salonId,
                          parentItemId: widget.parentItem.id,
                          id: r.id,
                          direction: -1,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Надолу',
                        icon: const Icon(Icons.arrow_downward),
                        onPressed: () => widget.db.reorderCatalogVariant(
                          salonId: widget.salonId,
                          parentItemId: widget.parentItem.id,
                          id: r.id,
                          direction: 1,
                        ),
                      ),
                      Switch(
                        value: r.isActive,
                        onChanged: (v) => widget.db.updateCatalogVariant(id: r.id, isActive: v),
                      ),
                    ],
                  ),
                  onTap: () => _addOrEdit(existing: r),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addOrEdit(),
        icon: const Icon(Icons.add),
        label: const Text('Добави'),
      ),
    );
  }
}
