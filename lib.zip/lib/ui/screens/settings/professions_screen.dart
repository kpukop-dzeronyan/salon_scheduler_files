import 'package:flutter/material.dart';

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import '../../../services/sync_service.dart';

class ProfessionsScreen extends StatelessWidget {
  final AppDatabase db;
  final AuthState auth;

  const ProfessionsScreen({super.key, required this.db, required this.auth});

  @override
  Widget build(BuildContext context) {
    final session = auth.user;
    if (session == null || !session.isAdmin) {
      return const Scaffold(body: Center(child: Text('Нямате права за този екран.')));
    }

    final salonId = auth.activeSalonId;
    if (salonId == null) {
      return const Scaffold(body: Center(child: Text('Моля, избери салон от менюто „Смени салон“.')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Професии')),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Нова'),
        onPressed: () => _addOrEdit(
          context,
          db: db,
          auth: auth,
          salonId: salonId,
          id: null,
          initial: '',
        ),
      ),
      body: StreamBuilder<List<AttributeOption>>(
        stream: db.watchProfessionsBySalon(salonId),
        builder: (context, snap) {
          final rows = snap.data ?? const <AttributeOption>[];
          if (rows.isEmpty) {
            return const Center(child: Text('Няма професии.'));
          }

          return ListView.separated(
            itemCount: rows.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final p = rows[i];
              final inactive = !p.isActive;
              return ListTile(
                title: Text(
                  inactive ? '${p.value} (inactive)' : p.value,
                  style: inactive ? TextStyle(color: Theme.of(context).disabledColor) : null,
                ),
                subtitle: Text('Подредба: ${p.orderIndex}'),
                trailing: Wrap(
                  spacing: 4,
                  children: [
                    IconButton(
                      tooltip: 'Нагоре',
                      onPressed: () async {
                        await db.reorderProfession(salonId: salonId, id: p.id, direction: -1);
                        await _syncNow(auth: auth, salonId: salonId);
                      },
                      icon: const Icon(Icons.arrow_upward),
                    ),
                    IconButton(
                      tooltip: 'Надолу',
                      onPressed: () async {
                        await db.reorderProfession(salonId: salonId, id: p.id, direction: 1);
                        await _syncNow(auth: auth, salonId: salonId);
                      },
                      icon: const Icon(Icons.arrow_downward),
                    ),
                    Switch(
                      value: p.isActive,
                      onChanged: (v) async {
                        await db.updateProfession(id: p.id, isActive: v);
                        await _syncNow(auth: auth, salonId: salonId);
                      },
                    ),
                  ],
                ),
                onTap: () => _addOrEdit(
                  context,
                  db: db,
                  auth: auth,
                  salonId: salonId,
                  id: p.id,
                  initial: p.value,
                ),
              );
            },
          );
        },
      ),
    );
  }
}

Future<void> _addOrEdit(
  BuildContext context, {
  required AppDatabase db,
  required AuthState auth,
  required String salonId,
  required String? id,
  required String initial,
}) async {
  final ctrl = TextEditingController(text: initial);
  final title = id == null ? 'Нова професия' : 'Редакция на професия';

  final value = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        decoration: const InputDecoration(
          labelText: 'Име/код (пример: hairdresser)',
          border: OutlineInputBorder(),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отказ')),
        FilledButton(
          onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
          child: const Text('Запази'),
        ),
      ],
    ),
  );

  if (value == null || value.trim().isEmpty) return;

  try {
    if (id == null) {
      await db.upsertProfession(salonId: salonId, value: value.trim());
    } else {
      await db.updateProfession(id: id, value: value.trim());
    }

    await _syncNow(auth: auth, salonId: salonId);
  } catch (e) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Грешка: $e')));
  }
}

Future<void> _syncNow({
  required AuthState auth,
  required String salonId,
}) async {
  final sync = SyncService.instance;
  final token = auth.accessToken;
  final deviceId = auth.deviceId;

  if (sync == null || token == null || token.isEmpty || deviceId == null || deviceId.isEmpty) {
    return;
  }

  sync.configureSession(
    salonId: salonId,
    token: token,
    deviceId: deviceId,
  );

  await sync.scheduleSync(reason: 'profession-save');
}
