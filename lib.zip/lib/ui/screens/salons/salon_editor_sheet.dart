import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import '../../../services/sync_service.dart';
import '../login_screen.dart';

class SalonEditorSheet extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;
  final Salon? existing;
  final int? existingSalonNumber;
  final List<Salon> templateCandidates;

  const SalonEditorSheet({
    super.key,
    required this.db,
    required this.auth,
    required this.existing,
    required this.existingSalonNumber,
    required this.templateCandidates,
  });

  @override
  State<SalonEditorSheet> createState() => _SalonEditorSheetState();
}

class _SalonEditorSheetState extends State<SalonEditorSheet> {
  static const String _apiBase = 'https://armadner.com/salon_api';

  late final TextEditingController _nameCtl;
  late final TextEditingController _numberCtl;
  String? _templateSalonId;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameCtl = TextEditingController(text: widget.existing?.name ?? '');
    _numberCtl = TextEditingController(text: widget.existingSalonNumber?.toString() ?? '');
    if (widget.existing == null) {
      _templateSalonId = null;
    }
  }

  @override
  void dispose() {
    _nameCtl.dispose();
    _numberCtl.dispose();
    super.dispose();
  }

  Future<String> _createSalonOnServer({required String name, required int salonNumber}) async {
    final token = widget.auth.accessToken;
    final sourceSalonId = widget.auth.currentSalonId;
    if (token == null || token.isEmpty || sourceSalonId == null || sourceSalonId.isEmpty) {
      throw Exception('Липсва активна сесия за създаване на салон.');
    }

    final res = await http.post(
      Uri.parse('$_apiBase/salon_create.php'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'name': name,
        'salon_number': salonNumber,
        'source_salon_id': sourceSalonId,
      }),
    );

    final Map<String, dynamic> data = (() {
      try {
        return jsonDecode(res.body) as Map<String, dynamic>;
      } catch (_) {
        return <String, dynamic>{'error': 'invalid_json', 'raw': res.body};
      }
    })();

    if (res.statusCode != 200) {
      final msg = (data['message'] ?? data['error'] ?? 'server_error').toString();
      throw Exception(msg);
    }

    final salonId = (data['salon_id'] ?? '').toString().trim();
    if (salonId.isEmpty) {
      throw Exception('Сървърът не върна salon_id.');
    }
    return salonId;
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final name = _nameCtl.text.trim();
      final salonNumber = int.tryParse(_numberCtl.text.trim());
      if (name.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Въведете име.')));
        return;
      }
      if (salonNumber == null || salonNumber <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Въведете валиден номер на салон.')));
        return;
      }

      if (widget.existing == null) {
        final newSalonId = await _createSalonOnServer(name: name, salonNumber: salonNumber);

        await widget.db.createSalonWithTemplate(
          name: name,
          salonId: newSalonId,
          templateSalonId: _templateSalonId,
        );
        await widget.db.enqueueAllSyncableConfigForSalon(newSalonId, salonNumber: salonNumber);

        final token = widget.auth.accessToken;
        final deviceId = widget.auth.deviceId;
        if (token == null || token.isEmpty || deviceId == null || deviceId.isEmpty) {
          throw Exception('Липсва sync сесия за новия салон.');
        }

        final sync = SyncService.instance ?? SyncService(widget.db);
        await sync.sync(
          salonId: newSalonId,
          token: token,
          deviceId: deviceId,
          reason: 'create_salon_template',
        );

        if (!mounted) return;
        await showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Салонът е създаден'),
            content: const Text(
              'Новият салон е създаден успешно. Ще бъдете изведени от текущата сесия, за да влезете отново и да заредите новия салон.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK'),
              ),
            ],
          ),
        );

        if (!mounted) return;
        sync.stopAutoSync();
        widget.auth.logout();
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => LoginScreen(auth: widget.auth)),
          (_) => false,
        );
        return;
      } else {
        await widget.db.renameSalon(
          salonId: widget.existing!.id,
          newName: name,
          salonNumber: salonNumber,
        );
      }

      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Грешка: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    final isCreate = widget.existing == null;
    final templates = widget.templateCandidates;

    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: bottom + 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  isCreate ? 'Нов салон' : 'Редакция на салон',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.of(context).pop(),
              )
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _nameCtl,
            decoration: const InputDecoration(
              labelText: 'Име на салон',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _numberCtl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Номер на салон',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          if (isCreate) ...[
            DropdownButtonFormField<String?>(
              value: _templateSalonId,
              decoration: const InputDecoration(
                labelText: 'Шаблон (по желание)',
                border: OutlineInputBorder(),
              ),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text('Без шаблон (чист салон)'),
                ),
                ...templates.map(
                  (s) => DropdownMenuItem<String?>(
                    value: s.id,
                    child: Text(s.name),
                  ),
                ),
              ],
              onChanged: (v) => setState(() => _templateSalonId = v),
            ),
            const SizedBox(height: 8),
            Text(
              'При шаблон се копират: работно време, slotMinutes, професии, услуги, продукти и вариантите им.',
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ],
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save),
            label: Text(_saving ? 'Запазване...' : (isCreate ? 'Създай' : 'Запази')),
          ),
        ],
      ),
    );
  }
}
