import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import 'salon_editor_sheet.dart';

class SalonsScreen extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;

  const SalonsScreen({super.key, required this.db, required this.auth});

  @override
  State<SalonsScreen> createState() => _SalonsScreenState();
}

class _SalonsScreenState extends State<SalonsScreen> {
  static const String _apiBase = 'https://armadner.com/salon_api';

  Map<String, int?> _numbersBySalonId = const {};

  @override
  void initState() {
    super.initState();
    _loadSalonNumbers();
  }

  Future<void> _loadSalonNumbers() async {
    try {
      final res = await http.get(Uri.parse('$_apiBase/salon_list.php'));
      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final raw = (data['salons'] as List? ?? const []);
      final map = <String, int?>{};
      for (final item in raw) {
        if (item is! Map) continue;
        final row = Map<String, dynamic>.from(item);
        final id = (row['salon_id'] ?? '').toString();
        if (id.isEmpty) continue;
        final n = row['number'] is num ? (row['number'] as num).toInt() : int.tryParse('${row['number'] ?? ''}');
        map[id] = n;
      }
      if (mounted) {
        setState(() => _numbersBySalonId = map);
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.auth.user;
    if (user == null || !user.isAdmin) {
      return const Scaffold(body: Center(child: Text('Нямате права.')));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Салони'),
        actions: [
          IconButton(
            tooltip: 'Обнови',
            onPressed: _loadSalonNumbers,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final salons = await widget.db.getAllSalons();
          if (!context.mounted) return;
          await showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            useSafeArea: true,
            builder: (_) => SalonEditorSheet(
              db: widget.db,
              auth: widget.auth,
              existing: null,
              existingSalonNumber: null,
              templateCandidates: salons,
            ),
          );
          await _loadSalonNumbers();
        },
        icon: const Icon(Icons.add),
        label: const Text('Нов салон'),
      ),
      body: StreamBuilder<List<Salon>>(
        stream: widget.db.watchSalons(),
        builder: (context, snap) {
          final salons = snap.data ?? const <Salon>[];

          if (salons.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.store_mall_directory_outlined, size: 44),
                    const SizedBox(height: 12),
                    const Text(
                      'Няма създадени салони.',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Натиснете „Нов салон“, за да създадете първия салон.\nЗа първия салон няма шаблон и настройките ще са по подразбиране.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.separated(
            itemCount: salons.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final s = salons[i];
              final isActive = (widget.auth.activeSalonId == s.id);
              final salonNumber = _numbersBySalonId[s.id];
              return ListTile(
                leading: const Icon(Icons.store_mall_directory_outlined),
                title: Text(s.name),
                subtitle: Text(
                  salonNumber != null ? '№ $salonNumber' : 'Без номер',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: isActive ? const Icon(Icons.check, color: Colors.green) : null,
                onTap: () async {
                  await showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    useSafeArea: true,
                    builder: (_) => SalonEditorSheet(
                      db: widget.db,
                      auth: widget.auth,
                      existing: s,
                      existingSalonNumber: salonNumber,
                      templateCandidates: const [],
                    ),
                  );
                  await _loadSalonNumbers();
                },
              );
            },
          );
        },
      ),
    );
  }
}
