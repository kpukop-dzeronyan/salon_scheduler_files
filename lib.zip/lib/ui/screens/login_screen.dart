import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../auth_state.dart';
import 'daily_schedule_screen.dart';

class LoginScreen extends StatefulWidget {
  final AuthState auth;
  final String? initialSalonId;
  final String? initialUsername;

  const LoginScreen({
    super.key,
    required this.auth,
    this.initialSalonId,
    this.initialUsername,
  });

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class SalonLoginItem {
  final String id;
  final String name;
  final int? number;

  const SalonLoginItem({
    required this.id,
    required this.name,
    required this.number,
  });

  factory SalonLoginItem.fromJson(Map<String, dynamic> json) {
    return SalonLoginItem(
      id: (json['salon_id'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      number: json['number'] is num ? (json['number'] as num).toInt() : int.tryParse('${json['number'] ?? ''}'),
    );
  }

  String get label {
    if (number != null) return '$number - $name';
    return name;
  }
}

class _LoginScreenState extends State<LoginScreen> {
  static const String _apiBase = 'https://armadner.com/salon_api';

  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  final List<SalonLoginItem> _salons = <SalonLoginItem>[];
  String? selectedSalonId;

  bool rememberMe = true;
  bool loading = false;
  bool loadingSalons = true;
  String? error;

  @override
  void initState() {
    super.initState();
    if (widget.initialUsername != null && widget.initialUsername!.trim().isNotEmpty) {
      userCtrl.text = widget.initialUsername!.trim();
    }
    _loadSalons();
  }

  Future<void> _loadSalons() async {
    setState(() {
      loadingSalons = true;
      error = null;
    });

    try {
      final res = await http.get(Uri.parse('$_apiBase/salon_list.php'));
      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}: ${res.body}');
      }
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final list = (data['salons'] as List? ?? const [])
          .whereType<Map>()
          .map((e) => SalonLoginItem.fromJson(Map<String, dynamic>.from(e)))
          .where((s) => s.id.isNotEmpty && s.name.isNotEmpty)
          .toList();

      _salons
        ..clear()
        ..addAll(list);

      if (_salons.isNotEmpty) {
        final preferred = widget.initialSalonId?.trim();
        final hasPreferred = preferred != null && _salons.any((s) => s.id == preferred);
        selectedSalonId = hasPreferred ? preferred : _salons.first.id;
      } else {
        selectedSalonId = null;
      }
    } catch (e) {
      error = 'Неуспешно зареждане на салоните';
    }

    if (mounted) {
      setState(() {
        loadingSalons = false;
      });
    }
  }

  @override
  void dispose() {
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Изберете салон, въведете име и парола',
                        style: Theme.of(context).textTheme.headlineSmall,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      if (loadingSalons)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 12),
                          child: CircularProgressIndicator(),
                        )
                      else
                        DropdownButtonFormField<String>(
                          value: selectedSalonId,
                          items: _salons
                              .map(
                                (s) => DropdownMenuItem<String>(
                                  value: s.id,
                                  child: Text(s.label),
                                ),
                              )
                              .toList(),
                          onChanged: _salons.isEmpty
                              ? null
                              : (v) => setState(() => selectedSalonId = v),
                          decoration: InputDecoration(
                            labelText: 'Салон',
                            border: const OutlineInputBorder(),
                            suffixIcon: IconButton(
                              tooltip: 'Обнови',
                              onPressed: loading ? null : _loadSalons,
                              icon: const Icon(Icons.refresh),
                            ),
                          ),
                        ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: userCtrl,
                        autocorrect: false,
                        enableSuggestions: false,
                        textCapitalization: TextCapitalization.none,
                        decoration: const InputDecoration(
                          labelText: 'Име',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.person),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: passCtrl,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'Парола',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.lock),
                        ),
                      ),
                      const SizedBox(height: 6),
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        value: rememberMe,
                        onChanged: (v) => setState(() => rememberMe = v ?? false),
                        title: const Text('Запомни ме'),
                        controlAffinity: ListTileControlAffinity.leading,
                      ),
                      const SizedBox(height: 10),
                      if (error != null)
                        Text(
                          error!,
                          style: TextStyle(color: Theme.of(context).colorScheme.error),
                          textAlign: TextAlign.center,
                        ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: (loading || loadingSalons) ? null : _doLogin,
                          child: loading
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Text('Вход'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _doLogin() async {
    final salonId = selectedSalonId;
    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    if (salonId == null || salonId.isEmpty) {
      setState(() => error = 'Изберете салон');
      return;
    }
    if (username.isEmpty || password.isEmpty) {
      setState(() => error = 'Въведете име и парола');
      return;
    }

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final ok = await widget.auth.loginApiAndBootstrap(
        salonId: salonId,
        username: username,
        password: password,
        rememberMe: rememberMe,
      );

      if (!mounted) return;
      if (!ok) {
        setState(() {
          error = 'Грешен салон, име или парола';
          loading = false;
        });
        return;
      }

      if (!mounted) return;
      setState(() {
        loading = false;
      });
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => DailyScheduleScreen(db: widget.auth.db, auth: widget.auth),
        ),
        (_) => false,
      );
      return;
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = 'Грешка при вход: $e';
        loading = false;
      });
      return;
    }

    if (mounted) {
      setState(() {
        loading = false;
      });
    }
  }
}
