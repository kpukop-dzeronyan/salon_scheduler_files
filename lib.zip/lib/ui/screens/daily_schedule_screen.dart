import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../../auth_state.dart';
import '../../data/local/app_db.dart';
import 'entry_editor_sheet.dart';
import 'salon_work_hours_screen.dart';
import 'salons/salons_screen.dart';
import 'users/users_screen.dart';
import 'settings/professions_screen.dart';
import 'settings/catalog_items_admin_screen.dart';
import 'settings/change_password_screen.dart';
import 'display_settings_screen.dart';

import 'backend_sync_test_screen.dart';
class DailyScheduleScreen extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;

  const DailyScheduleScreen({super.key, required this.db, required this.auth});

  @override
  State<DailyScheduleScreen> createState() => _DailyScheduleScreenState();
}

class _DailyScheduleScreenState extends State<DailyScheduleScreen> {
  static const double _baseTimeColWidth = 72.0;
  static const double _baseHeaderHeight = 44.0;
  static const double _baseRowHeight = 56.0;
  DateTime selectedDate = DateTime.now();

  final ScrollController _timeV = ScrollController();
  final ScrollController _gridV = ScrollController();
  final ScrollController _headerH = ScrollController();
  final ScrollController _gridH = ScrollController();
  // Auto-scroll + highlight current time slot
  DateTime? _autoScrollDate;
  bool _autoScrollScheduled = false;

  bool _isSameDate(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  int _currentSlotIndex(List<int> slots, int currentMinute) {
    if (slots.isEmpty) return 0;
    for (int i = 0; i < slots.length; i++) {
      final start = slots[i];
      final end = (i + 1 < slots.length) ? slots[i + 1] : 24 * 60;
      if (start <= currentMinute && currentMinute < end) return i;
    }
    // If before first slot -> 0; if after last slot -> last
    if (currentMinute < slots.first) return 0;
    return slots.length - 1;
  }

  void _scheduleAutoScrollToNow({required List<int> slots, required double rowExtent}) {
    final today = DateTime.now();
    if (!_isSameDate(selectedDate, today)) {
      _autoScrollDate = selectedDate;
      return; // only auto-scroll when viewing today
    }

    if (_autoScrollDate != null && _isSameDate(_autoScrollDate!, selectedDate)) return;
    if (_autoScrollScheduled) return;
    _autoScrollScheduled = true;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _autoScrollScheduled = false;
      if (!mounted) return;

      final now = TimeOfDay.now();
      final currentMinute = now.hour * 60 + now.minute;
      final index = _currentSlotIndex(slots, currentMinute);
      final offset = (index * rowExtent).toDouble();

      // Jump both vertical controllers; listeners will sync without loops thanks to guards
      if (_timeV.hasClients) _timeV.jumpTo(offset.clamp(0.0, _timeV.position.maxScrollExtent));
      if (_gridV.hasClients) _gridV.jumpTo(offset.clamp(0.0, _gridV.position.maxScrollExtent));

      _autoScrollDate = selectedDate;
    });
  }
  final ScrollController _footerH = ScrollController();

  bool _syncV = false;
  bool _syncH = false;

  static const double timeColWidth = 72;
  static const double headerHeight = 56;
  static const double rowHeight = 44;
  // Employee column width is computed at runtime to fill the remaining screen width
  // (so you see the time column + exactly one staff column).
  static const double _minEmployeeColWidth = 160;

  @override
  void initState() {
    super.initState();

    _timeV.addListener(() {
      if (_syncV) return;
      _syncV = true;
      if (_gridV.hasClients) _gridV.jumpTo(_timeV.offset);
      _syncV = false;
    });

    _gridV.addListener(() {
      if (_syncV) return;
      _syncV = true;
      if (_timeV.hasClients) _timeV.jumpTo(_gridV.offset);
      _syncV = false;
    });

    _headerH.addListener(() {
      if (_syncH) return;
      _syncH = true;
      if (_gridH.hasClients) _gridH.jumpTo(_headerH.offset);
      if (_footerH.hasClients) _footerH.jumpTo(_headerH.offset);
      _syncH = false;
    });

    _gridH.addListener(() {
      if (_syncH) return;
      _syncH = true;
      if (_headerH.hasClients) _headerH.jumpTo(_gridH.offset);
      if (_footerH.hasClients) _footerH.jumpTo(_gridH.offset);
      _syncH = false;
    });

    _footerH.addListener(() {
      if (_syncH) return;
      _syncH = true;
      if (_headerH.hasClients) _headerH.jumpTo(_footerH.offset);
      if (_gridH.hasClients) _gridH.jumpTo(_footerH.offset);
      _syncH = false;
    });
  }

  @override
  void dispose() {
    _timeV.dispose();
    _gridV.dispose();
    _headerH.dispose();
    _gridH.dispose();
    _footerH.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.auth.user;
    if (user == null) {
      return const Scaffold(body: SizedBox.shrink());
    }
    final salonId = widget.auth.activeSalonId ?? user.homeSalonId;
    final date = AppDatabase.dateOnly(selectedDate);

    final today = AppDatabase.dateOnly(DateTime.now());
    final maxUserDate = today.add(const Duration(days: 30));
    final canGoPrev = user.isAdmin || !date.isAtSameMomentAs(today);
    final canGoNext = user.isAdmin || date.isBefore(maxUserDate);

    return StreamBuilder<List<Salon>>(
      stream: widget.db.watchSalons(),
      builder: (context, salonsSnap) {
        final salons = salonsSnap.data ?? const <Salon>[];
        final activeSalon = salons.where((s) => s.id == salonId).cast<Salon?>().firstWhere(
              (s) => s != null,
              orElse: () => null,
            );
        final salonName = activeSalon?.name ?? widget.auth.activeSalonName ?? 'Салон';

        return Scaffold(
      // ✅ Drawer is now actually attached to the screen
      drawer: _AppMenuDrawer(
        isAdmin: user.isAdmin,
        salonName: salonName,
        onDisplaySettings: () {
          Navigator.of(context).pop();
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => DisplaySettingsScreen(auth: widget.auth)),
          );
        },
        onChangePassword: () {
          Navigator.of(context).pop(); // close drawer
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ChangePasswordScreen(db: widget.db, auth: widget.auth),
            ),
          );
        },
        onWorkHours: user.isAdmin
            ? () async {
                Navigator.of(context).pop(); // close drawer
                await Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => SalonWorkHoursScreen(db: widget.db, auth: widget.auth),
                  ),
                );
              }
            : null,
        onSwitchSalon: null,
        onSalons: user.isAdmin
            ? () async {
                Navigator.of(context).pop();
                await Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => SalonsScreen(db: widget.db, auth: widget.auth)),
                );
              }
            : null,
        onUsers: user.isAdmin
            ? () async {
                Navigator.of(context).pop();
                await Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => UsersScreen(db: widget.db, auth: widget.auth)),
                );
              }
            : null,
        onProfessions: user.isAdmin
            ? () async {
                Navigator.of(context).pop();
                await Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => ProfessionsScreen(db: widget.db, auth: widget.auth)),
                );
              }
            : null,

        onServices: user.isAdmin
            ? () async {
                Navigator.of(context).pop();
                await Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => CatalogItemsAdminScreen(db: widget.db, auth: widget.auth, type: 'service'),
                  ),
                );
              }
            : null,
        onProducts: user.isAdmin
            ? () async {
                Navigator.of(context).pop();
                await Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => CatalogItemsAdminScreen(db: widget.db, auth: widget.auth, type: 'product'),
                  ),
                );
              }
            : null,

        onLogout: () {
          Navigator.of(context).pop(); // close drawer
          widget.auth.logout();
        },
      ),
      appBar: AppBar(
        titleSpacing: 12,
        title: Text(
          _fmtDate(date),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        actions: [
		IconButton(
  tooltip: 'Backend Sync (test)',
  icon: const Icon(Icons.cloud_sync),
  onPressed: () {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => BackendSyncTestScreen(db: widget.db),
      ),
    );
  },
),
          IconButton(
            tooltip: 'Назад 1 ден',
            onPressed: canGoPrev
                ? () => setState(() => selectedDate = selectedDate.subtract(const Duration(days: 1)))
                : null,
            icon: const Icon(Icons.chevron_left),
          ),
          IconButton(
            tooltip: 'Напред 1 ден',
            onPressed: canGoNext
                ? () => setState(() => selectedDate = selectedDate.add(const Duration(days: 1)))
                : null,
            icon: const Icon(Icons.chevron_right),
          ),
          IconButton(
            tooltip: 'Избери дата',
            onPressed: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: AppDatabase.dateOnly(selectedDate),
                firstDate: user.isAdmin ? DateTime(2020, 1, 1) : today,
                lastDate: user.isAdmin ? DateTime(2035, 12, 31) : maxUserDate,
              );
              if (picked != null) {
                setState(() => selectedDate = picked);
              }
            },
            icon: const Icon(Icons.calendar_month),
          ),
          IconButton(
            tooltip: 'Днес',
            onPressed: () => setState(() => selectedDate = DateTime.now()),
            icon: const Icon(Icons.today),
          ),
          const SizedBox(width: 8),

          // ❌ Logout removed from AppBar (now in drawer)
          // IconButton(
          //   tooltip: 'Изход',
          //   onPressed: widget.auth.logout,
          //   icon: const Icon(Icons.logout),
          // ),
        ],
      ),
      body: StreamBuilder<SalonSetting?>(
        stream: widget.db.watchSalonSettingsBySalon(salonId),
        builder: (context, settingsSnap) {
          final settings = settingsSnap.data;
          final slotMinutes = settings?.slotMinutes ?? 10;
          return FutureBuilder<(int startMinute, int endMinute)>(
            future: widget.db.getSalonHoursForDate(salonId: salonId, date: date),
            builder: (context, whSnap) {
              final (dayStart, dayEnd) = whSnap.data ?? (480, 1320);
              final slots = _buildSlots(dayStart, dayEnd, slotMinutes);

              return StreamBuilder<List<StaffColumn>>(
                stream: widget.db.watchStaffColumnsForDate(salonId: salonId, date: date),
                builder: (context, staffSnap) {
                  var staff = staffSnap.data ?? const <StaffColumn>[];

                  if (!user.isAdmin) {
                    final idx = staff.indexWhere((c) => c.userId == user.id);
                    if (idx > 0) {
                      final mine = staff[idx];
                      staff = [mine, ...staff.where((c) => c.id != mine.id)];
                    }
                  }

                  return FutureBuilder<WorkDay>(
                    future: widget.db.ensureWorkDay(salonId: salonId, date: date),
                    builder: (context, daySnap) {
                      if (!daySnap.hasData) return const Center(child: CircularProgressIndicator());
                      final workDay = daySnap.data!;

                      return StreamBuilder<List<TimeSlotEntryWithMoney>>(
                        stream: widget.db.watchEntriesWithMoney(workDayId: workDay.id),
                        builder: (context, entrySnap) {
                          final entries = entrySnap.data ?? const <TimeSlotEntryWithMoney>[];
                          final byCell = <String, TimeSlotEntryWithMoney>{
                            for (final e in entries) '${e.entry.staffColumnId}:${e.entry.slotMinute}': e,
                          };

                          // Totals per staff column and overall.
                          final colTotals = <String, (double s, double p)>{};
                          double totalS = 0;
                          double totalP = 0;
                          for (final e in entries) {
                            final m = e.money;
                            if (m == null) continue;
                            final s = m.servicesTotal;
                            final p = m.productsTotal;
                            totalS += s;
                            totalP += p;
                            final cur = colTotals[e.entry.staffColumnId] ?? (0.0, 0.0);
                            colTotals[e.entry.staffColumnId] = (cur.$1 + s, cur.$2 + p);
                          }

                          return StreamBuilder<WorkDayEntryLineMap>(
                            stream: widget.db.watchEntryLineDisplaysForWorkDay(workDayId: workDay.id),
                            builder: (context, linesSnap) {
                              final lineMap = linesSnap.data ?? const <String, List<EntryLineDisplay>>{};

                              String namesForEntry(
                                String entryId, {
                                String? onlyType,
                              }) {
                                final all = lineMap[entryId] ?? const <EntryLineDisplay>[];
                                final lines = onlyType == null
                                    ? all
                                    : all.where((l) {
                                        String norm(String t) {
                                          final s = t.trim().toLowerCase();
                                          if (s == '1') return 'service';
                                          if (s == '2') return 'product';
                                          if (s == '3') return 'service'; // package -> show as service pill
                                          if (s == 'package') return 'service';
                                          return s;
                                        }
                                        return norm(l.lineType) == norm(onlyType);
                                      }).toList(growable: false);
                                if (lines.isEmpty) return '';

                                // Keep pills readable inside fixed-height grid rows.
                                // Show up to 3 items, then "+N".
                                final parts = <String>[];
                                final take = lines.length > 3 ? 3 : lines.length;
                                for (var i = 0; i < take; i++) {
                                  final l = lines[i];
                                  final n = l.variant == null ? l.name : '${l.name} ${l.variant}';
                                  parts.add(n);
                                }
                                final more = lines.length - take;
                                if (more > 0) parts.add('+$more');
                                return parts.join(', ');
                              }

                              return LayoutBuilder(
                                builder: (context, constraints) {
                                  final scheme = Theme.of(context).colorScheme;
                                  final isDark = Theme.of(context).brightness == Brightness.dark;
                                  final zebraEven = isDark ? scheme.surface : Colors.white;
                                  final zebraOdd = isDark ? scheme.surfaceContainerHighest : const Color(0xFFEBF3F5);

                                  final viewportWidth = constraints.maxWidth.isFinite
                                      ? constraints.maxWidth
                                      : MediaQuery.of(context).size.width;

                                  final tcw = timeColWidth.isFinite ? timeColWidth : _baseTimeColWidth;
                                  final hh = headerHeight.isFinite ? headerHeight : _baseHeaderHeight;
                                  final rh = rowHeight.isFinite ? rowHeight : _baseRowHeight;

                                  final now = TimeOfDay.now();
                                  final nowMinute = now.hour * 60 + now.minute;
                                  final isToday = _isSameDate(selectedDate, DateTime.now());
                                  final nowIndex = isToday ? _currentSlotIndex(slots, nowMinute) : -1;
                                  _scheduleAutoScrollToNow(slots: slots, rowExtent: rh);


                                  final available = (viewportWidth - tcw);
                                  final employeeColWidth = math.max(
                                    _minEmployeeColWidth,
                                    (available.isFinite && available > 0) ? available : _minEmployeeColWidth,
                                  );

                                  return Column(
                                    children: [
                              // Show the full salon name on its own line (wraps),
                              // because many salons have long names.
                              Padding(
                                padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    salonName,
                                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: hh,
                                child: Row(
                                  children: [
                                    Container(
                                      width: tcw,
                                      height: hh,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).colorScheme.surface,
                                        border: const Border(right: BorderSide(width: 1), bottom: BorderSide(width: 1)),
                                      ),
                                      child: const Icon(Icons.access_time, size: 18),
                                    ),
                                    Expanded(
                                      child: SingleChildScrollView(
                                        controller: _headerH,
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: staff.map((c) {
                                            return Container(
                                              width: employeeColWidth,
                                              height: hh,
                                              alignment: Alignment.centerLeft,
                                              padding: const EdgeInsets.symmetric(horizontal: 12),
                                              decoration: BoxDecoration(
                                                color: Theme.of(context).colorScheme.surface,
                                                border: const Border(right: BorderSide(width: 1), bottom: BorderSide(width: 1)),
                                              ),
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    c.displayName,
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                    style: Theme.of(context).textTheme.titleMedium,
                                                  ),
                                                  Text(c.profession, style: Theme.of(context).textTheme.bodySmall),
                                                ],
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: tcw,
                                      child: ListView.builder(
                                        controller: _timeV,
                                        itemCount: slots.length,
                                        itemExtent: rh,
                                        itemBuilder: (context, i) {
                                          final minute = slots[i];
                                          return Container(
										  alignment: Alignment.center,
										  decoration: BoxDecoration(
											color: (i == nowIndex) ? (isDark ? scheme.primaryContainer.withOpacity(0.45) : const Color(0xFFB3E5FC)) : (i.isEven ? zebraEven : zebraOdd),
											border: const Border(
											  right: BorderSide(width: 1),
											  bottom: BorderSide(width: 1),
											),
										  ),
										  child: Text(
											_fmtMinute(minute),
											style: Theme.of(context).textTheme.bodySmall,
										  ),
										);
                                        },
                                      ),
                                    ),
                                    Expanded(
                                      child: SingleChildScrollView(
                                        controller: _gridH,
                                        scrollDirection: Axis.horizontal,
                                        child: SizedBox(
                                          width: staff.length * employeeColWidth,
                                          child: ListView.builder(
                                            controller: _gridV,
                                            itemCount: slots.length,
                                            itemExtent: rh,
                                            itemBuilder: (context, row) {
                                              final slotMinute = slots[row];
                                              return Row(
                                                children: List.generate(staff.length, (col) {
                                                  final staffCol = staff[col];
                                                  final key = '${staffCol.id}:$slotMinute';
                                                  final entry = byCell[key];

                                                  final bg = (row == nowIndex) ? (isDark ? scheme.primaryContainer.withOpacity(0.30) : const Color(0xFFB3E5FC)) : (row.isEven ? zebraEven : zebraOdd);

                                                  return InkWell(
                                                    onTap: () => _onCellTap(context, user, workDay, staffCol, slotMinute, entry),
                                                    child: Container(
                                                      width: employeeColWidth,
                                                      height: rh,
                                                      decoration: BoxDecoration(
                                                        color: bg,
                                                        border: const Border(right: BorderSide(width: 1), bottom: BorderSide(width: 1)),
                                                      ),
                                                      padding: const EdgeInsets.symmetric(horizontal: 8),
                                                      alignment: Alignment.centerLeft,
                                                      child: entry == null
                                                          ? const SizedBox.shrink()
                                                          : _EntryPills(
                                                              locked: entry.entry.locked,
                                                              servicesText: namesForEntry(entry.entry.id, onlyType: 'service'),
                                                              productsText: namesForEntry(entry.entry.id, onlyType: 'product'),
                                                              servicesAmount: entry.money?.servicesTotal,
                                                              productsAmount: entry.money?.productsTotal,
                                                              currencyCode: entry.money?.currencyCode,
                                                            ),
                                                    ),
                                                  );
                                                }),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // Footer totals row
                              SizedBox(
                                height: 56,
                                child: Row(
                                  children: [
                                    Container(
                                      width: tcw,
                                      height: 56,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: Theme.of(context).colorScheme.surface,
                                        border: const Border(right: BorderSide(width: 1), top: BorderSide(width: 1)),
                                      ),
                                      child: const Icon(Icons.summarize_outlined, size: 18),
                                    ),
                                    Expanded(
                                      child: SingleChildScrollView(
                                        controller: _footerH,
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: staff.map((c) {
                                            final t = colTotals[c.id] ?? (0.0, 0.0);
                                            return Container(
                                              width: employeeColWidth,
                                              height: 56,
                                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                              decoration: BoxDecoration(
                                                color: Theme.of(context).colorScheme.surface,
                                                border: const Border(right: BorderSide(width: 1), top: BorderSide(width: 1)),
                                              ),
                                              child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Text('Услуги: ${t.$1.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodySmall),
                                                  Text('Продукти: ${t.$2.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodySmall),
                                                ],
                                              ),
                                            );
                                          }).toList(),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // Overall totals
                              Padding(
                                padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                                child: Align(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    'Общо за деня: ${(totalS + totalP).toStringAsFixed(2)} (У ${totalS.toStringAsFixed(2)} | П ${totalP.toStringAsFixed(2)})',
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ),
                            ],
                              );
                            },
                          );
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        },
          );
        },
      ),
        );
      },
    );
  }

  Future<String?> _pickSalon(BuildContext context) async {
    final salons = await widget.db.getAllSalons();
    if (!mounted) return null;

    return showDialog<String>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Изберете салон'),
          content: SizedBox(
            width: 420,
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: salons.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final s = salons[i];
                return ListTile(
                  title: Text(s.name),
                  subtitle: Text(s.id),
                  onTap: () => Navigator.of(ctx).pop(s.id),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Отказ'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _onCellTap(
    BuildContext context,
    SessionUser user,
    WorkDay workDay,
    StaffColumn staffCol,
    int slotMinute,
    TimeSlotEntryWithMoney? existing,
  ) async {
    if (!user.isAdmin) {
      if (staffCol.userId != user.id) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Нямате права за тази колона')));
        return;
      }
      if (existing != null && existing.entry.locked) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Записът е заключен')));
        return;
      }
    }

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => EntryEditorSheet(
        db: widget.db,
        salonId: workDay.salonId,
        workDay: workDay,
        staffCol: staffCol,
        slotMinute: slotMinute,
        currentUserId: user.id,
		isAdmin: user.isAdmin,
      ),
    );
  }
}

class _AppMenuDrawer extends StatelessWidget {
  final bool isAdmin;
  final String salonName;
  final VoidCallback onDisplaySettings;
  final VoidCallback onChangePassword;
  final VoidCallback? onWorkHours;
  final VoidCallback? onSwitchSalon;
  final VoidCallback? onSalons;
  final VoidCallback? onUsers;
  final VoidCallback? onProfessions;
  final VoidCallback? onServices;
  final VoidCallback? onProducts;
  final VoidCallback onLogout;

  const _AppMenuDrawer({
    required this.isAdmin,
    required this.salonName,
    required this.onDisplaySettings,
    required this.onChangePassword,
    required this.onLogout,
    this.onWorkHours,
    this.onSwitchSalon,
    this.onSalons,
    this.onUsers,
    this.onProfessions,
    this.onServices,
    this.onProducts,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    salonName,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    isAdmin ? 'Администратор' : 'Потребител',
                    style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),

            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  ListTile(
                    leading: const Icon(Icons.text_fields),
                    title: const Text('Размер на интерфейса'),
                    onTap: onDisplaySettings,
                  ),
                  ListTile(
                    leading: const Icon(Icons.password),
                    title: const Text('Смяна на парола'),
                    onTap: onChangePassword,
                  ),

                  if (isAdmin) ...[
                    const Padding(
                      padding: EdgeInsets.fromLTRB(16, 14, 16, 6),
                      child: Text(
                        'Админ инструменти',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                    if (onSwitchSalon != null)
                      ListTile(
                        leading: const Icon(Icons.store_mall_directory_outlined),
                        title: const Text('Смени салон'),
                        onTap: onSwitchSalon,
                      ),
                    if (onWorkHours != null)
                      ListTile(
                        leading: const Icon(Icons.schedule),
                        title: const Text('Работно време'),
                        onTap: onWorkHours,
                      ),
                  ],
                ],
              ),
            ),
                    if (onSalons != null)
                      ListTile(
                        leading: const Icon(Icons.apartment),
                        title: const Text('Салони'),
                        onTap: onSalons,
                      ),
                    if (onUsers != null)
                      ListTile(
                        leading: const Icon(Icons.people),
                        title: const Text('Потребители'),
                        onTap: onUsers,
                      ),
                    if (onProfessions != null)
                      ListTile(
                        leading: const Icon(Icons.work_outline),
                        title: const Text('Професии'),
                        onTap: onProfessions,
                      ),

                    if (onServices != null)
                      ListTile(
                        leading: const Icon(Icons.content_cut),
                        title: const Text('Услуги'),
                        onTap: onServices,
                      ),
                    if (onProducts != null)
                      ListTile(
                        leading: const Icon(Icons.shopping_bag_outlined),
                        title: const Text('Продукти'),
                        onTap: onProducts,
                      ),

                  const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Изход'),
              onTap: onLogout,
            ),
          ],
        ),
      ),
    );
  }
}

class _EntryPills extends StatelessWidget {
  final bool locked;
  final String servicesText;
  final String productsText;
  final double? servicesAmount;
  final double? productsAmount;
  final String? currencyCode;

  const _EntryPills({
    required this.locked,
    required this.servicesText,
    required this.productsText,
    required this.servicesAmount,
    required this.productsAmount,
    required this.currencyCode,
  });

  @override
  Widget build(BuildContext context) {
    final hasServices = servicesText.trim().isNotEmpty;
    final hasProducts = productsText.trim().isNotEmpty;

    // Keep within the fixed row height.
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (hasServices)
          _SmallPill(
            locked: locked,
            icon: Icons.content_cut,
            text: servicesText,
            amount: servicesAmount,
            currencyCode: currencyCode,
            isProduct: false,
          ),
        if (hasServices && hasProducts) const SizedBox(height: 3),
        if (hasProducts)
          _SmallPill(
            locked: locked,
            icon: Icons.shopping_bag_outlined,
            text: productsText,
            amount: productsAmount,
            currencyCode: currencyCode,
            isProduct: true,
          ),
      ],
    );
  }
}

class _SmallPill extends StatelessWidget {
  final bool locked;
  final IconData icon;
  final String text;
  final double? amount;
  final String? currencyCode;
  final bool isProduct;

  const _SmallPill({
    required this.locked,
    required this.icon,
    required this.text,
    required this.amount,
    required this.currencyCode,
    required this.isProduct,
  });

  @override
  Widget build(BuildContext context) {
    final hasAmount = (amount ?? 0) > 0 && (currencyCode ?? '').isNotEmpty;

    const serviceColor = Color(0xFF75C6E0);
    const productColor = Color(0xFFEDB563);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final base = isProduct ? productColor : serviceColor;
    final bg = isDark
        ? base.withOpacity(locked ? 0.22 : 0.30)
        : base.withOpacity(locked ? 0.55 : 0.70);

    return Container(
      height: 18,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      alignment: Alignment.centerLeft,
      child: Row(
        children: [
          Icon(locked ? Icons.lock : icon, size: 12),
          const SizedBox(width: 5),
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600, fontSize: 10, height: 1.0),
            ),
          ),
          if (hasAmount) ...[
            const SizedBox(width: 6),
            Text(
              '${amount!.toStringAsFixed(2)}${_currencySuffix(currencyCode!)}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(fontSize: 10, height: 1.0),
            ),
          ]
        ],
      ),
    );
  }
}

String _currencySuffix(String code) {
  if (code.isEmpty) return '';
  // Keep compact; most likely will be EUR/BGN.
  return ' $code';
}

List<int> _buildSlots(int dayStartMinute, int dayEndMinute, int slotMinutes) {
  final out = <int>[];
  for (int m = dayStartMinute; m <= dayEndMinute; m += slotMinutes) {
    out.add(m);
  }
  return out;
}

String _fmtMinute(int m) {
  final h = m ~/ 60;
  final min = m % 60;
  return '${h.toString().padLeft(2, '0')}:${min.toString().padLeft(2, '0')}';
}

String _fmtDate(DateTime d) {
  final day = d.day.toString().padLeft(2, '0');
  final m = d.month.toString().padLeft(2, '0');
  final y = d.year.toString();
  return '$day.$m.$y';
}

String _fmtMoney(double services, double products, String currency) {
  final parts = <String>[];
  if (services > 0) {
    parts.add('У ${services.toStringAsFixed(2)}');
  }
  if (products > 0) {
    parts.add('П ${products.toStringAsFixed(2)}');
  }
  if (parts.isEmpty) {
    parts.add('0.00');
  }
  return '${parts.join(' | ')} $currency';
}