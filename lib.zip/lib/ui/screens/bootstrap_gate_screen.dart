import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../auth_state.dart';
import 'bootstrap_setup_screen.dart';
import 'login_screen.dart';

class BootstrapGateScreen extends StatefulWidget {
  final AuthState auth;
  const BootstrapGateScreen({super.key, required this.auth});

  @override
  State<BootstrapGateScreen> createState() => _BootstrapGateScreenState();
}

class _BootstrapGateScreenState extends State<BootstrapGateScreen> {
  static const String _apiBase = 'https://armadner.com/salon_api';

  bool? _isEmpty;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isEmpty = null;
      _error = null;
    });

    try {
      final res = await http.get(Uri.parse('$_apiBase/bootstrap_status.php'));
      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}');
      }
      final data = Map<String, dynamic>.from(jsonDecode(res.body) as Map);
      if (!mounted) return;
      setState(() {
        _isEmpty = data['is_empty'] == true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Неуспешна проверка на началното състояние';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isEmpty == true) {
      return BootstrapSetupScreen(auth: widget.auth);
    }
    if (_isEmpty == false) {
      return LoginScreen(auth: widget.auth);
    }
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text(_error ?? 'Проверка на системата...'),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: _load,
                    child: const Text('Опитай отново'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
