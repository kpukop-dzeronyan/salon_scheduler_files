import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:drift/drift.dart' as drift;
import 'package:http/http.dart' as http;

import '../../data/local/app_db.dart';
import '../../services/sync_service.dart';

class BackendSyncTestScreen extends StatefulWidget {
  const BackendSyncTestScreen({super.key, required this.db});
  final AppDatabase db;

  @override
  State<BackendSyncTestScreen> createState() => _BackendSyncTestScreenState();
}

class _BackendSyncTestScreenState extends State<BackendSyncTestScreen> {
  bool _isUuid(String s) => RegExp(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\$').hasMatch(s);

  String _genUuidV4() {
    final r = Random.secure();
    final b = List<int>.generate(16, (_) => r.nextInt(256));
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    String h(int v) => v.toRadixString(16).padLeft(2, '0');
    final hex = b.map(h).join();
    return '${hex.substring(0,8)}-${hex.substring(8,12)}-${hex.substring(12,16)}-${hex.substring(16,20)}-${hex.substring(20)}';
  }

  static const String _apiBase = 'https://armadner.com/salon_api';

  final _emailCtrl = TextEditingController(text: 'kpukop@gmail.com');
  final _passCtrl = TextEditingController();

  String? _accessToken;
  String? _deviceId;

  String? _salonId;
  List<Map<String, dynamic>> _salons = [];

  String _status = '';

  // Local debug
  List<Map<String, dynamic>> _localSalons = [];

  @override
  void initState() {
    super.initState();
    _loadLocalSalons();
  }

  Future<void> _loadLocalSalons() async {
    try {
      final rows = await widget.db.select(widget.db.salons).get();
      final outboxRows = await widget.db.select(widget.db.syncOutbox).get();

      final outboxCountBySalon = <String, int>{};
      for (final o in outboxRows) {
        outboxCountBySalon[o.salonId] = (outboxCountBySalon[o.salonId] ?? 0) + 1;
      }

      final list = rows
          .map((s) => {
                'id': s.id,
                'name': s.name,
                'outbox': outboxCountBySalon[s.id] ?? 0,
              })
          .toList();

      setState(() => _localSalons = list);
    } catch (_) {
      // ignore
    }
  }


String _yyyyMmDd(DateTime d) {
  final mm = d.month.toString().padLeft(2, '0');
  final dd = d.day.toString().padLeft(2, '0');
  return '${d.year}-$mm-$dd';
}

Future<void> _dumpLocalDbToday() async {
  final salonId = _salonId;
  if (salonId == null || salonId.isEmpty) {
    debugPrint('[DUMP] No salon selected');
    return;
  }
  final today = DateTime.now();
  final dayStr = _yyyyMmDd(today);
  final workDayId = 'wd-$salonId-$dayStr';

  debugPrint('[DUMP] ===== Local DB dump salon=$salonId workDayId=$workDayId =====');

  final cols = await (widget.db.select(widget.db.staffColumns)
        ..where((t) => t.salonId.equals(salonId))
        ..orderBy([(t) => drift.OrderingTerm.asc(t.orderIndex)]))
      .get();
  debugPrint('[DUMP] staffColumns count=${cols.length}');
  for (final c in cols) {
    debugPrint('[DUMP]  col id=${c.id} userId=${c.userId} displayName=${c.displayName} profession=${c.profession} order=${c.orderIndex}');
  }

  final slots = await (widget.db.select(widget.db.timeSlotEntries)
        ..where((t) => t.workDayId.equals(workDayId))
        ..orderBy([(t) => drift.OrderingTerm.asc(t.slotMinute)]))
      .get();
  debugPrint('[DUMP] timeSlotEntries count=${slots.length}');
  for (final s in slots) {
    debugPrint('[DUMP]  slot id=${s.id} staffColumnId=${s.staffColumnId} minute=${s.slotMinute} locked=${s.locked}');
  }

  final entryIds = slots.map((e) => e.id).toSet().cast<String>().toList();
  debugPrint('[DUMP] entryIds=${entryIds.length}');

  List<EntryLine> lines = const [];
  if (entryIds.isNotEmpty) {
    lines = await (widget.db.select(widget.db.entryLines)
          ..where((t) => t.entryId.isIn(entryIds)))
        .get();
  }
  debugPrint('[DUMP] entryLines count=${lines.length}');
  final catalogIds = <String>{};
  for (final l in lines) {
    catalogIds.add(l.catalogItemId);
    debugPrint('[DUMP]  line id=${l.id} entryId=${l.entryId} catalogItemId=${l.catalogItemId} lineType=${l.lineType} qty=${l.qty}');
  }

  List<CatalogItem> cats = const [];
  if (catalogIds.isNotEmpty) {
    cats = await (widget.db.select(widget.db.catalogItems)
          ..where((t) => t.id.isIn(catalogIds.toList())))
        .get();
  }
  debugPrint('[DUMP] catalogItems(found) count=${cats.length} (needed=${catalogIds.length})');
  for (final c in cats) {
    debugPrint('[DUMP]  cat id=${c.id} name=${c.name} type=${c.type} profession=${c.profession}');
  }

  List<EntryMoneyData> money = const [];
  if (entryIds.isNotEmpty) {
    money = await (widget.db.select(widget.db.entryMoney)
          ..where((t) => t.entryId.isIn(entryIds)))
        .get();
  }
  debugPrint('[DUMP] entryMoney count=${money.length}');
  for (final m in money) {
    debugPrint('[DUMP]  money entryId=${m.entryId} services=${m.servicesTotal} products=${m.productsTotal} currency=${m.currencyCode}');
  }

  debugPrint('[DUMP] ===== End dump =====');
}

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _loginBootstrapPull() async {
    setState(() => _status = 'Working...');
    try {
      final loginRes = await http.post(
        Uri.parse('$_apiBase/auth_login.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': _emailCtrl.text.trim(),
          'password': _passCtrl.text,
          // Must be a valid UUID v4 string.
          'client_device_id': _uuidV4(),
          'device_name': 'FlutterApp',
          'platform': 'android',
          'app_version': '1.0.0',
        }),
      );

      if (loginRes.statusCode != 200) {
        throw Exception('Login failed (${loginRes.statusCode}): ${loginRes.body}');
      }

      final loginJson = jsonDecode(loginRes.body) as Map<String, dynamic>;
      _accessToken = loginJson['access_token'] as String?;
      _deviceId = loginJson['device_id'] as String?;
      if (_accessToken == null || _deviceId == null) {
        throw Exception('Login missing access_token/device_id');
      }

      final bootRes = await http.get(
        Uri.parse('$_apiBase/bootstrap.php'),
        headers: {'Authorization': 'Bearer $_accessToken'},
      );

      if (bootRes.statusCode != 200) {
        throw Exception('Bootstrap failed (${bootRes.statusCode}): ${bootRes.body}');
      }

      final bootJson = jsonDecode(bootRes.body) as Map<String, dynamic>;
      final salonsDyn = (bootJson['salons'] as List?) ?? [];
      _salons = salonsDyn.cast<Map>().map((e) => e.cast<String, dynamic>()).toList();
      if (_salons.isEmpty) throw Exception('No salons assigned to this user.');

      // salon_id may be int or string; normalize.
      _salonId ??= _salons.first['salon_id']?.toString();

      // Persist salons locally so the top debug section shows server salons too.
      for (final s in _salons) {
        final id = s['salon_id']?.toString();
        if (id == null || id.isEmpty) continue;
        final name = (s['name'] ?? 'Salon').toString();
        await widget.db.into(widget.db.salons).insertOnConflictUpdate(
              SalonsCompanion.insert(id: id, name: name),
            );
      }

      final pullRes = await http.get(
        Uri.parse('$_apiBase/sync_pull.php?salon_id=$_salonId&since_token=0&limit=500'),
        headers: {'Authorization': 'Bearer $_accessToken'},
      );

      if (pullRes.statusCode != 200) {
        throw Exception('Pull failed (${pullRes.statusCode}): ${pullRes.body}');
      }

      final pullJson = jsonDecode(pullRes.body) as Map<String, dynamic>;
      final toToken = pullJson['to_token'];
      final events = (pullJson['events'] as List?)?.length ?? 0;

      setState(() {
        _status =
            'OK ✅ Login + Bootstrap + Pull\n'
            'device_id: $_deviceId\n'
            'salon_id: $_salonId\n'
            'to_token: $toToken\n'
            'events: $events';
      });

      await _loadLocalSalons();

final sync = SyncService(widget.db);

sync.configureSession(
  salonId: _salonId!,
  token: _accessToken!,
  deviceId: _deviceId!,
);

sync.startAutoSync();
    } catch (e) {
      setState(() => _status = 'Грешка: $e');
    }
  }

  Future<void> _pushOutboxAndPull() async {
    if (_accessToken == null || _deviceId == null || _salonId == null) {
      setState(() => _status = 'Първо направи Login + Bootstrap + Pull');
      return;
    }

    setState(() => _status = 'Pushing outbox + pulling...');
    try {
      await SyncService(widget.db).sync(
        salonId: _salonId!,
        token: _accessToken!,
        deviceId: _deviceId!,
      );

      final left = await (widget.db.select(widget.db.syncOutbox)
            ..where((t) => t.salonId.equals(_salonId!)))
          .get();

      setState(() => _status = 'OK ✅ Push+Pull готово. Outbox left (selected salon): ${left.length}');
      await _loadLocalSalons();
    } catch (e) {
      setState(() => _status = 'Грешка: $e');
    }
  }

  Future<void> _seedStaff() async {
    if (_accessToken == null || _salonId == null) {
      setState(() => _status = 'Първо направи Login + Bootstrap + Pull');
      return;
    }

    setState(() => _status = 'Seeding staff...');
    try {
      final res = await http.post(
        Uri.parse('$_apiBase/admin_seed_staff.php'),
        headers: {
          'Authorization': 'Bearer $_accessToken',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'salon_id': _salonId, 'name': 'Test Staff'}),
      );

      if (res.statusCode != 200) {
        throw Exception('seed_staff failed (${res.statusCode}): ${res.body}');
      }

      final j = jsonDecode(res.body) as Map<String, dynamic>;
      setState(() => _status =
          'OK ✅ Staff seeded\n'
          'staff_id: ${j['staff_id']}\n'
          'reused: ${j['reused']}');
    } catch (e) {
      setState(() => _status = 'Грешка: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Backend Sync (test)')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            if (_localSalons.isNotEmpty) ...[
              const Text('Local salons (Drift)', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              ..._localSalons.map((s) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    '${s['name']}\nUUID: ${s['id']}\nOutbox: ${s['outbox']}\n',
                  ),
                );
              }),
              const Divider(),
            ],
            TextField(
              controller: _emailCtrl,
              decoration: const InputDecoration(labelText: 'Backend email'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _passCtrl,
              decoration: const InputDecoration(labelText: 'Backend password'),
              obscureText: true,
            ),
            const SizedBox(height: 12),
            if (_salons.isNotEmpty) ...[
              DropdownButtonFormField<String>(
                value: _salonId,
                decoration: const InputDecoration(labelText: 'Salon (server)'),
                items: _salons.map((s) {
                  final id = s['salon_id']?.toString() ?? '';
                  final name = (s['name'] ?? 'Salon').toString();
                  final role = (s['role'] ?? '').toString();
                  return DropdownMenuItem(
                    value: id,
                    child: Text('$name ($role)'),
                  );
                }).toList(),
                onChanged: (v) => setState(() => _salonId = v),
              ),
              const SizedBox(height: 12),
            ],
            ElevatedButton(
              onPressed: _loginBootstrapPull,
              child: const Text('Login + Bootstrap + Pull'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _pushOutboxAndPull,
              child: const Text('Push outbox + Pull'),
            ),
            

ElevatedButton(
  onPressed: _dumpLocalDbToday,
  child: const Text('Dump local DB (today)'),
),
const SizedBox(height: 8),

const SizedBox(height: 8),
            OutlinedButton(
              onPressed: _seedStaff,
              child: const Text('Seed staff (server)'),
            ),
            const SizedBox(height: 12),
            Text(_status),
          ],
        ),
      ),
    );
  }

  /// Generates a UUID v4 string without extra dependencies.
  String _uuidV4() {
    // Simple v4 generator based on current time.
    // For a real app, persist a single device UUID in SharedPreferences.
    final seed = DateTime.now().microsecondsSinceEpoch;
    int x = seed ^ (seed << 13);
    x ^= (x >> 7);
    x ^= (x << 17);
    String hex(int v, int len) => v.toRadixString(16).padLeft(len, '0');
    final a = hex((x & 0xffffffff), 8);
    final b = hex(((x >> 16) & 0xffff), 4);
    final c = hex((((x >> 8) & 0x0fff) | 0x4000), 4); // version 4
    final d = hex((((x >> 4) & 0x3fff) | 0x8000), 4); // variant
    final e = hex(((x >> 12) & 0xffffffff), 8) + hex((x & 0xffff), 4);
    return '$a-$b-$c-$d-$e';
  }
}