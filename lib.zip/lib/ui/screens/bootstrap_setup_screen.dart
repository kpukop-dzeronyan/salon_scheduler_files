import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../auth_state.dart';
import 'login_screen.dart';

class BootstrapSetupScreen extends StatefulWidget {
  final AuthState auth;
  const BootstrapSetupScreen({super.key, required this.auth});

  @override
  State<BootstrapSetupScreen> createState() => _BootstrapSetupScreenState();
}

class _BootstrapSetupScreenState extends State<BootstrapSetupScreen> {
  static const String _apiBase = 'https://armadner.com/salon_api';

  final _salonNameCtrl = TextEditingController();
  final _salonNumberCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  bool _saving = false;
  String? _error;

  @override
  void dispose() {
    _salonNameCtrl.dispose();
    _salonNumberCtrl.dispose();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final salonName = _salonNameCtrl.text.trim();
    final salonNumber = int.tryParse(_salonNumberCtrl.text.trim()) ?? 0;
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text;

    if (salonName.isEmpty || salonNumber <= 0 || username.isEmpty || password.isEmpty) {
      setState(() {
        _error = 'Попълни име и номер на салон, username и password';
      });
      return;
    }

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final res = await http.post(
        Uri.parse('$_apiBase/bootstrap_create.php'),
        headers: const {'Content-Type': 'application/json'},
        body: jsonEncode({
          'salon_name': salonName,
          'salon_number': salonNumber,
          'username': username,
          'password': password,
        }),
      );

      final Map<String, dynamic> data = res.body.isNotEmpty
          ? Map<String, dynamic>.from(jsonDecode(res.body) as Map)
          : <String, dynamic>{};

      if (res.statusCode != 200) {
        final errorCode = (data['error'] ?? '').toString();
        String message;
        switch (errorCode) {
          case 'salon_number_taken':
            message = 'Този номер на салон вече съществува.';
            break;
          case 'bootstrap_not_allowed':
            message = 'Базата вече е инициализирана. Продължи към вход.';
            break;
          case 'missing_fields':
            message = 'Липсват задължителни полета.';
            break;
          default:
            message = (data['message'] ?? 'Неуспешно начално създаване').toString();
        }
        throw Exception(message);
      }

      final createdSalonId = (data['salon_id'] ?? '').toString();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => LoginScreen(
            auth: widget.auth,
            initialSalonId: createdSalonId.isNotEmpty ? createdSalonId : null,
            initialUsername: username,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Начална настройка',
                        style: Theme.of(context).textTheme.headlineSmall,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Създай първи салон и първи администратор',
                        style: Theme.of(context).textTheme.bodyMedium,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 18),
                      Text('Салон', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _salonNameCtrl,
                        decoration: const InputDecoration(
                          labelText: 'Име на салон',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.store),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _salonNumberCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Номер на салон',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.numbers),
                        ),
                      ),
                      const SizedBox(height: 18),
                      Text('Администратор', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _usernameCtrl,
                        autocorrect: false,
                        enableSuggestions: false,
                        decoration: const InputDecoration(
                          labelText: 'Username',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.person),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _passwordCtrl,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'Password',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.lock),
                        ),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 14),
                        Text(
                          _error!,
                          style: TextStyle(color: Theme.of(context).colorScheme.error),
                          textAlign: TextAlign.center,
                        ),
                      ],
                      const SizedBox(height: 16),
                      FilledButton.icon(
                        onPressed: _saving ? null : _submit,
                        icon: _saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.rocket_launch_outlined),
                        label: Text(_saving ? 'Създаване...' : 'Създай и продължи към вход'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
