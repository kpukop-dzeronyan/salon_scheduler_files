import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import '../../../services/sync_service.dart';

class UserEditorSheet extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;
  final String? userId;
  final String initialScopeSalonId;

  const UserEditorSheet({
    super.key,
    required this.db,
    required this.auth,
    this.userId,
    required this.initialScopeSalonId,
  });

  @override
  State<UserEditorSheet> createState() => _UserEditorSheetState();
}

class _UserEditorSheetState extends State<UserEditorSheet> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController(text: '1');

  bool _isAdmin = false;
  bool _isActive = true;
  String? _salonId;
  String? _profession;

  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _salonId = widget.initialScopeSalonId;
    _isAdmin = false;

    final uid = widget.userId;
    if (uid != null) {
      _load(uid);
    }
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _load(String userId) async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final u = await widget.db.getUserById(userId);
      if (u == null) {
        setState(() => _error = 'Потребителят не е намерен.');
        return;
      }

      _usernameCtrl.text = u.username;
      _passwordCtrl.text = u.password;
      _isAdmin = u.isAdmin;
      _isActive = u.isActive;
      _salonId = u.salonId;

      if (!_isAdmin) {
        final col = await widget.db.getStaffColumnForUser(salonId: u.salonId, userId: u.id);
        _profession = col?.profession;
      }
    } catch (e) {
      setState(() => _error = 'Грешка при зареждане: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final session = widget.auth.user;
    if (session == null || !session.isAdmin) {
      return const SizedBox.shrink();
    }

    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          16,
          16,
          16,
          16 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Text(
                  widget.userId == null ? 'Нов потребител' : 'Редакция на потребител',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                )
              ],
            ),
            const SizedBox(height: 8),

            if (_loading)
              const Padding(
                padding: EdgeInsets.all(12),
                child: Center(child: CircularProgressIndicator()),
              )
            else ...[
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ),

              TextField(
                controller: _usernameCtrl,
                decoration: const InputDecoration(
                  labelText: 'Потребителско име',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),

              TextField(
                controller: _passwordCtrl,
                decoration: const InputDecoration(
                  labelText: 'Парола',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),

              SwitchListTile(
                value: _isAdmin,
                onChanged: (v) {
                  setState(() {
                    _isAdmin = v;
                    if (_isAdmin) {
                      _isActive = true;
                    }
                    if (_isAdmin) {
                      _salonId = AppDatabase.globalSalonId;
                      _profession = null;
                    } else {
                      // When switching from admin to user, default to current scope salon if possible.
                      if (_salonId == AppDatabase.globalSalonId) {
                        _salonId = session.activeSalonId;
                      }
                    }
                  });
                },
                title: const Text('Администратор'),
                subtitle: Text(
                  _isAdmin ? 'Глобален админ (вижда всички салони)' : 'Потребител за конкретен салон',
                ),
              ),
              const SizedBox(height: 10),

              if (!_isAdmin)
                SwitchListTile(
                  value: _isActive,
                  onChanged: (v) => setState(() => _isActive = v),
                  title: const Text('Активен'),
                  subtitle: Text(
                    _isActive ? 'Показва се в графика и може да влиза в приложението' : 'Скрит в графика (inactive) и не може да влиза',
                  ),
                ),

              if (!_isAdmin) const SizedBox(height: 10),

              _SalonPickerInline(
                db: widget.db,
                enabled: !_isAdmin,
                value: _salonId == AppDatabase.globalSalonId ? null : _salonId,
                onChanged: (v) => setState(() => _salonId = v),
              ),
              const SizedBox(height: 10),

              if (!_isAdmin)
                _ProfessionPicker(
                  db: widget.db,
                  salonId: _salonId!,
                  value: _profession,
                  onChanged: (v) => setState(() => _profession = v),
                  onAddNew: () => _addProfession(context),
                ),

              const SizedBox(height: 14),

              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _loading ? null : _save,
                      icon: const Icon(Icons.save),
                      label: const Text('Запази'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _addProfession(BuildContext context) async {
    final ctrl = TextEditingController();
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Нова професия'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Име/код (пример: hairdresser)',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Отказ')),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
            child: const Text('Добави'),
          ),
        ],
      ),
    );

    if (v == null || v.trim().isEmpty) return;

    try {
      await widget.db.upsertProfession(salonId: _salonId!, value: v.trim());
      if (!mounted) return;
      setState(() {
        _profession ??= v.trim();
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Грешка при добавяне: $e')),
      );
    }
  }

  Future<void> _save() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text.trim();

    if (username.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'Въведете потребителско име.';
      });
      return;
    }
    if (password.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'Въведете парола.';
      });
      return;
    }

    if (_salonId == null || _salonId == AppDatabase.globalSalonId) {
      setState(() {
        _loading = false;
        _error = 'Изберете салон.';
      });
      return;
    }

    if (!_isAdmin && (_profession == null || _profession!.trim().isEmpty)) {
      setState(() {
        _loading = false;
        _error = 'Изберете професия.';
      });
      return;
    }

    try {
      final uid = widget.userId ?? const Uuid().v4();

      await widget.db.upsertUserWithOptionalStaffColumn(
        id: uid,
        salonId: _salonId ?? widget.initialScopeSalonId,
        username: username,
        password: password,
        isAdmin: _isAdmin,
        isActive: _isActive,
        profession: _profession,
      );

      // Queue user sync (so server knows about this user and membership).
      final targetSalonId = _salonId ?? widget.initialScopeSalonId;
      await widget.db.enqueueUserUpsert(userId: uid, salonId: targetSalonId);

      final sync = SyncService.instance;
      if (sync != null &&
          widget.auth.accessToken != null &&
          widget.auth.deviceId != null) {
        sync.configureSession(
          salonId: targetSalonId,
          token: widget.auth.accessToken!,
          deviceId: widget.auth.deviceId!,
        );
        await sync.scheduleSync(reason: 'user-save');
      }

      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (e is StateError && e.message == 'USERNAME_TAKEN') {
        setState(() {
          _error = 'Има активен потребител със същото име в този салон.';
        });
      } else {
        setState(() {
          _error = 'Не може да се запази: $e';
        });
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Изтриване'),
        content: const Text('Сигурни ли сте, че искате да изтриете този потребител?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Отказ')),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Изтрий'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final uid = widget.userId;
      if (uid != null) {
        await widget.db.deleteUserAndCloseStaffColumn(userId: uid);
        await widget.db.enqueueUserDelete(userId: uid, salonId: widget.initialScopeSalonId);
        final sync = SyncService.instance;
        if (sync != null &&
            widget.auth.accessToken != null &&
            widget.auth.deviceId != null) {
          sync.configureSession(
            salonId: widget.initialScopeSalonId,
            token: widget.auth.accessToken!,
            deviceId: widget.auth.deviceId!,
          );
          await sync.scheduleSync(reason: 'user-delete');
        }
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      setState(() => _error = 'Грешка при изтриване: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

class _SalonPickerInline extends StatelessWidget {
  final AppDatabase db;
  final bool enabled;
  final String? value;
  final ValueChanged<String?> onChanged;

  const _SalonPickerInline({
    required this.db,
    required this.enabled,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Salon>>(
      stream: db.watchSalons(),
      builder: (context, snap) {
        final salons = snap.data ?? const <Salon>[];
        final effective = value ?? (salons.isNotEmpty ? salons.first.id : null);

        return DropdownButtonFormField<String>(
          value: effective,
          items: salons
              .map((s) => DropdownMenuItem<String>(
                    value: s.id,
                    child: Text(s.name, overflow: TextOverflow.ellipsis),
                  ))
              .toList(),
          onChanged: enabled ? onChanged : null,
          decoration: InputDecoration(
            labelText: 'Салон',
            border: const OutlineInputBorder(),
            isDense: true,
            helperText: null,
          ),
        );
      },
    );
  }
}

class _ProfessionPicker extends StatelessWidget {
  final AppDatabase db;
  final String salonId;
  final String? value;
  final ValueChanged<String?> onChanged;
  final VoidCallback onAddNew;

  const _ProfessionPicker({
    required this.db,
    required this.salonId,
    required this.value,
    required this.onChanged,
    required this.onAddNew,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<AttributeOption>>(
      stream: db.watchProfessionsBySalon(salonId),
      builder: (context, snap) {
        // Guard against duplicate values coming from DB (can crash DropdownButton)
        final raw = (snap.data ?? const <AttributeOption>[])
            .where((o) => o.isActive)
            .toList();

        final byValue = <String, AttributeOption>{};
        for (final o in raw) {
          byValue.putIfAbsent(o.value, () => o);
        }

        final options = byValue.values.toList();

        final items = options
            .map(
              (o) => DropdownMenuItem<String>(
                value: o.value,
                child: Text(_professionLabel(o.value)),
              ),
            )
            .toList();

        // If current value is not present in the list (e.g. DB changed / inactive option),
        // add a temporary item so DropdownButtonFormField doesn't assert.
        if (value != null && !items.any((it) => it.value == value)) {
          items.insert(
            0,
            DropdownMenuItem<String>(
              value: value,
              child: Text(_professionLabel(value!)),
            ),
          );
        }

        return Row(
          children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                value: value,
                items: items,
                onChanged: onChanged,
                decoration: const InputDecoration(
                  labelText: 'Професия',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 10),
            IconButton(
              tooltip: 'Добави професия',
              onPressed: onAddNew,
              icon: const Icon(Icons.add_circle_outline),
            ),
          ],
        );
      },
    );
  }
}

String _professionLabel(String key) {
  switch (key) {
    case 'hairdresser':
      return 'Фризьор';
    case 'manicurist':
      return 'Маникюр';
    default:
      return key;
  }
}
