import 'package:flutter/material.dart';

import '../../../auth_state.dart';
import '../../../data/local/app_db.dart';
import 'user_editor_sheet.dart';

/// Admin-only screen.
///
/// Users are managed inside the currently selected salon scope.
class UsersScreen extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;

  const UsersScreen({super.key, required this.db, required this.auth});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  String? _scopeSalonId;

  @override
  void initState() {
    super.initState();
    _scopeSalonId = widget.auth.activeSalonId;
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.auth.user;
    if (u == null || !u.isAdmin) {
      return const Scaffold(
        body: Center(child: Text('Нямате права за този екран.')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Потребители'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Нов'),
        onPressed: () async {
          final scope = _scopeSalonId;
          if (scope == null) return;
          await showModalBottomSheet<void>(
            context: context,
            isScrollControlled: true,
            builder: (_) => UserEditorSheet(
              db: widget.db,
              auth: widget.auth,
              userId: null,
              initialScopeSalonId: scope,
            ),
          );
        },
      ),
      body: Column(
        children: [
          _ScopePicker(
            db: widget.db,
            value: _scopeSalonId,
            onChanged: (v) => setState(() => _scopeSalonId = v),
          ),
          const Divider(height: 1),
          Expanded(
            child: _scopeSalonId == null
                ? const Center(child: Text('Няма избран салон.'))
                : _UsersList(
                    db: widget.db,
                    scopeSalonId: _scopeSalonId!,
                    onTapUser: (user) async {
                      await showModalBottomSheet<void>(
                        context: context,
                        isScrollControlled: true,
                        builder: (_) => UserEditorSheet(
                          db: widget.db,
                          auth: widget.auth,
                          userId: user.id,
                          initialScopeSalonId: _scopeSalonId!,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _ScopePicker extends StatelessWidget {
  final AppDatabase db;
  final String? value;
  final ValueChanged<String?> onChanged;

  const _ScopePicker({
    required this.db,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: StreamBuilder<List<Salon>>(
        stream: db.watchSalons(),
        builder: (context, snap) {
          final salons = snap.data ?? const <Salon>[];

          final items = <DropdownMenuItem<String>>[
            for (final s in salons)
              DropdownMenuItem(
                value: s.id,
                child: Text(s.name, overflow: TextOverflow.ellipsis),
              ),
          ];

          final validIds = <String>{for (final s in salons) s.id};
          final fallback = salons.isNotEmpty ? salons.first.id : null;
          final effective = (value != null && validIds.contains(value)) ? value! : fallback;
          if (effective != value) {
            WidgetsBinding.instance.addPostFrameCallback((_) => onChanged(effective));
          }

          return Row(
            children: [
              const Icon(Icons.filter_list),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: effective,
                  items: items,
                  onChanged: onChanged,
                  decoration: const InputDecoration(
                    labelText: 'Група',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _UsersList extends StatelessWidget {
  final AppDatabase db;
  final String scopeSalonId;
  final ValueChanged<User> onTapUser;

  const _UsersList({
    required this.db,
    required this.scopeSalonId,
    required this.onTapUser,
  });

  @override
  Widget build(BuildContext context) {
    // Salon users: show ordering controls based on staff column orderIndex.
    final today = DateTime.now();
    return StreamBuilder<List<StaffColumn>>(
      stream: db.watchStaffColumnsForDate(salonId: scopeSalonId, date: today),
      builder: (context, colsSnap) {
        final cols = colsSnap.data ?? const <StaffColumn>[];
        final orderByUserId = <String, int>{
          for (final c in cols) c.userId: c.orderIndex,
        };

        return StreamBuilder<List<User>>(
          stream: db.watchUsersBySalon(scopeSalonId),
          builder: (context, snap) {
            final usersRaw = snap.data ?? const <User>[];
            final users = [...usersRaw];
            users.sort((a, b) {
              final oa = orderByUserId[a.id] ?? 1 << 30;
              final ob = orderByUserId[b.id] ?? 1 << 30;
              if (oa != ob) return oa.compareTo(ob);
              // active first
              if (a.isActive != b.isActive) return a.isActive ? -1 : 1;
              final an = (a.usernameNorm ?? a.username).toLowerCase();
              final bn = (b.usernameNorm ?? b.username).toLowerCase();
              return an.compareTo(bn);
            });

            if (users.isEmpty) {
              return const Center(child: Text('Няма потребители за този салон.'));
            }

            return ListView.separated(
              itemCount: users.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final u = users[i];
                final inactive = !u.isActive;
                final canReorder = !u.isAdmin && (orderByUserId.containsKey(u.id));

                return ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(
                    inactive ? '${u.username} (inactive)' : u.username,
                    style: inactive ? TextStyle(color: Theme.of(context).disabledColor) : null,
                  ),
                  subtitle: const Text('Потребител'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (canReorder) ...[
                        IconButton(
                          tooltip: 'Нагоре',
                          icon: const Icon(Icons.arrow_upward),
                          onPressed: i == 0 ? null : () => db.moveStaffColumn(salonId: scopeSalonId, userId: u.id, up: true),
                        ),
                        IconButton(
                          tooltip: 'Надолу',
                          icon: const Icon(Icons.arrow_downward),
                          onPressed: i == users.length - 1
                              ? null
                              : () => db.moveStaffColumn(salonId: scopeSalonId, userId: u.id, up: false),
                        ),
                      ],
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                  onTap: () => onTapUser(u),
                );
              },
            );
          },
        );
      },
    );
  }
}
