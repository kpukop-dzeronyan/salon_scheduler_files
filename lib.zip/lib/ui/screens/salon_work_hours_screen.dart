import 'package:flutter/material.dart';

import '../../auth_state.dart';
import '../../data/local/app_db.dart';
import '../../services/sync_service.dart';

/// Admin-only screen.
///
/// Edits per-salon working hours (Mon..Sun) and slotMinutes.
/// Persists to Drift (SQLite) using [AppDatabase.upsertSalonWorkHoursAndSlotMinutes].
class SalonWorkHoursScreen extends StatefulWidget {
  final AppDatabase db;
  final AuthState auth;

  const SalonWorkHoursScreen({
    super.key,
    required this.db,
    required this.auth,
  });

  @override
  State<SalonWorkHoursScreen> createState() => _SalonWorkHoursScreenState();
}

class _SalonWorkHoursScreenState extends State<SalonWorkHoursScreen> {
  String? _selectedSalonId;

  // Local editable state
  final Map<int, _TimeRange> _hoursByWeekday = {
    for (int i = 1; i <= 7; i++)
      i: _TimeRange(
        start: const TimeOfDay(hour: 8, minute: 0),
        end: const TimeOfDay(hour: 22, minute: 0),
      ),
  };
  int _slotMinutes = 10;

  // Prevent overwriting local edits while user is editing.
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _selectedSalonId = widget.auth.activeSalonId;
  }

  @override
  Widget build(BuildContext context) {
    final user = widget.auth.user;
    if (user == null || !user.isAdmin) {
      return const Scaffold(
        body: Center(child: Text('Нямате права за този екран.')),
      );
    }

    final salonId = _selectedSalonId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Работно време'),
        actions: [
          TextButton.icon(
            onPressed: salonId == null ? null : () => _save(context, salonId),
            icon: const Icon(Icons.save),
            label: const Text('Запази'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          _SalonPicker(
            db: widget.db,
            selectedSalonId: salonId,
            onChanged: (id) {
              setState(() {
                _selectedSalonId = id;
                _dirty = false; // allow loading state for the newly selected salon
              });
            },
          ),
          const Divider(height: 1),
          Expanded(
            child: salonId == null
                ? const Center(child: Text('Няма избран салон.'))
                : _SalonWorkHoursEditor(
                    db: widget.db,
                    salonId: salonId,
                    hoursByWeekday: _hoursByWeekday,
                    slotMinutes: _slotMinutes,
                    dirty: _dirty,
                    onHydrateFromDb: (hours, slotMinutes) {
                      // Load from DB only if user hasn't started editing.
                      if (_dirty) return;
                      setState(() {
                        _slotMinutes = slotMinutes;
                        for (final e in hours.entries) {
                          _hoursByWeekday[e.key] = e.value;
                        }
                      });
                    },
                    onChangeSlotMinutes: (v) => setState(() {
                      _dirty = true;
                      _slotMinutes = v;
                    }),
                    onPickStart: (weekday) => _pickTime(
                      context,
                      initial: _hoursByWeekday[weekday]!.start,
                      onPicked: (t) => setState(() {
                        _dirty = true;
                        _hoursByWeekday[weekday] =
                            _hoursByWeekday[weekday]!.copyWith(start: t);
                      }),
                    ),
                    onPickEnd: (weekday) => _pickTime(
                      context,
                      initial: _hoursByWeekday[weekday]!.end,
                      onPicked: (t) => setState(() {
                        _dirty = true;
                        _hoursByWeekday[weekday] =
                            _hoursByWeekday[weekday]!.copyWith(end: t);
                      }),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _pickTime(
    BuildContext context, {
    required TimeOfDay initial,
    required ValueChanged<TimeOfDay> onPicked,
  }) async {
    final t = await showTimePicker(
      context: context,
      initialTime: initial,
    );
    if (t != null) onPicked(t);
  }

  Future<void> _save(BuildContext context, String salonId) async {
    final errors = <String>[];

    if (_slotMinutes <= 0 || _slotMinutes > 120) {
      errors.add('Slot Minutes трябва да е между 1 и 120.');
    }

    for (var weekday = 1; weekday <= 7; weekday++) {
      final r = _hoursByWeekday[weekday]!;
      final s = _toMinute(r.start);
      final e = _toMinute(r.end);
      if (e <= s) {
        errors.add(
            '${_weekdayLabel(weekday)}: крайният час трябва да е след началния.');
      }
    }

    if (errors.isNotEmpty) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Провери настройките'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final e in errors) Text('• $e'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      return;
    }

    final map = <int, ({int startMinute, int endMinute})>{
      for (var weekday = 1; weekday <= 7; weekday++)
        weekday: (
          startMinute: _toMinute(_hoursByWeekday[weekday]!.start),
          endMinute: _toMinute(_hoursByWeekday[weekday]!.end),
        )
    };

    await widget.db.upsertSalonWorkHoursAndSlotMinutes(
      salonId: salonId,
      hoursByWeekday: map,
      slotMinutes: _slotMinutes,
    );

    final sync = SyncService.instance;
    if (sync != null &&
        widget.auth.accessToken != null &&
        widget.auth.deviceId != null) {
      sync.configureSession(
        salonId: salonId,
        token: widget.auth.accessToken!,
        deviceId: widget.auth.deviceId!,
      );
      await sync.scheduleSync(reason: 'salon-hours-save');
    }

    if (!mounted) return;
    setState(() => _dirty = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Запазено.')),
    );
  }
}

class _SalonPicker extends StatelessWidget {
  final AppDatabase db;
  final String? selectedSalonId;
  final ValueChanged<String?> onChanged;

  const _SalonPicker({
    required this.db,
    required this.selectedSalonId,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: StreamBuilder<List<Salon>>(
        stream: db.watchSalons(),
        builder: (context, snap) {
          final salons = snap.data ?? const <Salon>[];
          final effectiveId =
              selectedSalonId ?? (salons.isNotEmpty ? salons.first.id : null);
          if (effectiveId != selectedSalonId && effectiveId != null) {
            WidgetsBinding.instance
                .addPostFrameCallback((_) => onChanged(effectiveId));
          }

          return Row(
            children: [
              const Icon(Icons.store),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: effectiveId,
                  items: [
                    for (final s in salons)
                      DropdownMenuItem(
                        value: s.id,
                        child: Text(s.name, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: onChanged,
                  decoration: const InputDecoration(
                    labelText: 'Салон',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SalonWorkHoursEditor extends StatelessWidget {
  final AppDatabase db;
  final String salonId;

  final Map<int, _TimeRange> hoursByWeekday;
  final int slotMinutes;
  final bool dirty;

  final void Function(Map<int, _TimeRange> hours, int slotMinutes)
      onHydrateFromDb;
  final ValueChanged<int> onChangeSlotMinutes;
  final ValueChanged<int> onPickStart;
  final ValueChanged<int> onPickEnd;

  const _SalonWorkHoursEditor({
    required this.db,
    required this.salonId,
    required this.hoursByWeekday,
    required this.slotMinutes,
    required this.dirty,
    required this.onHydrateFromDb,
    required this.onChangeSlotMinutes,
    required this.onPickStart,
    required this.onPickEnd,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<SalonSetting?>(
      stream: db.watchSalonSettingsBySalon(salonId),
      builder: (context, setSnap) {
        return StreamBuilder<List<SalonWorkHour>>(
          stream: db.watchSalonWorkHoursBySalon(salonId),
          builder: (context, whSnap) {
            final wh = whSnap.data ?? const <SalonWorkHour>[];
            final currentSlot = setSnap.data?.slotMinutes ?? 10;

            // Hydrate local editable state when we have data.
            if (!dirty) {
              final map = <int, _TimeRange>{};
              for (final r in wh) {
                map[r.weekday] = _TimeRange(
                  start: _fromMinute(r.startMinute),
                  end: _fromMinute(r.endMinute),
                );
              }
              if (map.length == 7) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  onHydrateFromDb(map, currentSlot);
                });
              }
            }

            return ListView(
              padding: const EdgeInsets.all(12),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        const Icon(Icons.timelapse),
                        const SizedBox(width: 10),
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: slotMinutes,
                            items: const [5, 10, 15, 20, 30].map((m) {
                              return DropdownMenuItem<int>(
                                value: m,
                                child: Text('$m мин.'),
                              );
                            }).toList(),
                            onChanged: (v) {
                              if (v != null) onChangeSlotMinutes(v);
                            },
                            decoration: const InputDecoration(
                              labelText: 'Интервал (slotMinutes)',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                for (var weekday = 1; weekday <= 7; weekday++)
                  _DayRow(
                    weekday: weekday,
                    range: hoursByWeekday[weekday]!,
                    onPickStart: () => onPickStart(weekday),
                    onPickEnd: () => onPickEnd(weekday),
                  ),
                const SizedBox(height: 24),
                Text(
                  'Забележка: слот-овете в графика се генерират според работното време за конкретния ден и slotMinutes.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _DayRow extends StatelessWidget {
  final int weekday;
  final _TimeRange range;
  final VoidCallback onPickStart;
  final VoidCallback onPickEnd;

  const _DayRow({
    required this.weekday,
    required this.range,
    required this.onPickStart,
    required this.onPickEnd,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _weekdayLabel(weekday),
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: onPickStart,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Начало'),
                        Text(range.start.format(context)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: onPickEnd,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Край'),
                        Text(range.end.format(context)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TimeRange {
  final TimeOfDay start;
  final TimeOfDay end;

  const _TimeRange({required this.start, required this.end});

  _TimeRange copyWith({TimeOfDay? start, TimeOfDay? end}) {
    return _TimeRange(
      start: start ?? this.start,
      end: end ?? this.end,
    );
  }
}

int _toMinute(TimeOfDay t) => t.hour * 60 + t.minute;

TimeOfDay _fromMinute(int m) {
  final h = (m ~/ 60) % 24;
  final mm = m % 60;
  return TimeOfDay(hour: h, minute: mm);
}

String _weekdayLabel(int weekday) {
  switch (weekday) {
    case 1:
      return 'Понеделник';
    case 2:
      return 'Вторник';
    case 3:
      return 'Сряда';
    case 4:
      return 'Четвъртък';
    case 5:
      return 'Петък';
    case 6:
      return 'Събота';
    case 7:
      return 'Неделя';
    default:
      return 'Ден $weekday';
  }
}
