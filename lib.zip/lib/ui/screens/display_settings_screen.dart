import 'package:flutter/material.dart';

import '../../auth_state.dart';

class DisplaySettingsScreen extends StatelessWidget {
  final AuthState auth;

  const DisplaySettingsScreen({super.key, required this.auth});

  // NOTE: `double` keys can't be used in a const map (no primitive equality).
  // We store percent as `int` and derive the scale factor from it.
  static const _options = <int, String>{
    100: 'Нормален',
    115: 'По-голям',
    130: 'Много голям',
  };

  @override
  Widget build(BuildContext context) {
    final currentPct = _snapToOptionPct(auth.uiScale);
    final currentTheme = auth.themeMode;

    return Scaffold(
      appBar: AppBar(title: const Text('Размер на интерфейса')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text(
            'Избери размер на шрифта и иконите. Промяната важи веднага.',
          ),
          const SizedBox(height: 12),
          ..._options.entries.map(
            (e) => RadioListTile<int>(
              value: e.key,
              groupValue: currentPct,
              title: Text(e.value),
              subtitle: Text('${e.key}%'),
              onChanged: (v) {
                if (v == null) return;
                auth.setUiScale(v / 100.0);
              },
            ),
          ),
          const SizedBox(height: 8),
          const Divider(),
          const Text('Тема', style: TextStyle(fontWeight: FontWeight.w700)),
          RadioListTile<ThemeMode>(
            value: ThemeMode.system,
            groupValue: currentTheme,
            title: const Text('Както е на телефона'),
            onChanged: (v) {
              if (v == null) return;
              auth.setThemeMode(v);
            },
          ),
          RadioListTile<ThemeMode>(
            value: ThemeMode.light,
            groupValue: currentTheme,
            title: const Text('Светла'),
            onChanged: (v) {
              if (v == null) return;
              auth.setThemeMode(v);
            },
          ),
          RadioListTile<ThemeMode>(
            value: ThemeMode.dark,
            groupValue: currentTheme,
            title: const Text('Тъмна'),
            onChanged: (v) {
              if (v == null) return;
              auth.setThemeMode(v);
            },
          ),
          const Divider(),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Примерен текст', style: TextStyle(fontWeight: FontWeight.w700)),
                  SizedBox(height: 8),
                  Text('Услуги: Подстрижка, Брада, +2'),
                  SizedBox(height: 6),
                  Text('Продукти: Бои 7.1, +1'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  int _snapToOptionPct(double v) {
    // Avoid tiny float drift; match nearest percent option.
    int best = _options.keys.first;
    double bestDiff = (v - (best / 100.0)).abs();
    for (final k in _options.keys) {
      final d = (v - (k / 100.0)).abs();
      if (d < bestDiff) {
        best = k;
        bestDiff = d;
      }
    }
    return best;
  }
}
