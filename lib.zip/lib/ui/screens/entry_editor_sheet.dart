import 'package:flutter/material.dart';
import 'dart:convert';
import '../../data/local/app_db.dart';
import 'package:uuid/uuid.dart';

class EntryEditorSheet extends StatefulWidget {
  final AppDatabase db;
  final String salonId;
  final WorkDay workDay;
  final StaffColumn staffCol;
  final int slotMinute;
  final String currentUserId;
  final bool isAdmin;

  const EntryEditorSheet({
    super.key,
    required this.db,
    required this.salonId,
    required this.workDay,
    required this.staffCol,
    required this.slotMinute,
    required this.currentUserId,
    required this.isAdmin,
  });

  @override
  State<EntryEditorSheet> createState() => _EntryEditorSheetState();
}

class _EntryEditorSheetState extends State<EntryEditorSheet> {
  int tab = 0;
  final servicesCtrl = TextEditingController();
  final productsCtrl = TextEditingController();
  final Set<String> selectedServiceIds = {};
  final Set<String> selectedProductIds = {};
  final Map<String, String> selectedProductVariant = {}; // parentItemId -> selected code/name

  bool _loadedExisting = false;

  bool _showValidation = false;

  String _baseServicesText = '';
  String _baseProductsText = '';
  Set<String> _baseServiceIds = <String>{};
  Set<String> _baseProductIds = <String>{};
  Map<String, String> _baseVariants = <String, String>{};

  bool _setEq(Set<String> a, Set<String> b) {
    if (identical(a, b)) return true;
    if (a.length != b.length) return false;
    for (final v in a) {
      if (!b.contains(v)) return false;
    }
    return true;
  }

  bool _mapEq(Map<String, String> a, Map<String, String> b) {
    if (identical(a, b)) return true;
    if (a.length != b.length) return false;
    for (final e in a.entries) {
      if (b[e.key] != e.value) return false;
    }
    return true;
  }

  bool get _hasUnsavedChanges {
    if (!_loadedExisting) return false;
    if (servicesCtrl.text.trim() != _baseServicesText) return true;
    if (productsCtrl.text.trim() != _baseProductsText) return true;
    if (!_setEq(selectedServiceIds, _baseServiceIds)) return true;
    if (!_setEq(selectedProductIds, _baseProductIds)) return true;
    if (!_mapEq(selectedProductVariant, _baseVariants)) return true;
    return false;
  }

  Future<void> _recalcPresetTotalsIfEnabled({required bool enabled}) async {
    if (!enabled) return;

    final ids = <String>{...selectedServiceIds, ...selectedProductIds}.toList();
    final items = await widget.db.getCatalogItemsByIds(ids);
    double svc = 0;
    double prd = 0;
    for (final it in items) {
      final p = it.defaultPrice;
      if (p == null) continue;
      if (it.type == 'service') svc += p;
      if (it.type == 'product' || it.type == 'product_category') prd += p;
    }
    if (!mounted) return;
    setState(() {
      servicesCtrl.text = svc == 0 ? '' : svc.toStringAsFixed(2);
      productsCtrl.text = prd == 0 ? '' : prd.toStringAsFixed(2);
    });
  }

  Future<void> _pickVariantAndSelect(CatalogItem parent, {required bool presetEnabled}) async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (_) {
        return SafeArea(
          child: StreamBuilder<List<AttributeOption>>(
            stream: widget.db.watchCatalogVariants(salonId: widget.salonId, parentItemId: parent.id),
            builder: (context, snap) {
              final vars = snap.data ?? const <AttributeOption>[];
              if (vars.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('Няма добавени номера/кодове за тази категория.\nДобави ги от админ екрана за продукта.'),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: vars.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final v = vars[i];
                  return ListTile(
                    title: Text(v.value),
                    onTap: () => Navigator.of(context).pop(v.value),
                  );
                },
              );
            },
          ),
        );
      },
    );

    if (picked == null || picked.isEmpty) return;

    setState(() {
      selectedProductIds.add(parent.id);
      selectedProductVariant[parent.id] = picked;
    });
    await _recalcPresetTotalsIfEnabled(enabled: presetEnabled);
  }

  @override
  void dispose() {
    servicesCtrl.dispose();
    productsCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final type = tab == 0 ? 'service' : 'product';

    final servicesTotal = double.tryParse(servicesCtrl.text.replaceAll(',', '.')) ?? 0.0;
    final productsTotal = double.tryParse(productsCtrl.text.replaceAll(',', '.')) ?? 0.0;

    final serviceHasSelection = selectedServiceIds.isNotEmpty;
    final productHasSelection = selectedProductIds.isNotEmpty;

    final serviceAmountError = !_showValidation
        ? null
        : (serviceHasSelection && servicesTotal <= 0)
            ? 'Въведете сума за услугите'
            : (!serviceHasSelection && servicesTotal > 0)
                ? 'Изберете поне 1 услуга'
                : null;

    final productAmountError = !_showValidation
        ? null
        : (productHasSelection && productsTotal <= 0)
            ? 'Въведете сума за продуктите'
            : (!productHasSelection && productsTotal > 0)
                ? 'Изберете поне 1 продукт'
                : null;

    return FutureBuilder<EntryEditorData>(
      future: widget.db.getEntryEditorDataByCell(
        workDayId: widget.workDay.id,
        staffColumnId: widget.staffCol.id,
        slotMinute: widget.slotMinute,
      ),
      builder: (context, snap) {
        final data = snap.data;
        final existingEntry = data?.entry;

        if (!_loadedExisting && data != null) {
          _loadedExisting = true;
          selectedServiceIds
            ..clear()
            ..addAll(data.lines.where((l) => l.lineType == 'service').map((l) => l.catalogItemId));
          selectedProductIds
            ..clear()
            ..addAll(data.lines.where((l) => l.lineType == 'product').map((l) => l.catalogItemId));

          selectedProductVariant.clear();
          for (final l in data.lines.where((l) => l.lineType == 'product')) {
            final mj = l.metaJson;
            if (mj == null || mj.isEmpty) continue;
            try {
              final obj = jsonDecode(mj);
              if (obj is Map && obj['variant'] is String) {
                selectedProductVariant[l.catalogItemId] = obj['variant'] as String;
              }
            } catch (_) {}
          }

          final m = data.money;
          if (m != null) {
            servicesCtrl.text = m.servicesTotal == 0 ? '' : m.servicesTotal.toStringAsFixed(2);
            productsCtrl.text = m.productsTotal == 0 ? '' : m.productsTotal.toStringAsFixed(2);
          }

          _baseServicesText = servicesCtrl.text.trim();
          _baseProductsText = productsCtrl.text.trim();
          _baseServiceIds = Set<String>.from(selectedServiceIds);
          _baseProductIds = Set<String>.from(selectedProductIds);
          _baseVariants = Map<String, String>.from(selectedProductVariant);
        }

        return WillPopScope(
          onWillPop: _onWillPop,
          child: Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.92,
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Container(width: 44, height: 5, decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(99))),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Text(_fmtMinute(widget.slotMinute), style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(width: 10),
                        Text(_fmtDate(widget.workDay.date), style: Theme.of(context).textTheme.bodyMedium),
                        const Spacer(),
                        Text(widget.staffCol.displayName),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SegmentedButton<int>(
                      segments: const [
                        ButtonSegment(value: 0, label: Text('Услуги'), icon: Icon(Icons.content_cut)),
                        ButtonSegment(value: 1, label: Text('Продукти'), icon: Icon(Icons.shopping_bag)),
                      ],
                      selected: {tab},
                      onSelectionChanged: (s) => setState(() => tab = s.first),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: StreamBuilder<bool>(
                      stream: widget.db.watchUsePresetPrices(widget.salonId),
                      builder: (context, presetSnap) {
                        final presetEnabled = presetSnap.data ?? false;
                        return StreamBuilder<bool>(
						  stream: widget.db.watchUsePresetPrices(widget.salonId),
						  builder: (context, presetSnap) {
							final presetEnabled = presetSnap.data ?? false;
							final professionFilter = widget.staffCol.profession.trim();

							return StreamBuilder<List<CatalogItem>>(
							  stream: widget.db.watchCatalogAdmin(
								salonId: widget.salonId,
								type: type,
								profession: professionFilter.isEmpty ? null : professionFilter,
								activeOnly: true,
							  ),
							  builder: (context, snap) {
								final items = snap.data ?? const <CatalogItem>[];
								if (items.isEmpty) return const Center(child: Text('Няма позиции'));
								return ListView.separated(
								  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
								  itemCount: items.length,
								  separatorBuilder: (_, __) => const SizedBox(height: 8),
								  itemBuilder: (context, i) {
									final it = items[i];
									final selected = tab == 0 ? selectedServiceIds.contains(it.id) : selectedProductIds.contains(it.id);
									final variant = selectedProductVariant[it.id];

									Future<void> toggleSelected({required bool next}) async {
									  if (tab == 0) {
										setState(() {
										  next ? selectedServiceIds.add(it.id) : selectedServiceIds.remove(it.id);
										});
										await _recalcPresetTotalsIfEnabled(enabled: presetEnabled);
										return;
									  }

									  if (it.type == 'product_category') {
										if (next) {
										  await _pickVariantAndSelect(it, presetEnabled: presetEnabled);
										} else {
										  setState(() {
											selectedProductIds.remove(it.id);
											selectedProductVariant.remove(it.id);
										  });
										  await _recalcPresetTotalsIfEnabled(enabled: presetEnabled);
										}
										return;
									  }

									  setState(() {
										next ? selectedProductIds.add(it.id) : selectedProductIds.remove(it.id);
										selectedProductVariant.remove(it.id);
									  });
									  await _recalcPresetTotalsIfEnabled(enabled: presetEnabled);
									}

									return InkWell(
									  onTap: () async => toggleSelected(next: !selected),
									  child: Container(
										padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
										constraints: const BoxConstraints(minHeight: 44),
										decoration: BoxDecoration(
										  color: selected
											  ? (tab == 0 ? const Color(0xFF2D38FE) : const Color(0xFFFAC11A))
											  : const Color(0xFF6E757D),
										  borderRadius: BorderRadius.circular(10),
										),
										child: Row(
										  children: [
											Expanded(
											  child: Column(
												crossAxisAlignment: CrossAxisAlignment.start,
												children: [
												  Text(it.name, style: const TextStyle(color: Colors.white)),
												  if (it.type == 'product_category')
													Text(
													  variant == null ? 'Избери номер/код…' : '№ $variant',
													  style: const TextStyle(color: Colors.white70, fontSize: 12),
													),
												],
											  ),
											),
											Checkbox(
											  value: selected,
											  visualDensity: VisualDensity.compact,
											  onChanged: (v) async {
												if (v == null) return;
												await toggleSelected(next: v);
											  },
											),
										  ],
										),
									  ),
									);
								  },
								);
							  },
							);
						  },
						);
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: servicesCtrl,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                onChanged: (_) {
                                  if (_showValidation) setState(() {});
                                },
                                decoration: InputDecoration(
                                  labelText: 'Услуги (сума)',
                                  border: const OutlineInputBorder(),
                                  errorText: serviceAmountError,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: TextField(
                                controller: productsCtrl,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                onChanged: (_) {
                                  if (_showValidation) setState(() {});
                                },
                                decoration: InputDecoration(
                                  labelText: 'Продукти (сума)',
                                  border: const OutlineInputBorder(),
                                  errorText: productAmountError,
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (_showValidation && servicesTotal <= 0 && productsTotal <= 0 && !serviceHasSelection && !productHasSelection)
                          const Padding(
                            padding: EdgeInsets.only(top: 10),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text('Изберете услуга или продукт', style: TextStyle(color: Colors.redAccent)),
                            ),
                          ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            if (widget.isAdmin && existingEntry != null)
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                  onPressed: _onDelete,
                                  child: const Text('Изтрий'),
                                ),
                              ),
                            if (widget.isAdmin && existingEntry != null)
                              const SizedBox(width: 12),
                            Expanded(
                              child: FilledButton(
                                onPressed: _onConfirm,
                                child: const Text('Потвърди'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<bool> _onWillPop() async {
    if (!_hasUnsavedChanges) return true;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Незапазени промени'),
        content: const Text('Имате незапазени промени. Да ги изхвърлим ли?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Отказ')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Изхвърли')),
        ],
      ),
    );

    return ok == true;
  }

  Future<void> _onDelete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Изтриване на запис'),
        content: const Text('Сигурни ли сте, че искате да изтриете този запис?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Отказ')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Изтрий'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    await widget.db.deleteEntryByCell(
      workDayId: widget.workDay.id,
      staffColumnId: widget.staffCol.id,
      slotMinute: widget.slotMinute,
    );

    if (!mounted) return;
    Navigator.of(context).pop();
  }

  Future<void> _onConfirm() async {
    setState(() => _showValidation = true);

    final servicesTotal = double.tryParse(servicesCtrl.text.replaceAll(',', '.')) ?? 0.0;
    final productsTotal = double.tryParse(productsCtrl.text.replaceAll(',', '.')) ?? 0.0;

    final serviceHasSelection = selectedServiceIds.isNotEmpty;
    final productHasSelection = selectedProductIds.isNotEmpty;

    final hasAnySelection = serviceHasSelection || productHasSelection;
    final hasAnyTotal = servicesTotal > 0 || productsTotal > 0;

    if (!hasAnySelection && !hasAnyTotal) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Изберете услуга или продукт')));
      return;
    }

    if ((serviceHasSelection && servicesTotal <= 0) || (!serviceHasSelection && servicesTotal > 0)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Проверете услугите и сумата')));
      return;
    }
    if ((productHasSelection && productsTotal <= 0) || (!productHasSelection && productsTotal > 0)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Проверете продуктите и сумата')));
      return;
    }

    final drafts = <LineDraft>[];
    for (final id in selectedServiceIds) {
      drafts.add(LineDraft(
        id: const Uuid().v4(),
        catalogItemId: id,
        lineType: 'service',
      ));
    }
    for (final id in selectedProductIds) {
      final variant = selectedProductVariant[id];
      drafts.add(LineDraft(
        id: const Uuid().v4(),
        catalogItemId: id,
        lineType: 'product',
        metaJson: variant == null ? null : jsonEncode({'variant': variant}),
      ));
    }

    await widget.db.upsertEntryAndReplaceLines(
      salonId: widget.salonId,
      workDayId: widget.workDay.id,
      staffColumnId: widget.staffCol.id,
      slotMinute: widget.slotMinute,
      byUserId: widget.currentUserId,
      servicesTotal: servicesTotal,
      productsTotal: productsTotal,
      currencyCode: widget.workDay.currencyCode,
      lines: drafts,
    );

    if (!mounted) return;
    Navigator.of(context).pop();
  }
}

String _fmtMinute(int m) {
  final h = m ~/ 60;
  final min = m % 60;
  return '${h.toString().padLeft(2, '0')}:${min.toString().padLeft(2, '0')}';
}

String _fmtDate(DateTime d) {
  final y = d.year.toString().padLeft(4, '0');
  final m = d.month.toString().padLeft(2, '0');
  final day = d.day.toString().padLeft(2, '0');
  return '$day/$m/$y';
}
