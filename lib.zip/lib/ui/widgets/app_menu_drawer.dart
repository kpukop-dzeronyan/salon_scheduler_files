
import 'package:flutter/material.dart';

class AppMenuDrawer extends StatelessWidget {
  final bool isAdmin;
  final VoidCallback onLogout;
  final VoidCallback onChangePassword;
  final VoidCallback? onWorkHours;
  final VoidCallback? onUsers;

  const AppMenuDrawer({
    super.key,
    required this.isAdmin,
    required this.onLogout,
    required this.onChangePassword,
    this.onWorkHours,
    this.onUsers,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          const DrawerHeader(
            child: Text("Меню", style: TextStyle(fontSize: 22)),
          ),
          ListTile(
            leading: const Icon(Icons.lock),
            title: const Text("Смяна на парола"),
            onTap: onChangePassword,
          ),
          if (isAdmin)
            ListTile(
              leading: const Icon(Icons.schedule),
              title: const Text("Работно време на салон"),
              onTap: onWorkHours,
            ),
          if (isAdmin)
            ListTile(
              leading: const Icon(Icons.people),
              title: const Text("Потребители"),
              onTap: onUsers,
            ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text("Logout"),
            onTap: onLogout,
          ),
        ],
      ),
    );
  }
}
