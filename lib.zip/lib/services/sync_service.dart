import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:drift/drift.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import '../data/local/app_db.dart';

/// SyncService v2 refactor goals:
/// - single-flight sync (no overlapping push/pull)
/// - automatic sync trigger support (periodic / app-resume / explicit markDirty)
/// - incremental pull via change_event (same backend contract)
/// - retry-friendly orchestration without test menu dependency
/// - lower query count through small local caches
class SyncService {
  SyncService(this.db, {http.Client? httpClient}) : _http = httpClient ?? http.Client() {
    instance = this;
  }

  static SyncService? instance;

  final AppDatabase db;
  final http.Client _http;

  final String apiBase = 'https://armadner.com/salon_api';

  final Set<String> _knownCatalogItems = <String>{};
  final Map<String, String> _knownStaffColumnIds = <String, String>{};
  final Map<String, String> _knownWorkDayIds = <String, String>{};

  Timer? _autoSyncTimer;
  Timer? _debounceTimer;
  Future<void>? _runningSync;

  String? _activeSalonId;
  String? _activeToken;
  String? _activeDeviceId;

  bool _disposed = false;
  bool _syncRequestedWhileRunning = false;

  final ValueNotifier<SyncStatus> status = ValueNotifier<SyncStatus>(const SyncStatus.idle());

  bool get isSyncing => _runningSync != null;

  void dispose() {
    _disposed = true;
    _autoSyncTimer?.cancel();
    _debounceTimer?.cancel();
    if (identical(instance, this)) {
      instance = null;
    }
    status.dispose();
    _http.close();
  }

  /// Call this once after login / salon switch.
  void configureSession({
    required String salonId,
    required String token,
    required String deviceId,
  }) {
    _activeSalonId = salonId;
    _activeToken = token;
    _activeDeviceId = deviceId;
  }

  /// Starts foreground automatic sync.
  ///
  /// This is intentionally package-free. Real OS background execution can be
  /// added later with a platform package, but this already removes the need for
  /// a test menu inside the running app.
  void _triggerSync(String reason) {
    unawaited(() async {
      try {
        await scheduleSync(reason: reason);
      } catch (e, st) {
        debugPrint('[SYNC] trigger failed ($reason): $e\n$st');
      }
    }());
  }

  void startAutoSync({Duration interval = const Duration(seconds: 20)}) {
    _autoSyncTimer?.cancel();
    _autoSyncTimer = Timer.periodic(interval, (_) {
      _triggerSync('timer');
    });
    _triggerSync('auto_start');
  }

  void stopAutoSync() {
    _autoSyncTimer?.cancel();
    _autoSyncTimer = null;
  }

  /// Useful when the app resumes.
  Future<void> onAppResumed() async => _triggerSync('resume');

  /// Useful after local writes / outbox append.
  Future<void> markDirty({Duration debounce = const Duration(milliseconds: 800)}) async {
    _debounceTimer?.cancel();
    _debounceTimer = Timer(debounce, () {
      _triggerSync('dirty');
    });
  }

  /// Backward-compatible manual entrypoint used by older screens.
  ///
  /// It also updates the active session so existing callers like LoginScreen
  /// and BackendSyncTestScreen continue to work without changes.
  Future<void> sync({
    required String salonId,
    required String token,
    required String deviceId,
    String reason = 'manual',
  }) async {
    configureSession(
      salonId: salonId,
      token: token,
      deviceId: deviceId,
    );
    await scheduleSync(reason: reason);
  }

  /// Public sync entrypoint.
  Future<void> scheduleSync({String reason = 'manual'}) async {
    if (_disposed) return;

    final salonId = _activeSalonId;
    final token = _activeToken;
    final deviceId = _activeDeviceId;
    if (salonId == null || token == null || deviceId == null) {
      throw StateError('SyncService is not configured. Call configureSession() first.');
    }

    if (_runningSync != null) {
      _syncRequestedWhileRunning = true;
      return _runningSync!;
    }

    final future = _runSyncCycle(
      salonId: salonId,
      token: token,
      deviceId: deviceId,
      reason: reason,
    );

    _runningSync = future;

    try {
      await future;
    } finally {
      _runningSync = null;

      // Coalesce stacked requests into one extra run.
      if (_syncRequestedWhileRunning && !_disposed) {
        _syncRequestedWhileRunning = false;
        unawaited(scheduleSync(reason: 'coalesced'));
      }
    }
  }

  Future<void> _runSyncCycle({
    required String salonId,
    required String token,
    required String deviceId,
    required String reason,
    int pushBatchSize = 100,
    int pullLimit = 1000,
  }) async {
    final startedAt = DateTime.now();
    status.value = SyncStatus.running(reason: reason, startedAt: startedAt);

    try {
      await _ensureSyncState(salonId);
      await _warmCaches(salonId);

      // Phase 1: drain outbox.
      var pushRounds = 0;
      while (pushRounds < 20) {
        pushRounds++;
        final pushedAny = await _pushOutboxBatch(
          salonId,
          token,
          deviceId,
          limit: pushBatchSize,
        );
        if (!pushedAny) break;
      }

      // Phase 2: incremental pull through change_event.
      var pullRounds = 0;
      while (pullRounds < 20) {
        pullRounds++;
        final hasMore = await _pullAndApply(
          salonId,
          token,
          limit: pullLimit,
        );
        if (!hasMore) break;
      }

      await (db.update(db.syncState)..where((t) => t.salonId.equals(salonId))).write(
        SyncStateCompanion(
          lastSyncedAt: Value(DateTime.now()),
          deviceId: Value(deviceId),
        ),
      );

      status.value = SyncStatus.success(
        startedAt: startedAt,
        finishedAt: DateTime.now(),
        reason: reason,
      );
    } catch (e, st) {
      debugPrint('[SYNC] failed: $e\n$st');
      status.value = SyncStatus.error(
        startedAt: startedAt,
        finishedAt: DateTime.now(),
        reason: reason,
        message: e.toString(),
      );
      rethrow;
    }
  }

  Future<void> _ensureSyncState(String salonId) async {
    final existing = await (db.select(db.syncState)..where((t) => t.salonId.equals(salonId))).getSingleOrNull();
    if (existing == null) {
      await db.into(db.syncState).insert(SyncStateCompanion.insert(salonId: salonId));
    }
  }

  Future<void> _warmCaches(String salonId) async {
    final catalogRows = await (db.select(db.catalogItems)..where((t) => t.salonId.equals(salonId))).get();
    _knownCatalogItems
      ..clear()
      ..addAll(catalogRows.map((e) => e.id));

    final staffRows = await (db.select(db.staffColumns)..where((t) => t.salonId.equals(salonId))).get();
    _knownStaffColumnIds
      ..clear()
      ..addEntries(staffRows.map((e) => MapEntry('$salonId|${e.userId}', e.id)));

    final workDays = await (db.select(db.workDays)..where((t) => t.salonId.equals(salonId))).get();
    _knownWorkDayIds
      ..clear()
      ..addEntries(workDays.map((e) => MapEntry('${salonId}|${_dateKey(e.date)}', e.id)));
  }

  // UUID validator (accepts standard 8-4-4-4-12 hex UUIDs)
  bool _isUuid(String? v) {
    if (v == null) return false;
    final re = RegExp(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$');
    return re.hasMatch(v);
  }

  // Deterministic UUID for legacy/local ids (e.g. "ser-...", numeric ids, etc.).
  String _stableUuid(String input) {
    return const Uuid().v5(Uuid.NAMESPACE_URL, 'salon_scheduler:$input');
  }

  int? _mapLineType(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) {
      final s = v.trim().toLowerCase();
      final n = int.tryParse(s);
      if (n != null) return n;
      switch (s) {
        case 'service':
          return 1;
        case 'product':
          return 2;
        case 'other':
        case 'package':
          return 3;
      }
    }
    return null;
  }

  String _lineTypeToString(dynamic v) {
    final lt = _mapLineType(v);
    switch (lt) {
      case 1:
        return 'service';
      case 2:
        return 'product';
      case 3:
        return 'other';
      default:
        return 'service';
    }
  }

  Map<String, dynamic> _sanitizeOutboxPayload(String entityType, Map<String, dynamic> p) {
    if (entityType != 'entry') return p;

    final wd = p['work_day_id'];
    if (wd is String && !_isUuid(wd)) {
      if (wd.startsWith('wd-')) {
        final rest = wd.substring(3);
        if (rest.length >= 10) {
          final maybeDate = rest.substring(rest.length - 10);
          if (RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(maybeDate)) {
            p['date'] ??= maybeDate;
          }
        }
      }
      p.remove('work_day_id');
    }

    final staff = p['staff_id'];
    if (staff is String && !_isUuid(staff)) {
      p.remove('staff_id');
    }

    final linesAny = p['lines'];
    if (linesAny is List) {
      final normalized = <Map<String, dynamic>>[];

      for (final item in linesAny) {
        if (item is! Map) continue;
        final l = item.cast<String, dynamic>();

        var id = l['id']?.toString();
        if (id == null || id.isEmpty) continue;
        if (!_isUuid(id)) id = _stableUuid('entry_line:$id');

        var refId = (l['ref_id'] ?? l['catalog_item_id'] ?? l['catalogItemId'])?.toString();
        if (refId == null || refId.isEmpty) continue;
        if (!_isUuid(refId)) refId = _stableUuid('ref:$refId');

        final lt = _mapLineType(l['line_type'] ?? l['lineType']);
        if (lt == null) continue;

        final out = Map<String, dynamic>.from(l)
          ..['id'] = id
          ..['ref_id'] = refId
          ..['line_type'] = lt;

        final varsAny = out['variants'];
        if (varsAny is List) {
          final varsNorm = <Map<String, dynamic>>[];
          for (final vItem in varsAny) {
            if (vItem is! Map) continue;
            final v = vItem.cast<String, dynamic>();
            var vid = v['id']?.toString();
            var vref = (v['variant_ref_id'] ?? v['variantRefId'])?.toString();
            if (vid == null || vid.isEmpty || vref == null || vref.isEmpty) continue;
            if (!_isUuid(vid)) vid = _stableUuid('variant:$vid');
            if (!_isUuid(vref)) vref = _stableUuid('variant_ref:$vref');
            varsNorm.add(Map<String, dynamic>.from(v)
              ..['id'] = vid
              ..['variant_ref_id'] = vref);
          }
          if (varsNorm.isNotEmpty) {
            out['variants'] = varsNorm;
          } else {
            out.remove('variants');
          }
        }

        normalized.add(out);
      }

      if (normalized.isNotEmpty) {
        p['lines'] = normalized;
      } else {
        p.remove('lines');
      }
    }

    return p;
  }

  Future<bool> _pushOutboxBatch(
    String salonId,
    String token,
    String deviceId, {
    required int limit,
  }) async {
    final ops = await (db.select(db.syncOutbox)
          ..where((t) => t.salonId.equals(salonId))
          ..orderBy([(t) => OrderingTerm.asc(t.createdAt)])
          ..limit(limit))
        .get();

    if (ops.isEmpty) return false;

    // Temporary compatibility: standalone entry_line ops are not server-authoritative yet.
    final skippedIds = ops.where((o) => o.entityType == 'entry_line').map((e) => e.opId).toList();
    if (skippedIds.isNotEmpty) {
      await (db.delete(db.syncOutbox)..where((t) => t.opId.isIn(skippedIds))).go();
    }

    final pushOps = ops.where((o) => o.entityType != 'entry_line').toList();
    if (pushOps.isEmpty) return false;

    final payload = {
      'salon_id': salonId,
      'device_id': deviceId,
      'ops': pushOps.map((o) {
        final decoded = (jsonDecode(o.payloadJson) as Map).cast<String, dynamic>();
        final sanitized = _sanitizeOutboxPayload(o.entityType, decoded);
        return {
          'op_id': o.opId,
          'entity_type': o.entityType,
          'entity_id': o.entityId,
          'op': o.op,
          'base_version': o.baseVersion,
          'payload': sanitized,
        };
      }).toList(),
    };

    final res = await _http.post(
      Uri.parse('$apiBase/sync_push.php'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode(payload),
    );

    if (res.statusCode != 200) {
      throw Exception('push failed (${res.statusCode}): ${res.body}');
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final applied = (data['applied'] as List<dynamic>? ?? const []).cast<String>();
    final conflicts = (data['conflicts'] as List<dynamic>? ?? const []);
    final toToken = (data['to_token'] as num?)?.toInt();

    if (applied.isNotEmpty) {
      await (db.delete(db.syncOutbox)..where((t) => t.opId.isIn(applied))).go();
    }

    if (toToken != null) {
      final state = await (db.select(db.syncState)..where((t) => t.salonId.equals(salonId))).getSingle();
      if (toToken > state.lastToken) {
        await (db.update(db.syncState)..where((t) => t.salonId.equals(salonId))).write(
          SyncStateCompanion(lastToken: Value(toToken)),
        );
      }
    }

    if (conflicts.isNotEmpty) {
      throw Exception('conflicts: ${jsonEncode(conflicts)}');
    }

    return true;
  }

  Future<bool> _pullAndApply(
    String salonId,
    String token, {
    required int limit,
  }) async {
    final state = await (db.select(db.syncState)..where((t) => t.salonId.equals(salonId))).getSingle();
    final since = state.lastToken;

    final res = await _http.get(
      Uri.parse('$apiBase/sync_pull.php?salon_id=$salonId&since_token=$since&limit=$limit'),
      headers: {'Authorization': 'Bearer $token'},
    );

    if (res.statusCode != 200) {
      throw Exception('pull failed (${res.statusCode}): ${res.body}');
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final bootstrap = data['bootstrap'] as Map<String, dynamic>?;
    final events = (data['events'] as List<dynamic>? ?? const []);
    final toToken = (data['to_token'] as num?)?.toInt() ?? since;
    final hasMore = (data['has_more'] as bool?) ?? false;
    final now = DateTime.now();

    await db.transaction(() async {
      if (since == 0 && bootstrap != null) {
        await _applyBootstrap(salonId, bootstrap, now);
      }

      for (final raw in events) {
        final e = (raw as Map).cast<String, dynamic>();
        final type = e['entity_type']?.toString() ?? '';
        final op = e['op']?.toString() ?? 'upsert';
        final payload = Map<String, dynamic>.from((e['payload'] as Map?) ?? const {});

        if (type == 'salon') {
          final id = payload['id']?.toString() ?? e['entity_id']?.toString();
          final name = payload['name']?.toString();
          if (id != null && id.isNotEmpty && name != null && name.isNotEmpty) {
            await db.into(db.salons).insertOnConflictUpdate(
              SalonsCompanion.insert(id: id, name: name),
            );
          }
          continue;
        }

        if (type == 'user') {
          final id = payload['id']?.toString() ?? e['entity_id']?.toString();
          if (id == null || id.isEmpty) continue;

          if (op == 'delete') {
            await (db.delete(db.users)..where((t) => t.id.equals(id))).go();
            final localStaffColumnId = 'col-$salonId-$id';
            await (db.delete(db.staffColumns)..where((t) => t.id.equals(localStaffColumnId))).go();
            continue;
          }

          final username = (payload['username'] ?? payload['display_name'] ?? '(unknown)').toString();
          final isActive = (payload['is_active'] as num?)?.toInt() != 0;
          final role = (payload['role'] ?? 'user').toString();
          final displayName = (payload['display_name'] ?? username).toString();
          final profession = (payload['profession'] ?? 'unknown').toString();
          final sortOrder = (payload['sort_order'] as num?)?.toInt() ?? 0;

          await db.into(db.users).insertOnConflictUpdate(
            UsersCompanion(
              id: Value(id),
              salonId: Value(role == 'admin' ? AppDatabase.globalSalonId : salonId),
              username: Value(username),
              usernameNorm: Value(username.toLowerCase()),
              password: const Value(''),
              isActive: Value(isActive),
              isAdmin: Value(role == 'admin'),
            ),
          );

          if (role != 'admin') {
            final localStaffColumnId = 'col-$salonId-$id';
            _knownStaffColumnIds['$salonId|$id'] = localStaffColumnId;
            await db.into(db.staffColumns).insertOnConflictUpdate(
              StaffColumnsCompanion.insert(
                id: localStaffColumnId,
                salonId: salonId,
                userId: id,
                displayName: displayName.trim().isEmpty ? username : displayName,
                profession: profession.trim().isEmpty ? 'unknown' : profession,
                orderIndex: Value(sortOrder),
                activeFrom: DateTime(2000, 1, 1),
                activeTo: Value(isActive ? null : AppDatabase.dateOnly(now)),
              ),
            );
          }
          continue;
        }


        if (type == 'catalog_item') {
          final id = payload['id']?.toString() ?? e['entity_id']?.toString();
          if (id == null || id.isEmpty) continue;

          if (op == 'delete') {
            await (db.delete(db.catalogItems)..where((t) => t.id.equals(id))).go();
            _knownCatalogItems.remove(id);
          } else {
            final targetSalonId = payload['salon_id']?.toString() ?? salonId;
            final itemType = (payload['type'] ?? '').toString();
            final profession = (payload['profession'] ?? '').toString();
            final name = (payload['name'] ?? '').toString();
            if (targetSalonId.isEmpty || itemType.isEmpty || profession.isEmpty || name.isEmpty) continue;

            await db.into(db.catalogItems).insertOnConflictUpdate(
              CatalogItemsCompanion.insert(
                id: id,
                salonId: targetSalonId,
                type: itemType,
                category: (payload['category'] ?? '').toString(),
                profession: profession,
                name: name,
                defaultPrice: Value((payload['default_price'] as num?)?.toDouble()),
                orderIndex: Value((payload['order_index'] as num?)?.toInt() ?? 0),
                isActive: Value(((payload['is_active'] as num?)?.toInt() ?? 1) != 0),
              ),
            );
            _knownCatalogItems.add(id);
          }
          continue;
        }

        if (type == 'attribute_option') {
          final id = payload['id']?.toString() ?? e['entity_id']?.toString();
          if (id == null || id.isEmpty) continue;

          if (op == 'delete') {
            await (db.delete(db.attributeOptions)..where((t) => t.id.equals(id))).go();
          } else {
            final targetSalonId = payload['salon_id']?.toString() ?? salonId;
            final optionType = (payload['type'] ?? '').toString();
            final value = (payload['value'] ?? '').toString();
            if (targetSalonId.isEmpty || optionType.isEmpty || value.isEmpty) continue;

            await db.into(db.attributeOptions).insertOnConflictUpdate(
              AttributeOptionsCompanion.insert(
                id: id,
                salonId: targetSalonId,
                type: optionType,
                value: value,
                orderIndex: Value((payload['order_index'] as num?)?.toInt() ?? 0),
                isActive: Value(((payload['is_active'] as num?)?.toInt() ?? 1) != 0),
              ),
            );
          }
          continue;
        }

        if (type == 'salon_settings') {
          final targetSalonId = payload['salon_id']?.toString() ?? salonId;
          if (targetSalonId.isEmpty) continue;

          await db.into(db.salonSettings).insertOnConflictUpdate(
            SalonSettingsCompanion(
              salonId: Value(targetSalonId),
              dayStartMinute: Value((payload['day_start_minute'] as num?)?.toInt() ?? 480),
              dayEndMinute: Value((payload['day_end_minute'] as num?)?.toInt() ?? 1320),
              slotMinutes: Value((payload['slot_minutes'] as num?)?.toInt() ?? 10),
            ),
          );
          continue;
        }

        if (type == 'salon_work_hours') {
          final targetSalonId = payload['salon_id']?.toString() ?? salonId;
          final weekday = (payload['weekday'] as num?)?.toInt();
          if (targetSalonId.isEmpty || weekday == null || weekday < 1 || weekday > 7) continue;

          final localId = 'wh-$targetSalonId-$weekday';
          await db.into(db.salonWorkHours).insertOnConflictUpdate(
            SalonWorkHoursCompanion.insert(
              id: localId,
              salonId: targetSalonId,
              weekday: weekday,
              startMinute: (payload['start_minute'] as num?)?.toInt() ?? 480,
              endMinute: (payload['end_minute'] as num?)?.toInt() ?? 1320,
            ),
          );
          continue;
        }

        if (type == 'work_day') {
          final dateStr = payload['date']?.toString();
          if (dateStr == null || dateStr.isEmpty) continue;

          final dateOnly = dateStr.substring(0, 10);
          final localWorkDayId = 'wd-$salonId-$dateOnly';
          _knownWorkDayIds['$salonId|$dateOnly'] = localWorkDayId;

          if (op == 'delete') {
            await (db.delete(db.workDays)..where((t) => t.id.equals(localWorkDayId))).go();
          } else {
            await db.into(db.workDays).insertOnConflictUpdate(
                  WorkDaysCompanion.insert(
                    id: localWorkDayId,
                    salonId: salonId,
                    date: DateTime.parse(dateOnly),
                    currencyCode: const Value('EUR'),
                  ),
                );
          }
          continue;
        }

        if (type == 'entry') {
          if (op == 'delete') {
            final id = payload['id']?.toString() ?? e['entity_id']?.toString();
            if (id == null || id.isEmpty) continue;
            await (db.delete(db.entryLines)..where((t) => t.entryId.equals(id))).go();
            await (db.delete(db.entryMoney)..where((t) => t.entryId.equals(id))).go();
            await (db.delete(db.timeSlotEntries)..where((t) => t.id.equals(id))).go();
          } else {
            await _applyEntrySnapshot(salonId, payload, now);
          }
          continue;
        }

        if (type == 'entry_line') {
          final id = payload['id']?.toString();
          final entryId = payload['entry_id']?.toString();
          final catalogItemId = payload['ref_id']?.toString();
          final lineTypeStr = _lineTypeToString(payload['line_type']);
          if (id == null || entryId == null || catalogItemId == null) continue;

          await _ensureCatalogItemExists(
            salonId: salonId,
            catalogItemId: catalogItemId,
            lineType: lineTypeStr,
            fallbackName: (payload['title'] ?? '').toString(),
            now: now,
          );

          if (op == 'delete') {
            await (db.delete(db.entryLines)..where((t) => t.id.equals(id))).go();
          } else {
            await db.into(db.entryLines).insertOnConflictUpdate(
                  EntryLinesCompanion.insert(
                    id: id,
                    entryId: entryId,
                    catalogItemId: catalogItemId,
                    lineType: lineTypeStr,
                    qty: Value((payload['qty'] as num?)?.toInt() ?? 1),
                    metaJson: Value(payload['meta_json'] as String?),
                    createdAt: now,
                  ),
                );
          }
          continue;
        }
      }

      if (toToken > since) {
        await (db.update(db.syncState)..where((t) => t.salonId.equals(salonId))).write(
          SyncStateCompanion(lastToken: Value(toToken)),
        );
      }
    });

    if (hasMore && toToken == since) {
      debugPrint('[SYNC] Warning: has_more=true but to_token did not advance (since=$since). Breaking.');
      return false;
    }

    return hasMore;
  }

  Future<void> _applyBootstrap(String salonId, Map<String, dynamic> bootstrap, DateTime now) async {
    final salon = (bootstrap['salon'] as Map?)?.cast<String, dynamic>();
    if (salon != null) {
      final sid = salon['id']?.toString();
      final name = salon['name']?.toString();
      if (sid != null && name != null) {
        await db.into(db.salons).insertOnConflictUpdate(SalonsCompanion.insert(id: sid, name: name));
      }
    }

    final today = AppDatabase.dateOnly(now);

    final existingCols = await (db.select(db.staffColumns)..where((t) => t.salonId.equals(salonId))).get();
    final existingColByUserId = <String, StaffColumn>{
      for (final c in existingCols) c.userId: c,
    };

    final staff = (bootstrap['staff'] as List?) ?? const [];
    final staffUpserts = <StaffColumnsCompanion>[];
    for (final sRaw in staff) {
      if (sRaw is! Map) continue;
      final s = sRaw.cast<String, dynamic>();
      final id = s['id']?.toString();
      final displayName = s['name']?.toString();
      if (id == null || displayName == null) continue;

      final existingCol = existingColByUserId[id];
      final serverName = displayName.trim();
      final serverProf = (s['profession']?.toString() ?? '').trim();
      final serverOrder = (s['sort_order'] as num?)?.toInt();

      final mergedName =
          (serverName.isEmpty || serverName.toLowerCase() == '(unknown)' || serverName.toLowerCase() == 'unknown')
              ? (existingCol?.displayName ?? '(unknown)')
              : serverName;

      final mergedProf =
          (serverProf.isEmpty || serverProf.toLowerCase() == '(unknown)' || serverProf.toLowerCase() == 'unknown')
              ? (existingCol?.profession ?? 'unknown')
              : serverProf;

      final mergedOrder = serverOrder ?? existingCol?.orderIndex ?? 0;
      final localStaffColumnId = 'col-$salonId-$id';
      _knownStaffColumnIds['$salonId|$id'] = localStaffColumnId;

      if (existingCol != null &&
          existingCol.id == localStaffColumnId &&
          existingCol.displayName == mergedName &&
          existingCol.profession == mergedProf &&
          existingCol.orderIndex == mergedOrder &&
          existingCol.activeTo == null &&
          AppDatabase.dateOnly(existingCol.activeFrom) == DateTime(2000, 1, 1)) {
        continue;
      }

      staffUpserts.add(
        StaffColumnsCompanion.insert(
          id: localStaffColumnId,
          salonId: salonId,
          userId: id,
          displayName: mergedName,
          profession: mergedProf,
          orderIndex: Value(mergedOrder),
          activeFrom: DateTime(2000, 1, 1),
          activeTo: const Value(null),
        ),
      );
    }

    if (staffUpserts.isNotEmpty) {
      await db.batch((b) {
        for (final row in staffUpserts) {
          b.insert(db.staffColumns, row, mode: InsertMode.insertOrReplace);
        }
      });
    }


    final catalogItems = (bootstrap['catalog_items'] as List?) ?? const [];
    if (catalogItems.isNotEmpty) {
      await db.batch((b) {
        for (final cRaw in catalogItems) {
          if (cRaw is! Map) continue;
          final c = cRaw.cast<String, dynamic>();
          final id = c['id']?.toString();
          final targetSalonId = c['salon_id']?.toString() ?? salonId;
          final type = c['type']?.toString();
          final profession = c['profession']?.toString();
          final name = c['name']?.toString();
          if (id == null || id.isEmpty || targetSalonId.isEmpty || type == null || profession == null || name == null) continue;
          b.insert(
            db.catalogItems,
            CatalogItemsCompanion.insert(
              id: id,
              salonId: targetSalonId,
              type: type,
              category: (c['category'] ?? '').toString(),
              profession: profession,
              name: name,
              defaultPrice: Value((c['default_price'] as num?)?.toDouble()),
              orderIndex: Value((c['order_index'] as num?)?.toInt() ?? 0),
              isActive: Value(((c['is_active'] as num?)?.toInt() ?? 1) != 0),
            ),
            mode: InsertMode.insertOrReplace,
          );
          _knownCatalogItems.add(id);
        }
      });
    }

    final attributeOptions = (bootstrap['attribute_options'] as List?) ?? const [];
    if (attributeOptions.isNotEmpty) {
      await db.batch((b) {
        for (final aRaw in attributeOptions) {
          if (aRaw is! Map) continue;
          final a = aRaw.cast<String, dynamic>();
          final id = a['id']?.toString();
          final targetSalonId = a['salon_id']?.toString() ?? salonId;
          final type = a['type']?.toString();
          final value = a['value']?.toString();
          if (id == null || id.isEmpty || targetSalonId.isEmpty || type == null || value == null) continue;
          b.insert(
            db.attributeOptions,
            AttributeOptionsCompanion.insert(
              id: id,
              salonId: targetSalonId,
              type: type,
              value: value,
              orderIndex: Value((a['order_index'] as num?)?.toInt() ?? 0),
              isActive: Value(((a['is_active'] as num?)?.toInt() ?? 1) != 0),
            ),
            mode: InsertMode.insertOrReplace,
          );
        }
      });
    }

    final settingsRaw = (bootstrap['salon_settings'] as Map?)?.cast<String, dynamic>();
    if (settingsRaw != null) {
      final targetSalonId = settingsRaw['salon_id']?.toString() ?? salonId;
      if (targetSalonId.isNotEmpty) {
        await db.into(db.salonSettings).insertOnConflictUpdate(
          SalonSettingsCompanion(
            salonId: Value(targetSalonId),
            dayStartMinute: Value((settingsRaw['day_start_minute'] as num?)?.toInt() ?? 480),
            dayEndMinute: Value((settingsRaw['day_end_minute'] as num?)?.toInt() ?? 1320),
            slotMinutes: Value((settingsRaw['slot_minutes'] as num?)?.toInt() ?? 10),
          ),
        );
      }
    }

    final workHours = (bootstrap['salon_work_hours'] as List?) ?? const [];
    final workHourUpserts = <SalonWorkHoursCompanion>[];
    for (final hRaw in workHours) {
      if (hRaw is! Map) continue;
      final h = hRaw.cast<String, dynamic>();
      final weekday = (h['weekday'] as num?)?.toInt();
      if (weekday == null || weekday < 1 || weekday > 7) continue;
      final targetSalonId = h['salon_id']?.toString() ?? salonId;
      if (targetSalonId.isEmpty) continue;

      workHourUpserts.add(
        SalonWorkHoursCompanion.insert(
          id: 'wh-$targetSalonId-$weekday',
          salonId: targetSalonId,
          weekday: weekday,
          startMinute: (h['start_minute'] as num?)?.toInt() ?? 480,
          endMinute: (h['end_minute'] as num?)?.toInt() ?? 1320,
        ),
      );
    }

    if (workHourUpserts.isNotEmpty) {
      await db.batch((b) {
        for (final row in workHourUpserts) {
          b.insert(db.salonWorkHours, row, mode: InsertMode.insertOrReplace);
        }
      });
    }

    final workDays = (bootstrap['work_days'] as List?) ?? const [];
    final workDayUpserts = <WorkDaysCompanion>[];
    for (final wRaw in workDays) {
      if (wRaw is! Map) continue;
      final w = wRaw.cast<String, dynamic>();
      final dateStr = w['date']?.toString();
      if (dateStr == null || dateStr.isEmpty) continue;

      final dateOnly = dateStr.substring(0, 10);
      final localWorkDayId = 'wd-$salonId-$dateOnly';
      if (_knownWorkDayIds['$salonId|$dateOnly'] != null) continue;

      workDayUpserts.add(
        WorkDaysCompanion.insert(
          id: localWorkDayId,
          salonId: salonId,
          date: DateTime.parse(dateOnly),
          currencyCode: const Value('EUR'),
        ),
      );
      _knownWorkDayIds['$salonId|$dateOnly'] = localWorkDayId;
    }

    if (workDayUpserts.isNotEmpty) {
      await db.batch((b) {
        for (final row in workDayUpserts) {
          b.insert(db.workDays, row, mode: InsertMode.insertOrReplace);
        }
      });
    }

    final entries = (bootstrap['entries'] as List?) ?? const [];
    for (final eRaw in entries) {
      if (eRaw is! Map) continue;
      await _applyEntrySnapshot(salonId, eRaw.cast<String, dynamic>(), now);
    }
  }

  Future<String> _ensureStaffColumnForServerUser({
    required String salonId,
    required String serverUserId,
    required DateTime now,
  }) async {
    final cacheKey = '$salonId|$serverUserId';
    final cached = _knownStaffColumnIds[cacheKey];
    if (cached != null) return cached;

    final desiredId = 'col-$salonId-$serverUserId';

    final existingDesired = await (db.select(db.staffColumns)..where((t) => t.id.equals(desiredId))).getSingleOrNull();
    if (existingDesired != null) {
      _knownStaffColumnIds[cacheKey] = desiredId;
      return desiredId;
    }

    final cols = await (db.select(db.staffColumns)..where((t) => t.salonId.equals(salonId))).get();

    if (cols.length == 1) {
      final c = cols.first;
      final oldId = c.id;
      final oldUserId = c.userId;

      final looksTemp = oldUserId.startsWith('u-');
      if (looksTemp && oldId != desiredId) {
        await db.transaction(() async {
          await db.into(db.staffColumns).insertOnConflictUpdate(
                StaffColumnsCompanion.insert(
                  id: desiredId,
                  salonId: salonId,
                  userId: serverUserId,
                  displayName: c.displayName,
                  profession: c.profession,
                  orderIndex: Value(c.orderIndex),
                  activeFrom: c.activeFrom,
                  activeTo: Value(c.activeTo),
                ),
              );

          await (db.update(db.timeSlotEntries)..where((t) => t.staffColumnId.equals(oldId))).write(
            TimeSlotEntriesCompanion(staffColumnId: Value(desiredId)),
          );

          await (db.delete(db.staffColumns)..where((t) => t.id.equals(oldId))).go();
        });
        _knownStaffColumnIds[cacheKey] = desiredId;
        return desiredId;
      }
    }

    final fallbackUser = await (db.select(db.users)..where((t) => t.id.equals(serverUserId))).getSingleOrNull();

    await db.into(db.staffColumns).insertOnConflictUpdate(
          StaffColumnsCompanion.insert(
            id: desiredId,
            salonId: salonId,
            userId: serverUserId,
            displayName: fallbackUser?.username ?? '(unknown)',
            profession: 'unknown',
            orderIndex: const Value(999),
            activeFrom: DateTime(2000, 1, 1),
            activeTo: const Value(null),
          ),
        );
    _knownStaffColumnIds[cacheKey] = desiredId;
    return desiredId;
  }

  Future<void> _ensureCatalogItemExists({
    required String salonId,
    required String catalogItemId,
    required String lineType,
    required String fallbackName,
    required DateTime now,
  }) async {
    if (_knownCatalogItems.contains(catalogItemId)) return;

    final existing = await (db.select(db.catalogItems)..where((t) => t.id.equals(catalogItemId))).getSingleOrNull();
    if (existing != null) {
      _knownCatalogItems.add(catalogItemId);
      return;
    }

    await db.into(db.catalogItems).insertOnConflictUpdate(
          CatalogItemsCompanion.insert(
            id: catalogItemId,
            salonId: salonId,
            type: lineType,
            category: '(sync)',
            profession: 'unknown',
            name: fallbackName.isNotEmpty ? fallbackName : '(unknown)',
            orderIndex: const Value(9999),
            isActive: const Value(true),
          ),
        );
    _knownCatalogItems.add(catalogItemId);
  }

  Future<String> _ensureLocalWorkDayId({
    required String salonId,
    required String workDayDateStr,
  }) async {
    final dateOnly = workDayDateStr.substring(0, 10);
    final cacheKey = '$salonId|$dateOnly';
    final cached = _knownWorkDayIds[cacheKey];
    if (cached != null) return cached;

    final localWorkDayId = 'wd-$salonId-$dateOnly';
    final existing = await (db.select(db.workDays)..where((t) => t.id.equals(localWorkDayId))).getSingleOrNull();
    if (existing == null) {
      await db.into(db.workDays).insertOnConflictUpdate(
            WorkDaysCompanion.insert(
              id: localWorkDayId,
              salonId: salonId,
              date: DateTime.parse(dateOnly),
              currencyCode: const Value('EUR'),
            ),
          );
    }

    _knownWorkDayIds[cacheKey] = localWorkDayId;
    return localWorkDayId;
  }

  Future<void> _applyEntrySnapshot(String salonId, Map<String, dynamic> payload, DateTime now) async {
    final id = payload['id']?.toString();
    final staffId = payload['staff_id']?.toString();
    final workDayDateStr =
        (payload['work_day_date'] ?? payload['date'] ?? payload['workDayDate'] ?? payload['work_day']?['date'])
            ?.toString();
    if (id == null || staffId == null || workDayDateStr == null || workDayDateStr.isEmpty) return;

    final localWorkDayId = await _ensureLocalWorkDayId(
      salonId: salonId,
      workDayDateStr: workDayDateStr,
    );
    final localStaffColumnId = await _ensureStaffColumnForServerUser(
      salonId: salonId,
      serverUserId: staffId,
      now: now,
    );

    final startMin = (() {
      final v = payload['start_min'] ?? payload['slot_minute'] ?? payload['slotMinute'];
      if (v is int) return v;
      if (v is num) return v.toInt();
      if (v is String && v.trim().isNotEmpty) {
        final n = int.tryParse(v.trim());
        if (n != null) return n;
      }

      final st = payload['start_time']?.toString() ?? payload['startTime']?.toString();
      if (st != null && st.isNotEmpty) return _timeToMinute(st);
      return null;
    })();

    final existingEntry = await (db.select(db.timeSlotEntries)..where((t) => t.id.equals(id))).getSingleOrNull();
    final slotMinute = startMin ?? existingEntry?.slotMinute ?? 0;

    await db.into(db.timeSlotEntries).insertOnConflictUpdate(
          TimeSlotEntriesCompanion.insert(
            id: id,
            salonId: salonId,
            workDayId: localWorkDayId,
            staffColumnId: localStaffColumnId,
            slotMinute: slotMinute,
            locked: const Value(true),
            createdAt: existingEntry?.createdAt ?? now,
            updatedAt: now,
          ),
        );

    final linesAny = payload['lines'];
    if (linesAny is List) {
      await (db.delete(db.entryLines)..where((t) => t.entryId.equals(id))).go();

      for (final lRaw in linesAny) {
        if (lRaw is! Map) continue;
        final l = lRaw.cast<String, dynamic>();
        final lineId = l['id']?.toString();
        final refId = l['ref_id']?.toString();
        if (lineId == null || refId == null) continue;

        final qtyNum = (l['qty'] as num?) ?? 1;
        final qtyInt = qtyNum.round().clamp(1, 1000000);
        final lineTypeStr = _lineTypeToString(l['line_type']);

        await _ensureCatalogItemExists(
          salonId: salonId,
          catalogItemId: refId,
          lineType: lineTypeStr,
          fallbackName: (l['title'] ?? '').toString(),
          now: now,
        );

        final linePayload = Map<String, dynamic>.from(l);
        final variantsAny = l['variants'];
        if (lineTypeStr == 'product' && variantsAny is List && variantsAny.isNotEmpty) {
          final first = variantsAny.first;
          if (first is Map) {
            final firstMap = first.cast<String, dynamic>();
            final variantTitle = (firstMap['title'] ?? firstMap['name'] ?? firstMap['label'] ?? '').toString().trim();
            if (variantTitle.isNotEmpty) {
              linePayload['variant'] = variantTitle;
            }
          }
        }

        await db.into(db.entryLines).insertOnConflictUpdate(
              EntryLinesCompanion.insert(
                id: lineId,
                entryId: id,
                catalogItemId: refId,
                lineType: lineTypeStr,
                qty: Value(qtyInt),
                metaJson: Value(jsonEncode(linePayload)),
                createdAt: now,
              ),
            );
      }
    }

    final priceTotal = (payload['price_total'] as num?)?.toDouble();
    final servicesTotal = (payload['services_total'] as num?)?.toDouble() ?? priceTotal ?? 0.0;
    final productsTotal = (payload['products_total'] as num?)?.toDouble() ?? 0.0;

    if (priceTotal != null || payload.containsKey('services_total') || payload.containsKey('products_total')) {
      await db.into(db.entryMoney).insertOnConflictUpdate(
            EntryMoneyCompanion.insert(
              entryId: id,
              servicesTotal: Value(servicesTotal),
              productsTotal: Value(productsTotal),
              currencyCode: const Value('EUR'),
            ),
          );
    }
  }

  int _timeToMinute(String hhmmss) {
    final parts = hhmmss.split(':');
    if (parts.length < 2) return 0;
    final h = int.tryParse(parts[0]) ?? 0;
    final m = int.tryParse(parts[1]) ?? 0;
    return (h * 60) + m;
  }

  String _dateKey(DateTime d) => AppDatabase.dateOnly(d).toIso8601String().substring(0, 10);
}

class SyncStatus {
  final bool isRunning;
  final bool isSuccess;
  final String reason;
  final String? message;
  final DateTime? startedAt;
  final DateTime? finishedAt;

  const SyncStatus._({
    required this.isRunning,
    required this.isSuccess,
    required this.reason,
    this.message,
    this.startedAt,
    this.finishedAt,
  });

  const SyncStatus.idle() : this._(isRunning: false, isSuccess: false, reason: 'idle');

  const SyncStatus.running({required String reason, required DateTime startedAt})
      : this._(isRunning: true, isSuccess: false, reason: reason, startedAt: startedAt);

  const SyncStatus.success({required String reason, required DateTime startedAt, required DateTime finishedAt})
      : this._(
          isRunning: false,
          isSuccess: true,
          reason: reason,
          startedAt: startedAt,
          finishedAt: finishedAt,
        );

  const SyncStatus.error({
    required String reason,
    required DateTime startedAt,
    required DateTime finishedAt,
    required String message,
  }) : this._(
          isRunning: false,
          isSuccess: false,
          reason: reason,
          message: message,
          startedAt: startedAt,
          finishedAt: finishedAt,
        );
}
