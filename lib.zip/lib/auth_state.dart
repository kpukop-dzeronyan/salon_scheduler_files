import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:drift/drift.dart';

import 'data/local/app_db.dart';
import 'services/sync_service.dart';
import 'ui/screens/login_screen.dart';

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class SessionUser {
  final String id;
  final String username;
  final bool isAdmin;

  /// Home salon (for normal users this is their salon; for global admins it's AppDatabase.globalSalonId).
  final String homeSalonId;

  /// The salon currently shown/edited in the UI.
  final String activeSalonId;

  final String activeSalonName;

  const SessionUser({
    required this.id,
    required this.username,
    required this.isAdmin,
    required this.homeSalonId,
    required this.activeSalonId,
    required this.activeSalonName,
  });

  SessionUser copyWith({
    String? activeSalonId,
    String? activeSalonName,
  }) {
    return SessionUser(
      id: id,
      username: username,
      isAdmin: isAdmin,
      homeSalonId: homeSalonId,
      activeSalonId: activeSalonId ?? this.activeSalonId,
      activeSalonName: activeSalonName ?? this.activeSalonName,
    );
  }
}

class AuthState extends ChangeNotifier {
  final AppDatabase db;

  SessionUser? _user;
  SessionUser? get user => _user;
  
  bool get isLoggedIn => _user != null;
  bool get isAdmin => _user?.isAdmin ?? false;

  bool _showBootstrapGate = true;
  bool get showBootstrapGate => _showBootstrapGate;

  void setShowBootstrapGate(bool value) {
    if (_showBootstrapGate == value) return;
    _showBootstrapGate = value;
    notifyListeners();
  }

  String? get activeSalonId => _user?.activeSalonId;
  String? get activeSalonName => _user?.activeSalonName;
  
    String? _currentSalonId;
    String? get currentSalonId => _currentSalonId;
  
  	String? _accessToken;
	String? get accessToken => _accessToken;

	String? _deviceId;
	String? get deviceId => _deviceId;

  String? _apiUserId;
  bool _apiIsAdmin = false;
  String? _apiUsername;

  String? _apiEmail;
  String? get apiEmail => _apiEmail;

  String? _apiPassword;
  String? get apiPassword => _apiPassword;

  AuthState({required this.db});

  static const _kRememberMe = 'remember_me';
  static const _kSessionUserId = 'session_user_id';
  static const _kSessionPickedSalonId = 'session_picked_salon_id';
  static const _kUiScale = 'ui_scale';
  static const _kThemeMode = 'theme_mode';

  // API session (Phase 2 sync)
  static const _kApiAccessToken = 'api_access_token';
  static const _kApiDeviceId = 'api_device_id';
  static const _kApiSalonId = 'api_salon_id';
  static const _kApiEmail = 'api_email';
  static const _kApiPassword = 'api_password';

  /// Returns a stable UUIDv4 device id stored in SharedPreferences.
  /// Backend requires a valid UUID string for client_device_id.
  Future<String> _getOrCreateDeviceUuid() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_kApiDeviceId);
    if (existing != null && _isValidUuid(existing)) {
      return existing;
    }

    final uuid = _uuidV4();
    await prefs.setString(_kApiDeviceId, uuid);
    return uuid;
  }

  static bool _isValidUuid(String s) {
    final re = RegExp(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$');
    return re.hasMatch(s);
  }

  static String _uuidV4() {
    final rnd = Random.secure();
    final bytes = List<int>.generate(16, (_) => rnd.nextInt(256));
    // version 4
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    // variant 10xx
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    String hex(int v) => v.toRadixString(16).padLeft(2, '0');
    final b = bytes;
    return '${hex(b[0])}${hex(b[1])}${hex(b[2])}${hex(b[3])}'
        '-${hex(b[4])}${hex(b[5])}'
        '-${hex(b[6])}${hex(b[7])}'
        '-${hex(b[8])}${hex(b[9])}'
        '-${hex(b[10])}${hex(b[11])}${hex(b[12])}${hex(b[13])}${hex(b[14])}${hex(b[15])}';
  }


  double _uiScale = 1.0;
  double get uiScale => _uiScale;

  ThemeMode _themeMode = ThemeMode.system;
  ThemeMode get themeMode => _themeMode;
  
  Future<bool> loginApi({
  required String salonId,
  required String username,
  required String password,
}) async {
    final uri = Uri.parse("https://armadner.com/salon_api/auth_login.php");

    final deviceUuid = await _getOrCreateDeviceUuid();

    final res = await http.post(
      uri,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "salon_id": salonId,
        "username": username,
        "password": password,
        "client_device_id": deviceUuid,
        "device_name": "FlutterApp",
        "platform": "android",
        "app_version": "1.0.0"
      }),
    );

    if (res.statusCode != 200) {
      return false;
    }

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    _accessToken = data["access_token"]?.toString();
    _deviceId = data["device_id"]?.toString();
    _currentSalonId = salonId;
    _apiUserId = data["user_id"]?.toString();
    _apiIsAdmin = data["is_admin"] == true;
    _apiUsername = data["username"]?.toString() ?? username;

    notifyListeners();
    return _accessToken != null && _deviceId != null && _apiUserId != null;
  }

Future<void> loadBootstrap({String? preferredSalonId}) async {
  if (_accessToken == null) return;

  final uri = Uri.parse("https://armadner.com/salon_api/bootstrap.php");
  final res = await http.get(
    uri,
    headers: {"Authorization": "Bearer $_accessToken"},
  );

  if (res.statusCode != 200) {
    throw Exception("bootstrap failed: ${res.body}");
  }

  final data = jsonDecode(res.body) as Map<String, dynamic>;
  final salons = (data["salons"] as List).cast<Map<String, dynamic>>();

  if (salons.isEmpty) {
    throw Exception("No salons assigned to this user.");
  }

  final preferred = preferredSalonId?.trim();
  final picked = preferred == null
      ? null
      : salons.cast<Map<String, dynamic>?>().firstWhere(
          (s) => s?['salon_id']?.toString() == preferred,
          orElse: () => null,
        );

  _currentSalonId = (picked ?? salons.first)["salon_id"].toString();

  notifyListeners();
}



  Future<void> saveApiSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kApiAccessToken, _accessToken ?? '');
    await prefs.setString(_kApiDeviceId, _deviceId ?? '');
    await prefs.setString(_kApiSalonId, _currentSalonId ?? '');
  }

  Future<void> saveApiCredentials({
    required String email,
    required String password,
  }) async {
    // Legacy no-op in the simplified salon + username + password flow.
  }

  Future<void> loadApiCredentials() async {
    // Legacy no-op in the simplified salon + username + password flow.
  }


  Future<bool> tryRestoreApiSession() async {
    final prefs = await SharedPreferences.getInstance();
    final t = prefs.getString(_kApiAccessToken) ?? '';
    final d = prefs.getString(_kApiDeviceId) ?? '';
    final s = prefs.getString(_kApiSalonId) ?? '';
    if (t.isEmpty || d.isEmpty || s.isEmpty) return false;
    _accessToken = t;
    _deviceId = d;
    _currentSalonId = s;

    final sync = SyncService.instance ?? SyncService(db);
    sync.configureSession(
      salonId: s,
      token: t,
      deviceId: d,
    );
    sync.startAutoSync();

    notifyListeners();
    return true;
  }

  Future<void> clearApiSession() async {
    _accessToken = null;
    _deviceId = null;
    _currentSalonId = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kApiAccessToken);
    await prefs.remove(_kApiDeviceId);
    await prefs.remove(_kApiSalonId);
  }

  /// Server-first login for fresh install:
  /// 1) authenticate on backend with salon + username + password
  /// 2) pull the selected salon from server into local Drift
  /// 3) open a normal local session bound to that salon
  Future<bool> loginApiAndBootstrap({
    required String salonId,
    required String username,
    required String password,
    bool rememberMe = true,
  }) async {
    final ok = await loginApi(
      salonId: salonId,
      username: username,
      password: password,
    );
    if (!ok || _accessToken == null || _deviceId == null) return false;

    final sync = SyncService.instance ?? SyncService(db);
    sync.configureSession(
      salonId: salonId,
      token: _accessToken!,
      deviceId: _deviceId!,
    );
    await sync.sync(
      salonId: salonId,
      token: _accessToken!,
      deviceId: _deviceId!,
      reason: 'login_bootstrap',
    );
    sync.startAutoSync();

    await saveApiSession();

    final safeUserId = _apiUserId;
    if (safeUserId == null) return false;

    await db.into(db.users).insertOnConflictUpdate(
      UsersCompanion.insert(
        id: safeUserId,
        salonId: salonId,
        username: _apiUsername ?? username,
        usernameNorm: Value((_apiUsername ?? username).trim().toLowerCase()),
        password: password,
        isAdmin: Value(_apiIsAdmin),
        isActive: const Value(true),
      ),
    );

    final salon = await db.getSalonById(salonId);
    final salonName = salon?.name ?? activeSalonName ?? salonId;

    _user = SessionUser(
      id: safeUserId,
      username: _apiUsername ?? username,
      isAdmin: _apiIsAdmin,
      homeSalonId: salonId,
      activeSalonId: salonId,
      activeSalonName: salonName,
    );
    _currentSalonId = salonId;

    if (!_apiIsAdmin) {
      await db.ensureStaffColumnForUser(
        salonId: salonId,
        userId: safeUserId,
        displayName: _apiUsername ?? username,
        profession: '',
      );
    }

    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    if (rememberMe) {
      await prefs.setBool(_kRememberMe, true);
      await prefs.setString(_kSessionUserId, safeUserId);
      await prefs.setString(_kSessionPickedSalonId, salonId);
    } else {
      await _clearPersistedSession(prefs);
    }

    return true;
  }

  Future<void> loadUiScale() async {
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getDouble(_kUiScale);
    if (v != null && v >= 0.8 && v <= 2.0) {
      _uiScale = v;
    } else {
      _uiScale = 1.0;
    }
    notifyListeners();
  }

  Future<void> loadThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getString(_kThemeMode);
    switch (v) {
      case 'light':
        _themeMode = ThemeMode.light;
        break;
      case 'dark':
        _themeMode = ThemeMode.dark;
        break;
      default:
        _themeMode = ThemeMode.system;
    }
    notifyListeners();
  }

  Future<void> setUiScale(double scale) async {
    final s = scale.clamp(0.8, 2.0);
    _uiScale = s;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kUiScale, s);
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    final v = switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      _ => 'system',
    };
    await prefs.setString(_kThemeMode, v);
  }

  Future<bool> login({
    required String salonId,
    required String username,
    required String password,
    bool rememberMe = false,
  }) async {
    final u = await db.authenticate(
      salonId: salonId,
      username: username,
      password: password,
    );

    if (u == null) return false;
    if (!u.isAdmin && !u.isActive) return false;

    final salon = await db.getSalonById(salonId);
    final salonName = salon?.name ?? salonId;

    _user = SessionUser(
      id: u.id,
      username: u.username,
      isAdmin: u.isAdmin,
      homeSalonId: salonId,
      activeSalonId: salonId,
      activeSalonName: salonName,
    );
    _currentSalonId = salonId;

    if (!u.isAdmin) {
      await db.ensureStaffColumnForUser(
        salonId: salonId,
        userId: u.id,
        displayName: u.username,
        profession: '',
      );
    }

    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    if (rememberMe) {
      await prefs.setBool(_kRememberMe, true);
      await prefs.setString(_kSessionUserId, u.id);
      await prefs.setString(_kSessionPickedSalonId, salonId);
    } else {
      await _clearPersistedSession(prefs);
    }

    return true;
  }

  /// Attempts to restore a previously saved session (Remember me).
  /// Returns true if restored.
  Future<bool> tryRestoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final remember = prefs.getBool(_kRememberMe) ?? false;
    if (!remember) return false;
    final userId = prefs.getString(_kSessionUserId);
    final salonId = prefs.getString(_kSessionPickedSalonId);
    if (userId == null || userId.isEmpty || salonId == null || salonId.isEmpty) {
      return false;
    }

    final u = await db.getUserById(userId);
    if (u == null || u.salonId != salonId) {
      await _clearPersistedSession(prefs);
      return false;
    }
    if (!u.isAdmin && !u.isActive) {
      await _clearPersistedSession(prefs);
      return false;
    }

    final salon = await db.getSalonById(salonId);
    if (salon == null) {
      await _clearPersistedSession(prefs);
      return false;
    }

    _user = SessionUser(
      id: u.id,
      username: u.username,
      isAdmin: u.isAdmin,
      homeSalonId: salonId,
      activeSalonId: salonId,
      activeSalonName: salon.name,
    );
    _currentSalonId = salonId;

    if (!u.isAdmin) {
      await db.ensureStaffColumnForUser(
        salonId: salonId,
        userId: u.id,
        displayName: u.username,
        profession: '',
      );
    }

    notifyListeners();
    return true;
  }

  void logout() {
    SyncService.instance?.stopAutoSync();
    _user = null;
    _accessToken = null;
    _deviceId = null;
    _currentSalonId = null;
    _apiUserId = null;
    _apiIsAdmin = false;
    _apiUsername = null;
    _apiEmail = null;
    _apiPassword = null;

    // After an explicit logout we should go straight to LoginScreen.
    // Bootstrap gate is only needed on a fresh app start.
    _showBootstrapGate = false;

    notifyListeners();
    SharedPreferences.getInstance().then(_clearPersistedSession);
    // Clear API session keys too
    SharedPreferences.getInstance().then((p) async {
      await p.remove(_kApiAccessToken);
      await p.remove(_kApiDeviceId);
      await p.remove(_kApiSalonId);
      await p.remove(_kApiEmail);
      await p.remove(_kApiPassword);
    });

    final nav = appNavigatorKey.currentState;
    if (nav != null) {
      nav.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => LoginScreen(auth: this)),
        (route) => false,
      );
    }
  }

  Future<void> _clearPersistedSession(SharedPreferences prefs) async {
    await prefs.remove(_kRememberMe);
    await prefs.remove(_kSessionUserId);
    await prefs.remove(_kSessionPickedSalonId);
  }
}
