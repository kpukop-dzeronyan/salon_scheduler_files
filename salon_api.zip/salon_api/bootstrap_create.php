<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util_uuid.php';

function read_json_body(): array {
  $raw = file_get_contents('php://input');
  if (!is_string($raw) || trim($raw) === '') return [];
  $decoded = json_decode($raw, true);
  return is_array($decoded) ? $decoded : [];
}

function uuid_v4_bin(): string {
  $bytes = random_bytes(16);
  $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
  $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
  return $bytes;
}

$pdo = db();
$body = read_json_body();
if (!empty($_POST) && is_array($_POST)) {
  $body = array_merge($body, $_POST);
}

$salonName = trim((string)($body['salon_name'] ?? ''));
$salonNumber = isset($body['salon_number']) ? (int)$body['salon_number'] : 0;
$username = trim((string)($body['username'] ?? ''));
$password = (string)($body['password'] ?? '');

if ($salonName === '' || $salonNumber <= 0 || $username === '' || $password === '') {
  json_response([
    'error' => 'missing_fields',
    'missing' => [
      'salon_name' => $salonName === '',
      'salon_number' => $salonNumber <= 0,
      'username' => $username === '',
      'password' => $password === '',
    ],
  ], 400);
}

try {
  $existingSalonCount = (int)$pdo->query("SELECT COUNT(*) FROM salon WHERE deleted_at IS NULL")->fetchColumn();
  if ($existingSalonCount > 0) {
    json_response(['error' => 'bootstrap_not_allowed', 'message' => 'Bootstrap is allowed only for an empty database.'], 409);
  }

  $st = $pdo->prepare("SELECT 1 FROM salon WHERE salon_number = ? AND deleted_at IS NULL LIMIT 1");
  $st->execute([$salonNumber]);
  if ($st->fetchColumn()) {
    json_response(['error' => 'salon_number_taken', 'message' => 'Този номер на салон вече съществува.'], 409);
  }

  $salonId = uuid_v4_bin();
  $userId = uuid_v4_bin();
  $passwordHash = password_hash($password, PASSWORD_DEFAULT);

  $pdo->beginTransaction();

  $pdo->prepare("INSERT INTO salon (id, salon_number, name, created_at, updated_at, deleted_at) VALUES (?, ?, ?, NOW(), NOW(), NULL)")
      ->execute([$salonId, $salonNumber, $salonName]);

  $pdo->prepare("INSERT INTO user (id, username, email, password_hash, is_active, created_at, updated_at, deleted_at) VALUES (?, ?, NULL, ?, 1, NOW(), NOW(), NULL)")
      ->execute([$userId, $username, $passwordHash]);

  $pdo->prepare("INSERT INTO salon_user (salon_id, user_id, role, display_name, profession, is_active, sort_order, created_at, updated_at, deleted_at) VALUES (?, ?, 'admin', ?, 'unknown', 1, 0, NOW(), NOW(), NULL)")
      ->execute([$salonId, $userId, $username]);

  $pdo->prepare("INSERT INTO salon_settings (salon_id, day_start_minute, day_end_minute, slot_minutes, created_at, updated_at) VALUES (?, 480, 1320, 10, NOW(), NOW())")
      ->execute([$salonId]);

  $wh = $pdo->prepare("INSERT INTO salon_work_hours (id, salon_id, weekday, start_minute, end_minute, created_at, updated_at, deleted_at) VALUES (?, ?, ?, 480, 1320, NOW(), NOW(), NULL)");
  for ($weekday = 1; $weekday <= 7; $weekday++) {
    $wh->execute([uuid_v4_bin(), $salonId, $weekday]);
  }

  $pdo->commit();

  json_response([
    'ok' => true,
    'salon_id' => bin_to_uuid($salonId),
    'salon_name' => $salonName,
    'salon_number' => $salonNumber,
    'username' => $username,
  ]);
} catch (Throwable $e) {
  if ($pdo->inTransaction()) {
    $pdo->rollBack();
  }
  json_response(['error' => 'server_error', 'message' => $e->getMessage()], 500);
}
