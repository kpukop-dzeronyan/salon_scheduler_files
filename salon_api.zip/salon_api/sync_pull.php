<?php
ini_set('display_errors', '0');
ini_set('html_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util_uuid.php';

$pdo = db();
$auth = require_auth($pdo);

$salonIdStr = (string)($_GET['salon_id'] ?? '');
$sinceToken = (int)($_GET['since_token'] ?? 0);
$limit      = (int)($_GET['limit'] ?? 500);

if ($salonIdStr === '') json_response(['error'=>'bad_request','message'=>'missing salon_id'], 400);
$salonId = uuid_to_bin($salonIdStr);

$limit = max(1, min(2000, $limit));

// Verify access
$st = $pdo->prepare("SELECT role FROM salon_user WHERE salon_id=? AND user_id=? AND deleted_at IS NULL LIMIT 1");
$st->execute([$salonId, $auth['user_id']]);
$role = $st->fetchColumn();
if ($role === false) json_response(['error'=>'forbidden'], 403);

$bootstrap = null;

if ($sinceToken === 0) {
  // Salon
  $st = $pdo->prepare("SELECT id, name, salon_number FROM salon WHERE id=? LIMIT 1");
  $st->execute([$salonId]);
  $salonRow = $st->fetch(PDO::FETCH_ASSOC);

  // Staff bootstrap from salon_user + user (staff.id == user.id)
  // Return fields expected by current app SyncService: id, name, profession, sort_order
  $st = $pdo->prepare("
    SELECT
      su.user_id,
      COALESCE(NULLIF(su.display_name,''), u.username, u.email, '(unknown)') AS name,
      COALESCE(NULLIF(su.profession,''), 'unknown') AS profession,
      su.sort_order,
      su.is_active,
      su.role
    FROM salon_user su
    JOIN user u ON u.id = su.user_id
    WHERE su.salon_id=? AND su.deleted_at IS NULL AND su.role='user' AND su.is_active=1
    ORDER BY su.sort_order ASC, name ASC
  ");
  $st->execute([$salonId]);
  $staff = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $staff[] = [
      'id' => bin_to_uuid($r['user_id']),
      'name' => $r['name'],
      'profession' => $r['profession'],
      'sort_order' => (int)$r['sort_order'],
      'is_active' => (int)$r['is_active'],
      'role' => $r['role'],
    ];
  }

  // Attribute options bootstrap (professions, variants, preset prices)
  $st = $pdo->prepare("
    SELECT id, salon_id, type, value, order_index, is_active
    FROM attribute_option
    WHERE salon_id=? AND deleted_at IS NULL
    ORDER BY type ASC, order_index ASC, value ASC
  ");
  $st->execute([$salonId]);
  $attributeOptions = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $attributeOptions[] = [
      'id' => bin_to_uuid($r['id']),
      'salon_id' => bin_to_uuid($r['salon_id']),
      'type' => $r['type'],
      'value' => $r['value'],
      'order_index' => (int)$r['order_index'],
      'is_active' => (int)$r['is_active'],
    ];
  }

  // Catalog items bootstrap
  $st = $pdo->prepare("
    SELECT id, salon_id, type, category, profession, name, default_price, order_index, is_active
    FROM catalog_item
    WHERE salon_id=? AND deleted_at IS NULL
    ORDER BY type ASC, profession ASC, order_index ASC, name ASC
  " );
  $st->execute([$salonId]);
  $catalogItems = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $catalogItems[] = [
      'id' => bin_to_uuid($r['id']),
      'salon_id' => bin_to_uuid($r['salon_id']),
      'type' => $r['type'],
      'category' => $r['category'],
      'profession' => $r['profession'],
      'name' => $r['name'],
      'default_price' => $r['default_price'] !== null ? (float)$r['default_price'] : null,
      'order_index' => (int)$r['order_index'],
      'is_active' => (int)$r['is_active'],
    ];
  }

  // Salon settings bootstrap
  $st = $pdo->prepare("SELECT salon_id, day_start_minute, day_end_minute, slot_minutes FROM salon_settings WHERE salon_id=? LIMIT 1");
  $st->execute([$salonId]);
  $settingsRow = $st->fetch(PDO::FETCH_ASSOC);
  $salonSettings = null;
  if ($settingsRow) {
    $salonSettings = [
      'salon_id' => bin_to_uuid($settingsRow['salon_id']),
      'day_start_minute' => (int)$settingsRow['day_start_minute'],
      'day_end_minute' => (int)$settingsRow['day_end_minute'],
      'slot_minutes' => (int)$settingsRow['slot_minutes'],
    ];
  }

  // Weekly work hours bootstrap
  $st = $pdo->prepare("SELECT id, salon_id, weekday, start_minute, end_minute FROM salon_work_hours WHERE salon_id=? AND deleted_at IS NULL ORDER BY weekday ASC");
  $st->execute([$salonId]);
  $salonWorkHours = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $salonWorkHours[] = [
      'id' => bin_to_uuid($r['id']),
      'salon_id' => bin_to_uuid($r['salon_id']),
      'weekday' => (int)$r['weekday'],
      'start_minute' => (int)$r['start_minute'],
      'end_minute' => (int)$r['end_minute'],
    ];
  }

  // Work days (optional)
  $st = $pdo->prepare("SELECT date FROM work_day WHERE salon_id=? AND deleted_at IS NULL ORDER BY date DESC LIMIT 60");
  $st->execute([$salonId]);
  $workDays = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $workDays[] = ['date' => $r['date']];
  }

  // Entries snapshot (bootstrap window: last 30 days)
  // Include lines, variants and section totals so pills and money are visible on a fresh install.
  $st = $pdo->prepare("
    SELECT
      e.id, e.salon_id, e.work_day_id, e.staff_id, e.start_min, e.end_min, e.status, e.client_name, e.notes,
      e.version, e.updated_at, e.deleted_at, e.price_total,
      wd.date AS work_day_date
    FROM entry e
    JOIN work_day wd ON wd.id = e.work_day_id
    WHERE e.salon_id=? AND e.deleted_at IS NULL AND wd.date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    ORDER BY wd.date DESC, e.start_min ASC
    LIMIT 2000
  ");
  $st->execute([$salonId]);
  $entries = [];
  $entryIds = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $entryIdBin = $r['id'];
    $entryIdStr = bin_to_uuid($entryIdBin);
    if ($entryIdStr === null) continue;

    $entries[$entryIdStr] = [
      'id' => $entryIdStr,
      'salon_id' => bin_to_uuid($r['salon_id']),
      'work_day_id' => bin_to_uuid($r['work_day_id']),
      'staff_id' => bin_to_uuid($r['staff_id']),
      'start_min' => (int)$r['start_min'],
      'end_min' => (int)$r['end_min'],
      'status' => (int)$r['status'],
      'client_name' => $r['client_name'],
      'notes' => $r['notes'],
      'version' => (int)$r['version'],
      'updated_at' => $r['updated_at'],
      'deleted_at' => $r['deleted_at'],
      'work_day_date' => $r['work_day_date'],
      'price_total' => $r['price_total'] !== null ? (float)$r['price_total'] : null,
      'services_total' => 0.0,
      'products_total' => 0.0,
      'lines' => [],
    ];
    $entryIds[] = $entryIdBin;
  }

  if (!empty($entryIds)) {
    $placeholders = implode(',', array_fill(0, count($entryIds), '?'));

    $sqlLines = "
      SELECT
        el.id, el.entry_id, el.line_type, el.ref_id, el.title, el.qty, el.unit_price, el.discount,
        elv.id AS variant_id, elv.variant_ref_id, elv.title AS variant_title, elv.qty AS variant_qty, elv.unit_price AS variant_unit_price
      FROM entry_line el
      LEFT JOIN entry_line_variant elv ON elv.entry_line_id = el.id AND elv.deleted_at IS NULL
      WHERE el.entry_id IN ($placeholders) AND el.deleted_at IS NULL
      ORDER BY el.created_at ASC, el.id ASC, elv.created_at ASC, elv.id ASC
    ";
    $stLines = $pdo->prepare($sqlLines);
    $stLines->execute($entryIds);

    while ($lr = $stLines->fetch(PDO::FETCH_ASSOC)) {
      $entryIdStr = bin_to_uuid($lr['entry_id']);
      if ($entryIdStr === null || !isset($entries[$entryIdStr])) continue;

      $lineIdStr = bin_to_uuid($lr['id']);
      $refIdStr = bin_to_uuid($lr['ref_id']);
      if ($lineIdStr === null || $refIdStr === null) continue;

      if (!isset($entries[$entryIdStr]['_line_index'])) {
        $entries[$entryIdStr]['_line_index'] = [];
      }

      if (!isset($entries[$entryIdStr]['_line_index'][$lineIdStr])) {
        $lineType = (int)$lr['line_type'];
        $qty = (float)($lr['qty'] ?? 1);
        $unitPrice = (float)($lr['unit_price'] ?? 0);
        $discount = $lr['discount'] !== null ? (float)$lr['discount'] : null;
        $lineTotal = max(0.0, ($qty * $unitPrice) - ($discount ?? 0.0));

        if ($lineType === 2) {
          $entries[$entryIdStr]['products_total'] += $lineTotal;
        } else {
          $entries[$entryIdStr]['services_total'] += $lineTotal;
        }

        $entries[$entryIdStr]['lines'][] = [
          'id' => $lineIdStr,
          'ref_id' => $refIdStr,
          'line_type' => $lineType,
          'title' => $lr['title'],
          'qty' => $qty,
          'unit_price' => $unitPrice,
          'discount' => $discount,
          'variants' => [],
        ];
        $entries[$entryIdStr]['_line_index'][$lineIdStr] = count($entries[$entryIdStr]['lines']) - 1;
      }

      if ($lr['variant_id'] !== null && $lr['variant_ref_id'] !== null) {
        $idx = $entries[$entryIdStr]['_line_index'][$lineIdStr];
        $entries[$entryIdStr]['lines'][$idx]['variants'][] = [
          'id' => bin_to_uuid($lr['variant_id']),
          'variant_ref_id' => bin_to_uuid($lr['variant_ref_id']),
          'title' => $lr['variant_title'],
          'qty' => (float)($lr['variant_qty'] ?? 1),
          'unit_price' => (float)($lr['variant_unit_price'] ?? 0),
        ];
      }
    }

    foreach ($entries as &$entry) {
      unset($entry['_line_index']);
    }
    unset($entry);
  }

  $entries = array_values($entries);

  $bootstrap = [
    'salon' => $salonRow ? ['id'=>bin_to_uuid($salonRow['id']), 'name'=>$salonRow['name'], 'salon_number'=>isset($salonRow['salon_number']) ? (int)$salonRow['salon_number'] : null] : null,
    'staff' => $staff,
    'catalog_items' => $catalogItems,
    'attribute_options' => $attributeOptions,
    'salon_settings' => $salonSettings,
    'salon_work_hours' => $salonWorkHours,
    'work_days' => $workDays,
    'entries' => $entries,
  ];
}

// Events since token
$st = $pdo->prepare("
  SELECT token, entity_type, entity_id, op, payload_json, created_at
  FROM change_event
  WHERE salon_id=? AND token > ?
  ORDER BY token ASC
  LIMIT ?
");
$st->bindValue(1, $salonId, PDO::PARAM_LOB);
$st->bindValue(2, $sinceToken, PDO::PARAM_INT);
$st->bindValue(3, $limit, PDO::PARAM_INT);
$st->execute();

$events = [];
$maxToken = $sinceToken;
while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
  $maxToken = max($maxToken, (int)$r['token']);
  $payload = [];
  if (!empty($r['payload_json'])) {
    $payload = json_decode($r['payload_json'], true) ?: [];
  }
  $events[] = [
    'token' => (int)$r['token'],
    'entity_type' => $r['entity_type'],
    'entity_id' => bin_to_uuid($r['entity_id']),
    'op' => $r['op'],
    'payload' => $payload,
    'created_at' => $r['created_at'],
  ];
}

$st = $pdo->prepare("SELECT COALESCE(MAX(token),0) FROM change_event WHERE salon_id=?");
$st->execute([$salonId]);
$toToken = (int)$st->fetchColumn();

$hasMore = false;
if (count($events) >= $limit && $maxToken < $toToken) $hasMore = true;

json_response([
  'bootstrap' => $bootstrap,
  'events' => $events,
  'to_token' => $toToken,
  'has_more' => $hasMore,
]);
