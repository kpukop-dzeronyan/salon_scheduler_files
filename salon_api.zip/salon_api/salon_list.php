<?php
require_once 'db.php';

header('Content-Type: application/json');

$conn = db();

$stmt = $conn->query("
    SELECT
        LOWER(CONCAT(
            SUBSTR(HEX(id), 1, 8), '-',
            SUBSTR(HEX(id), 9, 4), '-',
            SUBSTR(HEX(id), 13, 4), '-',
            SUBSTR(HEX(id), 17, 4), '-',
            SUBSTR(HEX(id), 21, 12)
        )) AS salon_id,
        salon_number AS number,
        name
    FROM salon
    WHERE deleted_at IS NULL
    ORDER BY name
");

$salons = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'salons' => $salons,
]);
