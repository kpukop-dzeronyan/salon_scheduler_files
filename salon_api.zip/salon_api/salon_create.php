<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util_uuid.php';

$pdo = db();
$auth = require_auth($pdo);
$userId = $auth['user_id'];

$raw = file_get_contents('php://input');
$body = [];
if (is_string($raw) && $raw !== '') {
  $decoded = json_decode($raw, true);
  if (is_array($decoded)) {
    $body = $decoded;
  }
}
if (!empty($_POST) && is_array($_POST)) {
  $body = array_merge($body, $_POST);
}

$name = trim((string)($body['name'] ?? ''));
$salonNumber = isset($body['salon_number']) ? (int)$body['salon_number'] : 0;
$sourceSalonIdStr = trim((string)($body['source_salon_id'] ?? ''));

if ($name === '' || $sourceSalonIdStr === '' || $salonNumber <= 0) {
  json_response([
    'error' => 'missing_fields',
    'missing' => [
      'name' => $name === '',
      'source_salon_id' => $sourceSalonIdStr === '',
      'salon_number' => $salonNumber <= 0,
    ],
  ], 400);
}

try {
  $sourceSalonId = uuid_to_bin($sourceSalonIdStr);
} catch (Throwable $e) {
  json_response(['error' => 'invalid_source_salon_id'], 400);
}

$st = $pdo->prepare("SELECT display_name, profession FROM salon_user WHERE salon_id=? AND user_id=? AND role='admin' AND deleted_at IS NULL LIMIT 1");
$st->execute([$sourceSalonId, $userId]);
$membership = $st->fetch();
if (!$membership) {
  json_response(['error' => 'forbidden'], 403);
}

$newSalonId = random_bytes(16);
$newSalonId[6] = chr((ord($newSalonId[6]) & 0x0f) | 0x40);
$newSalonId[8] = chr((ord($newSalonId[8]) & 0x3f) | 0x80);

$displayName = trim((string)($membership['display_name'] ?? ''));
if ($displayName === '') {
  $displayName = 'Admin';
}
$profession = trim((string)($membership['profession'] ?? 'admin'));
if ($profession === '') {
  $profession = 'admin';
}

try {
  $pdo->beginTransaction();

  $st = $pdo->prepare("SELECT 1 FROM salon WHERE salon_number = ? AND deleted_at IS NULL LIMIT 1");
  $st->execute([$salonNumber]);
  if ($st->fetchColumn()) {
    throw new Exception('Salon number already exists');
  }

  $pdo->prepare("INSERT INTO salon (id, salon_number, name, created_at, updated_at, deleted_at) VALUES (?, ?, ?, NOW(), NOW(), NULL)")
      ->execute([$newSalonId, $salonNumber, $name]);

  $pdo->prepare("INSERT INTO salon_user (salon_id, user_id, role, display_name, profession, is_active, sort_order, created_at, updated_at, deleted_at)
                 VALUES (?, ?, 'admin', ?, ?, 1, 1, NOW(), NOW(), NULL)")
      ->execute([$newSalonId, $userId, $displayName, $profession]);

  $pdo->commit();
} catch (Throwable $e) {
  if ($pdo->inTransaction()) {
    $pdo->rollBack();
  }
  json_response(['error' => 'server_error', 'message' => $e->getMessage()], 500);
}

json_response([
  'salon_id' => bin_to_uuid($newSalonId),
  'salon_number' => $salonNumber,
  'name' => $name,
]);
