<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util_uuid.php';

$pdo = db();

$raw = file_get_contents('php://input');
$body = [];
if (is_string($raw) && $raw !== '') {
  $decoded = json_decode($raw, true);
  if (is_array($decoded)) {
    $body = $decoded;
  } else {
    $parsed = [];
    parse_str($raw, $parsed);
    if (is_array($parsed) && $parsed) {
      $body = $parsed;
    }
  }
}
if (!empty($_POST) && is_array($_POST)) {
  $body = array_merge($body, $_POST);
}

$email = trim((string)($body['email'] ?? ''));
$salonIdStr = trim((string)($body['salon_id'] ?? ''));
$username = trim((string)($body['username'] ?? ''));
$password = (string)($body['password'] ?? '');
$clientDeviceId = trim((string)($body['client_device_id'] ?? ''));

if ($password === '' || $clientDeviceId === '') {
  json_response([
    'error' => 'missing_fields',
    'missing' => [
      'password' => $password === '',
      'client_device_id' => $clientDeviceId === '',
    ],
  ], 400);
}

try {
  $deviceId = uuid_to_bin($clientDeviceId);
} catch (Throwable $e) {
  json_response(['error' => 'invalid_device_id'], 400);
}

try {
  if ($salonIdStr !== '' && $username !== '') {
    $salonId = uuid_to_bin($salonIdStr);
    $st = $pdo->prepare("
      SELECT u.id, u.username, u.password_hash, su.role
      FROM salon_user su
      JOIN user u ON u.id = su.user_id
      WHERE su.salon_id = ?
        AND su.deleted_at IS NULL
        AND u.deleted_at IS NULL
        AND LOWER(u.username) = LOWER(?)
      LIMIT 1
    ");
    $st->execute([$salonId, $username]);
  } else {
    if ($email === '') {
      json_response([
        'error' => 'missing_fields',
        'missing' => [
          'email' => true,
          'salon_id' => $salonIdStr === '',
          'username' => $username === '',
        ],
      ], 400);
    }
    $st = $pdo->prepare("SELECT id, username, password_hash, NULL AS role FROM user WHERE email=? AND deleted_at IS NULL LIMIT 1");
    $st->execute([$email]);
  }
  $row = $st->fetch();
} catch (Throwable $e) {
  json_response(['error' => 'server_error', 'message' => $e->getMessage()], 500);
}

if (!$row || !password_verify($password, $row['password_hash'])) {
  json_response(['error' => 'invalid_credentials'], 401);
}

$userId = $row['id'];

try {
  $pdo->prepare("
    INSERT INTO device (id, user_id, name, created_at, last_seen_at)
    VALUES (?, ?, 'Flutter', NOW(), NOW())
    ON DUPLICATE KEY UPDATE last_seen_at=NOW(), user_id=VALUES(user_id)
  ")->execute([$deviceId, $userId]);

  $token = bin2hex(random_bytes(32));
  $tokenHash = hash('sha256', $token);

  $pdo->prepare("
    INSERT INTO access_token (token_hash, user_id, device_id, expires_at, created_at)
    VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY), NOW())
  ")->execute([$tokenHash, $userId, $deviceId]);
} catch (Throwable $e) {
  json_response(['error' => 'server_error', 'message' => $e->getMessage()], 500);
}

json_response([
  'access_token' => $token,
  'expires_at' => gmdate('c', time() + 7*86400),
  'device_id' => $clientDeviceId,
  'salon_id' => $salonIdStr !== '' ? $salonIdStr : null,
  'user_id' => bin_to_uuid($userId),
  'username' => $row['username'] ?? null,
  'is_admin' => (($row['role'] ?? '') === 'admin'),
]);
