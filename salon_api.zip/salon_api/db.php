<?php
function db(): PDO {
  static $pdo = null;
  if ($pdo) return $pdo;

  $host = 'localhost';
  $name = 'armadne_salon';
  $user = 'armadne_salon';
  $pass = 'h0SeLsx%7.Ju';

  $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";
  $pdo = new PDO($dsn, $user, $pass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  return $pdo;
}

function json_response($data, int $code = 200): void {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($data, JSON_UNESCAPED_UNICODE);
  exit;
}

function require_auth(PDO $pdo): array {
  $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (!preg_match('/Bearer\\s+(.+)/', $h, $m)) {
    json_response(['error'=>'missing_token'], 401);
  }
  $token = trim($m[1]);
  $hash = hash('sha256', $token);

  $st = $pdo->prepare("
    SELECT at.user_id, at.device_id
    FROM access_token at
    WHERE at.token_hash=? AND at.expires_at > NOW()
    LIMIT 1
  ");
  $st->execute([$hash]);
  $row = $st->fetch();
  if (!$row) {
    json_response(['error'=>'invalid_token'], 401);
  }
  return $row;
}
