<?php
require_once __DIR__ . '/db.php';

$pdo = db();

try {
  $count = (int)$pdo->query("SELECT COUNT(*) FROM salon WHERE deleted_at IS NULL")->fetchColumn();
  json_response([
    'is_empty' => $count === 0,
    'salon_count' => $count,
  ]);
} catch (Throwable $e) {
  json_response(['error' => 'server_error', 'message' => $e->getMessage()], 500);
}
