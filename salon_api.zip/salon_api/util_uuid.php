<?php
function uuid_to_bin(string $uuid): string {
  $hex = str_replace('-', '', strtolower(trim($uuid)));
  if (strlen($hex) !== 32) throw new Exception("Invalid UUID: $uuid");
  return hex2bin($hex);
}
function bin_to_uuid(string $bin): string {
  $hex = bin2hex($bin);
  return substr($hex, 0, 8) . '-' .
         substr($hex, 8, 4) . '-' .
         substr($hex, 12, 4) . '-' .
         substr($hex, 16, 4) . '-' .
         substr($hex, 20, 12);
}
