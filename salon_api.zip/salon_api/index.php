<?php
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
$path = rtrim($path, '/');
$prefix = '/salon_api';
if (str_starts_with($path, $prefix)) {
  $path = substr($path, strlen($prefix));
  if ($path === '') $path = '/';
}

switch ($path) {
  case '/auth/login':
    require __DIR__ . '/auth_login.php';
    break;
  case '/bootstrap':
    require __DIR__ . '/bootstrap.php';
    break;
  case '/sync/push':
    require __DIR__ . '/sync_push.php';
    break;
  case '/sync/pull':
    require __DIR__ . '/sync_pull.php';
    break;
  default:
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error'=>'not_found','path'=>$path], JSON_UNESCAPED_UNICODE);
}
