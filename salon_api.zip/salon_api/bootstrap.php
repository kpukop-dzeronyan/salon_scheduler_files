<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util_uuid.php';

$pdo = db();
$auth = require_auth($pdo);
$userId = $auth['user_id'];

$st = $pdo->prepare("
  SELECT su.salon_id, s.name, su.role
  FROM salon_user su
  JOIN salon s ON s.id = su.salon_id
  WHERE su.user_id=? 
");
$st->execute([$userId]);

$salons = [];
while ($r = $st->fetch()) {
  $salons[] = [
    'salon_id' => bin_to_uuid($r['salon_id']),
    'name' => $r['name'],
    'role' => $r['role'],
  ];
}

json_response(['salons'=>$salons]);
