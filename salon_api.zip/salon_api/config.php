<?php
// public_html/salon_api/config.php
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'armadne_salon',
    'user' => 'armadne_salon',
    'pass' => 'h0SeLsx%7.Ju',
    'charset' => 'utf8mb4',
  ],
  'auth' => [
    'token_ttl_hours' => 168, // 7 дни
  ],
];
