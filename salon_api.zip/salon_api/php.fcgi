#!/bin/bash

PHP_INI_SCAN_DIR=/home/armadne/.sh.phpmanager/php82.d
export PHP_INI_SCAN_DIR

DEFAULTPHPINI=/home/armadne/public_html/salon_api/php82-fcgi.ini
exec /opt/cpanel/ea-php82/root/usr/bin/php-cgi -c ${DEFAULTPHPINI}
