<?php
ini_set('display_errors', '0');
ini_set('html_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

set_error_handler(function($severity, $message, $file, $line) {
  http_response_code(500);
  echo json_encode([
    'error' => 'PHP_WARNING',
    'message' => $message,
    'file' => basename($file),
    'line' => $line,
  ], JSON_UNESCAPED_UNICODE);
  exit;
});
set_exception_handler(function($e) {
  http_response_code(500);
  echo json_encode([
    'error' => 'PHP_EXCEPTION',
    'message' => $e->getMessage(),
    'file' => basename($e->getFile()),
    'line' => $e->getLine(),
  ], JSON_UNESCAPED_UNICODE);
  exit;
});

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/util_uuid.php';

// Local helpers (safe if already defined in util_uuid.php)
if (!function_exists('bin_to_uuid')) {
  function bin_to_uuid($bin) {
    if ($bin === null) return null;
    $hex = bin2hex($bin);
    if (strlen($hex) !== 32) return null;
    return substr($hex,0,8).'-'.substr($hex,8,4).'-'.substr($hex,12,4).'-'.substr($hex,16,4).'-'.substr($hex,20,12);
  }
}

function is_uuid_str($s): bool {
  return is_string($s) && preg_match(
    '/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$/',
    $s
  );
}

function entry_row_to_payload(array $r): array {
  return [
    'id'          => isset($r['id']) ? bin_to_uuid($r['id']) : null,
    'salon_id'    => isset($r['salon_id']) ? bin_to_uuid($r['salon_id']) : null,
    'work_day_id' => isset($r['work_day_id']) ? bin_to_uuid($r['work_day_id']) : null,
    'staff_id'    => isset($r['staff_id']) ? bin_to_uuid($r['staff_id']) : null,
    'start_min'   => isset($r['start_min']) ? (int)$r['start_min'] : null,
    'end_min'     => isset($r['end_min']) ? (int)$r['end_min'] : null,
    'status'      => isset($r['status']) ? (int)$r['status'] : null,
    'client_name' => $r['client_name'] ?? null,
    'notes'       => $r['notes'] ?? null,
    'version'     => isset($r['version']) ? (int)$r['version'] : null,
    'updated_at'  => $r['updated_at'] ?? null,
    'deleted_at'  => $r['deleted_at'] ?? null,
  ];
}



function load_entry_payload(PDO $pdo, $entryIdBin): array {
  $st = $pdo->prepare("
    SELECT
      e.id, e.salon_id, e.work_day_id, e.staff_id, e.start_min, e.end_min, e.status, e.client_name, e.notes,
      e.version, e.updated_at, e.deleted_at, e.price_total,
      wd.date AS work_day_date
    FROM entry e
    JOIN work_day wd ON wd.id = e.work_day_id
    WHERE e.id=?
    LIMIT 1
  ");
  $st->execute([$entryIdBin]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if (!$row) return [];

  $payload = entry_row_to_payload($row);
  $payload['work_day_date'] = $row['work_day_date'] ?? null;
  $payload['price_total'] = isset($row['price_total']) ? (float)$row['price_total'] : null;
  $payload['services_total'] = 0.0;
  $payload['products_total'] = 0.0;
  $payload['lines'] = [];

  $st = $pdo->prepare("
    SELECT
      el.id, el.line_type, el.ref_id, el.title, el.qty, el.unit_price, el.discount,
      elv.id AS variant_id, elv.variant_ref_id, elv.title AS variant_title, elv.qty AS variant_qty, elv.unit_price AS variant_unit_price
    FROM entry_line el
    LEFT JOIN entry_line_variant elv ON elv.entry_line_id = el.id AND elv.deleted_at IS NULL
    WHERE el.entry_id=? AND el.deleted_at IS NULL
    ORDER BY el.created_at ASC, el.id ASC, elv.created_at ASC, elv.id ASC
  ");
  $st->execute([$entryIdBin]);

  $lineIndex = [];
  while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
    $lineIdStr = bin_to_uuid($r['id']);
    $refIdStr = bin_to_uuid($r['ref_id']);
    if ($lineIdStr === null || $refIdStr === null) continue;

    if (!isset($lineIndex[$lineIdStr])) {
      $lineType = (int)$r['line_type'];
      $qty = (float)($r['qty'] ?? 1);
      $unitPrice = (float)($r['unit_price'] ?? 0);
      $discount = $r['discount'] !== null ? (float)$r['discount'] : null;
      $lineTotal = max(0.0, ($qty * $unitPrice) - ($discount ?? 0.0));
      if ($lineType === 2) {
        $payload['products_total'] += $lineTotal;
      } else {
        $payload['services_total'] += $lineTotal;
      }

      $payload['lines'][] = [
        'id' => $lineIdStr,
        'ref_id' => $refIdStr,
        'line_type' => $lineType,
        'title' => $r['title'],
        'qty' => $qty,
        'unit_price' => $unitPrice,
        'discount' => $discount,
        'variants' => [],
      ];
      $lineIndex[$lineIdStr] = count($payload['lines']) - 1;
    }

    if ($r['variant_id'] !== null && $r['variant_ref_id'] !== null) {
      $idx = $lineIndex[$lineIdStr];
      $payload['lines'][$idx]['variants'][] = [
        'id' => bin_to_uuid($r['variant_id']),
        'variant_ref_id' => bin_to_uuid($r['variant_ref_id']),
        'title' => $r['variant_title'],
        'qty' => (float)($r['variant_qty'] ?? 1),
        'unit_price' => (float)($r['variant_unit_price'] ?? 0),
      ];
    }
  }

  return $payload;
}


function bcrypt_hash_password($plain): string {
  return password_hash($plain, PASSWORD_BCRYPT);
}

function ensure_user_exists(PDO $pdo, $userIdBin, string $username, ?string $email, ?string $passwordPlain, int $isActive) {
  // email is nullable but unique when not null
  $passwordHash = null;
  if ($passwordPlain !== null && trim($passwordPlain) !== '') {
    $passwordHash = bcrypt_hash_password($passwordPlain);
  }

  if ($passwordHash !== null) {
    $st = $pdo->prepare("
      INSERT INTO user (id, username, email, password_hash, is_active, created_at, updated_at, deleted_at)
      VALUES (?, ?, ?, ?, ?, NOW(), NOW(), NULL)
      ON DUPLICATE KEY UPDATE
        username=VALUES(username),
        email=VALUES(email),
        password_hash=VALUES(password_hash),
        is_active=VALUES(is_active),
        updated_at=NOW(),
        deleted_at=NULL
    ");
    $st->execute([$userIdBin, $username, $email, $passwordHash, $isActive]);
  } else {
    // keep existing password_hash
    $st = $pdo->prepare("
      INSERT INTO user (id, username, email, password_hash, is_active, created_at, updated_at, deleted_at)
      VALUES (?, ?, ?, password_hash, ?, NOW(), NOW(), NULL)
      ON DUPLICATE KEY UPDATE
        username=VALUES(username),
        email=VALUES(email),
        is_active=VALUES(is_active),
        updated_at=NOW(),
        deleted_at=NULL
    ");
    $st->execute([$userIdBin, $username, $email, $isActive]);
  }
}

function ensure_salon_user(PDO $pdo, $salonIdBin, $userIdBin, string $role, string $displayName, ?string $profession, int $isActive, int $sortOrder) {
  if ($role !== 'admin') $role = 'user';
  $displayName = trim($displayName);
  if ($displayName === '') $displayName = '(unknown)';
  $profession = is_string($profession) ? trim($profession) : null;
  if ($profession === '') $profession = null;
  if ($profession === null) $profession = 'unknown';

  $st = $pdo->prepare("
    INSERT INTO salon_user (salon_id, user_id, role, display_name, profession, is_active, sort_order, created_at, updated_at, deleted_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), NULL)
    ON DUPLICATE KEY UPDATE
      role=VALUES(role),
      display_name=VALUES(display_name),
      profession=VALUES(profession),
      is_active=VALUES(is_active),
      sort_order=VALUES(sort_order),
      updated_at=NOW(),
      deleted_at=NULL
  ");
  $st->execute([$salonIdBin, $userIdBin, $role, $displayName, $profession, $isActive, $sortOrder]);
}

function make_placeholder_username($userIdBin): string {
  $uuid = bin_to_uuid($userIdBin);
  $short = substr(str_replace('-', '', $uuid), 0, 12);
  return 'sync_' . $short;
}


$pdo = db();
$auth = require_auth($pdo);
$authDeviceId = $auth['device_id'];

// Auth user id (BINARY(16)) used as staff_id fallback when client sends non-UUID like "col-..."
$authUserId = $auth['user_id'] ?? ($auth['user_id_bin'] ?? ($auth['userId'] ?? null));
if (!is_string($authUserId) || strlen($authUserId) !== 16) {
  throw new Exception('Auth token missing user_id');
}

$body = json_decode(file_get_contents('php://input'), true) ?: [];
$salonIdStr = (string)($body['salon_id'] ?? '');
$deviceIdStr = (string)($body['device_id'] ?? '');
$ops = $body['ops'] ?? [];

if ($salonIdStr === '' || $deviceIdStr === '' || !is_array($ops)) {
  json_response(['error'=>'bad_request'], 400);
}

$salonId = uuid_to_bin($salonIdStr);
$deviceId = uuid_to_bin($deviceIdStr);
if ($deviceId !== $authDeviceId) {
  json_response(['error'=>'device_mismatch'], 403);
}

$applied = [];
$conflicts = [];

$pdo->beginTransaction();
try {
  foreach ($ops as $op) {
    if (!is_array($op)) continue;
    $opIdStr = (string)($op['op_id'] ?? '');
    $entityType = (string)($op['entity_type'] ?? '');
    $opKind = (string)($op['op'] ?? '');
    $baseVersion = isset($op['base_version']) ? (int)$op['base_version'] : 0;
    $payload = $op['payload'] ?? [];
    if (!is_array($payload)) $payload = [];
    if ($opIdStr === '' || $entityType === '' || $opKind === '') continue;

    $opId = uuid_to_bin($opIdStr);

    // Idempotency
    $st = $pdo->prepare("INSERT IGNORE INTO applied_op (device_id, op_id, salon_id, applied_at) VALUES (?, ?, ?, NOW())");
    $st->execute([$deviceId, $opId, $salonId]);
    if ($st->rowCount() === 0) {
      $applied[] = $opIdStr;
      continue;
    }


    // USER upsert/delete (staff.id == user.id; profile per salon in salon_user)
    if ($entityType === 'user' && $opKind === 'upsert') {
      $idStr = (string)($payload['id'] ?? '');
      if (!is_uuid_str($idStr)) {
        throw new Exception("Invalid UUID (user.id): " . $idStr);
      }
      $userId = uuid_to_bin($idStr);

      $username = trim((string)($payload['username'] ?? ''));
      if ($username === '') {
        throw new Exception("Username missing in user upsert");
      }

      $email = $payload['email'] ?? null;
      $email = is_string($email) ? trim($email) : null;
      if ($email === '') $email = null;

      $password = $payload['password'] ?? null;
      $password = is_string($password) ? trim($password) : null;
      if ($password === '') $password = null;

      $isActive = isset($payload['is_active']) ? (int)$payload['is_active'] : 1;

      $role = (string)($payload['role'] ?? 'user');
      if ($role !== 'admin') $role = 'user';

      $displayName = trim((string)($payload['display_name'] ?? $username));
      if ($displayName === '') $displayName = $username;

      $profession = $payload['profession'] ?? null;
      $profession = is_string($profession) ? trim($profession) : null;
      if ($profession === '') $profession = null;
      if ($profession === null) {
        $profession = ($role === 'admin') ? 'unknown' : 'unknown';
      }

      $sortOrder = isset($payload['sort_order']) ? (int)$payload['sort_order'] : 0;

      ensure_user_exists($pdo, $userId, $username, $email, $password, $isActive);
      ensure_salon_user($pdo, $salonId, $userId, $role, $displayName, $profession, $isActive, $sortOrder);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'user', ?, 'upsert', ?, NOW())")
          ->execute([$salonId, $userId, json_encode([
            'id' => $idStr,
            'username' => $username,
            'email' => $email,
            'is_active' => $isActive,
            'role' => $role,
            'display_name' => $displayName,
            'profession' => $profession,
            'sort_order' => $sortOrder,
          ], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }

    if ($entityType === 'user' && $opKind === 'delete') {
      $idStr = (string)($payload['id'] ?? $op['entity_id'] ?? '');
      if (!is_uuid_str($idStr)) {
        throw new Exception("Invalid UUID (user.id): " . $idStr);
      }
      $userId = uuid_to_bin($idStr);

      // soft-delete membership & user (keep historical integrity)
      $pdo->prepare("UPDATE salon_user SET deleted_at=NOW() WHERE salon_id=? AND user_id=?")->execute([$salonId, $userId]);
      $pdo->prepare("UPDATE user SET deleted_at=NOW(), is_active=0 WHERE id=?")->execute([$userId]);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'user', ?, 'delete', ?, NOW())")
          ->execute([$salonId, $userId, json_encode(['id'=>$idStr], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }


    if ($entityType === 'salon' && $opKind === 'upsert') {
      $idStr = (string)($payload['id'] ?? $salonIdStr ?? '');
      if (!is_uuid_str($idStr)) {
        throw new Exception("Invalid UUID (salon.id): " . $idStr);
      }
      $targetSalonId = uuid_to_bin($idStr);
      $name = trim((string)($payload['name'] ?? ''));
      $salonNumber = isset($payload['salon_number']) ? (int)$payload['salon_number'] : 0;
      if ($name === '') {
        throw new Exception("Salon name missing in salon upsert");
      }
      if ($salonNumber <= 0) {
        throw new Exception("Salon number missing in salon upsert");
      }

      $st = $pdo->prepare("SELECT 1 FROM salon WHERE salon_number = ? AND id != ? AND deleted_at IS NULL LIMIT 1");
      $st->execute([$salonNumber, $targetSalonId]);
      if ($st->fetchColumn()) {
        throw new Exception("Salon number already exists");
      }

      $pdo->prepare("UPDATE salon SET name=?, salon_number=?, updated_at=NOW() WHERE id=?")
          ->execute([$name, $salonNumber, $targetSalonId]);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'salon', ?, 'upsert', ?, NOW())")
          ->execute([$targetSalonId, $targetSalonId, json_encode([
            'id' => $idStr,
            'name' => $name,
            'salon_number' => $salonNumber,
          ], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }

    if ($entityType === 'catalog_item' && $opKind === 'upsert') {
      $idStr = (string)($payload['id'] ?? '');
      $targetSalonIdStr = (string)($payload['salon_id'] ?? $salonIdStr ?? '');
      if (!is_uuid_str($idStr)) {
        throw new Exception("Invalid UUID (catalog_item.id): " . $idStr);
      }
      if (!is_uuid_str($targetSalonIdStr)) {
        throw new Exception("Invalid UUID (catalog_item.salon_id): " . $targetSalonIdStr);
      }
      $entityId = uuid_to_bin($idStr);
      $targetSalonId = uuid_to_bin($targetSalonIdStr);
      $type = trim((string)($payload['type'] ?? ''));
      $category = trim((string)($payload['category'] ?? ''));
      $profession = trim((string)($payload['profession'] ?? ''));
      $name = trim((string)($payload['name'] ?? ''));
      $defaultPrice = array_key_exists('default_price', $payload) && $payload['default_price'] !== null ? (float)$payload['default_price'] : null;
      $orderIndex = isset($payload['order_index']) ? (int)$payload['order_index'] : 0;
      $isActive = isset($payload['is_active']) ? (int)$payload['is_active'] : 1;
      if ($type === '' || $profession === '' || $name === '') {
        throw new Exception("catalog_item missing required fields");
      }

      $pdo->prepare("
        INSERT INTO catalog_item (id, salon_id, type, category, profession, name, default_price, order_index, is_active, created_at, updated_at, deleted_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), NULL)
        ON DUPLICATE KEY UPDATE
          type=VALUES(type),
          category=VALUES(category),
          profession=VALUES(profession),
          name=VALUES(name),
          default_price=VALUES(default_price),
          order_index=VALUES(order_index),
          is_active=VALUES(is_active),
          updated_at=NOW(),
          deleted_at=NULL
      ")->execute([$entityId, $targetSalonId, $type, $category, $profession, $name, $defaultPrice, $orderIndex, $isActive]);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'catalog_item', ?, 'upsert', ?, NOW())")
          ->execute([$targetSalonId, $entityId, json_encode([
            'id' => $idStr,
            'salon_id' => $targetSalonIdStr,
            'type' => $type,
            'category' => $category,
            'profession' => $profession,
            'name' => $name,
            'default_price' => $defaultPrice,
            'order_index' => $orderIndex,
            'is_active' => $isActive,
          ], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }

    if ($entityType === 'attribute_option' && $opKind === 'upsert') {
      $idStr = (string)($payload['id'] ?? '');
      $targetSalonIdStr = (string)($payload['salon_id'] ?? $salonIdStr ?? '');
      if (!is_uuid_str($idStr)) {
        throw new Exception("Invalid UUID (attribute_option.id): " . $idStr);
      }
      if (!is_uuid_str($targetSalonIdStr)) {
        throw new Exception("Invalid UUID (attribute_option.salon_id): " . $targetSalonIdStr);
      }
      $entityId = uuid_to_bin($idStr);
      $targetSalonId = uuid_to_bin($targetSalonIdStr);
      $type = trim((string)($payload['type'] ?? ''));
      $value = trim((string)($payload['value'] ?? ''));
      $orderIndex = isset($payload['order_index']) ? (int)$payload['order_index'] : 0;
      $isActive = isset($payload['is_active']) ? (int)$payload['is_active'] : 1;
      if ($type === '' || $value === '') {
        throw new Exception("attribute_option missing required fields");
      }

      $pdo->prepare("
        INSERT INTO attribute_option (id, salon_id, type, value, order_index, is_active, created_at, updated_at, deleted_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), NULL)
        ON DUPLICATE KEY UPDATE
          type=VALUES(type),
          value=VALUES(value),
          order_index=VALUES(order_index),
          is_active=VALUES(is_active),
          updated_at=NOW(),
          deleted_at=NULL
      ")->execute([$entityId, $targetSalonId, $type, $value, $orderIndex, $isActive]);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'attribute_option', ?, 'upsert', ?, NOW())")
          ->execute([$targetSalonId, $entityId, json_encode([
            'id' => $idStr,
            'salon_id' => $targetSalonIdStr,
            'type' => $type,
            'value' => $value,
            'order_index' => $orderIndex,
            'is_active' => $isActive,
          ], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }


    if ($entityType === 'salon_settings' && $opKind === 'upsert') {
      $targetSalonIdStr = (string)($payload['salon_id'] ?? $salonIdStr ?? '');
      if (!is_uuid_str($targetSalonIdStr)) {
        throw new Exception("Invalid UUID (salon_settings.salon_id): " . $targetSalonIdStr);
      }
      $targetSalonId = uuid_to_bin($targetSalonIdStr);

      $dayStartMinute = isset($payload['day_start_minute']) ? (int)$payload['day_start_minute'] : 480;
      $dayEndMinute = isset($payload['day_end_minute']) ? (int)$payload['day_end_minute'] : 1320;
      $slotMinutes = isset($payload['slot_minutes']) ? (int)$payload['slot_minutes'] : 10;

      $pdo->prepare("
        INSERT INTO salon_settings (salon_id, day_start_minute, day_end_minute, slot_minutes, created_at, updated_at)
        VALUES (?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
          day_start_minute=VALUES(day_start_minute),
          day_end_minute=VALUES(day_end_minute),
          slot_minutes=VALUES(slot_minutes),
          updated_at=NOW()
      ")->execute([$targetSalonId, $dayStartMinute, $dayEndMinute, $slotMinutes]);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'salon_settings', ?, 'upsert', ?, NOW())")
          ->execute([$targetSalonId, $targetSalonId, json_encode([
            'salon_id' => $targetSalonIdStr,
            'day_start_minute' => $dayStartMinute,
            'day_end_minute' => $dayEndMinute,
            'slot_minutes' => $slotMinutes,
          ], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }

    
    if ($entityType === 'salon_work_hours' && $opKind === 'upsert') {

      $targetSalonIdStr = (string)($payload['salon_id'] ?? $salonIdStr ?? '');
      if (!is_uuid_str($targetSalonIdStr)) {
        throw new Exception("Invalid UUID (salon_work_hours.salon_id): " . $targetSalonIdStr);
      }
      $targetSalonId = uuid_to_bin($targetSalonIdStr);

      $weekday = isset($payload['weekday']) ? (int)$payload['weekday'] : 0;
      if ($weekday < 1 || $weekday > 7) {
        throw new Exception("Invalid weekday (salon_work_hours.weekday): " . $weekday);
      }

      $startMinute = isset($payload['start_minute']) ? (int)$payload['start_minute'] : 0;
      $endMinute = isset($payload['end_minute']) ? (int)$payload['end_minute'] : 0;

      // find existing row by (salon_id, weekday)
      $st = $pdo->prepare("SELECT id FROM salon_work_hours WHERE salon_id=? AND weekday=? LIMIT 1");
      $st->execute([$targetSalonId, $weekday]);
      $existingId = $st->fetchColumn();

      if ($existingId) {
        $entityId = $existingId;
      } else {
        $entityId = random_bytes(16);
      }

      $pdo->prepare("
        INSERT INTO salon_work_hours (id, salon_id, weekday, start_minute, end_minute, created_at, updated_at, deleted_at)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW(), NULL)
        ON DUPLICATE KEY UPDATE
          start_minute=VALUES(start_minute),
          end_minute=VALUES(end_minute),
          updated_at=NOW(),
          deleted_at=NULL
      ")->execute([$entityId, $targetSalonId, $weekday, $startMinute, $endMinute]);

      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'salon_work_hours', ?, 'upsert', ?, NOW())")
          ->execute([$targetSalonId, $entityId, json_encode([
            'salon_id' => $targetSalonIdStr,
            'weekday' => $weekday,
            'start_minute' => $startMinute,
            'end_minute' => $endMinute,
          ], JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }

	if ($entityType === 'entry' && $opKind === 'delete') {
  $entryIdStr = (string)($payload['id'] ?? $entityIdStr ?? '');
  if ($entryIdStr === '' || !is_uuid_str($entryIdStr)) {
    throw new Exception("Invalid UUID (entry.id): " . $entryIdStr);
  }

  $entryId = uuid_to_bin($entryIdStr);

  // Soft delete entry itself
  $pdo->prepare("
    UPDATE entry
    SET
      deleted_at = NOW(),
      updated_at = NOW(),
      version = version + 1
    WHERE id = ? AND salon_id = ?
  ")->execute([$entryId, $salonId]);

  // Optional but recommended: mark lines deleted too
  $pdo->prepare("
    UPDATE entry_line
    SET
      deleted_at = NOW(),
      updated_at = NOW(),
      version = version + 1
    WHERE entry_id = ? AND salon_id = ?
  ")->execute([$entryId, $salonId]);

  // Notify other devices
  $pdo->prepare("
    INSERT INTO change_event
      (salon_id, entity_type, entity_id, op, payload_json, created_at)
    VALUES
      (?, 'entry', ?, 'delete', ?, NOW())
  ")->execute([
    $salonId,
    $entryId,
    json_encode(['id' => $entryIdStr], JSON_UNESCAPED_UNICODE),
  ]);

  $applied[] = $opIdStr;
  continue;
}

    if ($entityType === 'entry' && $opKind === 'upsert') {
      $entryIdStr = (string)($payload['id'] ?? '');
      if (!is_uuid_str($entryIdStr)) {
        throw new Exception("Invalid UUID: " . $entryIdStr);
      }
      $entryId = uuid_to_bin($entryIdStr);
      // Resolve work_day_id: accept either work_day_id OR date (YYYY-MM-DD)
$workDayIdBin = null;

// Resolve work_day_id: accept either work_day_id OR date (YYYY-MM-DD).
$wd = $payload['work_day_id'] ?? null;
if (is_string($wd) && $wd !== '') {
  $workDayIdBin = uuid_to_bin($wd);
} else {
  $date = (string)($payload['date'] ?? '');
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    throw new Exception("Missing or invalid date (YYYY-MM-DD) for work_day");
  }

  // Ensure work_day exists for (salon_id, date).
  // Assumes UNIQUE KEY (salon_id, date) on work_day.
  $sel = $pdo->prepare("SELECT id FROM work_day WHERE salon_id=? AND date=? LIMIT 1");
  $sel->execute([$salonId, $date]);
  $found = $sel->fetchColumn();

  if ($found !== false && $found !== null && $found !== '') {
    $workDayIdBin = $found; // binary(16)
  } else {
    // Try insert (race-safe via UNIQUE KEY).
    $b = random_bytes(16);          // UUIDv4 binary
    $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
    $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);

    $ins = $pdo->prepare("
      INSERT INTO work_day (id, salon_id, date, created_at, updated_at)
      VALUES (?, ?, ?, NOW(), NOW())
      ON DUPLICATE KEY UPDATE updated_at=updated_at
    ");
    $ins->execute([$b, $salonId, $date]);

    // Re-select id (either our new one or existing one if another request won the race)
    $sel->execute([$salonId, $date]);
    $workDayIdBin = $sel->fetchColumn();
    if ($workDayIdBin === false || $workDayIdBin === null || $workDayIdBin === '') {
      throw new Exception("Failed to resolve work_day_id for date={$date}");
    }
  }
}
      $staffIdStr = (string)($payload['staff_id'] ?? '');
      $staffId = ($staffIdStr !== '' && is_uuid_str($staffIdStr))
        ? uuid_to_bin($staffIdStr)
        : $authUserId;

      // Ensure referenced staff user exists (FK entry.staff_id -> user.id).
      // Do NOT auto-create placeholder sync_* users. Users must be synced first.
      $stUser = $pdo->prepare("SELECT 1 FROM user WHERE id=? AND deleted_at IS NULL LIMIT 1");
      $stUser->execute([$staffId]);
      if ($stUser->fetchColumn() === false) {
        throw new Exception("Staff user missing on server; sync user first");
      }
      $startMin = (int)($payload['start_min'] ?? 0);
      $endMin = (int)($payload['end_min'] ?? 0);
      $status = (int)($payload['status'] ?? 0);
      $clientName = (string)($payload['client_name'] ?? '');
      $notes = (string)($payload['notes'] ?? '');

      $cur = $pdo->prepare("SELECT version FROM entry WHERE id=? AND salon_id=? LIMIT 1");
      $cur->execute([$entryId, $salonId]);
      $curRow = $cur->fetch();
      if ($curRow && $baseVersion > 0 && $baseVersion !== (int)$curRow['version']) {
        // SERVER WINS: don't apply client change; return server snapshot so client can overwrite local.
        $srv = $pdo->prepare("SELECT * FROM entry WHERE id=? AND salon_id=? LIMIT 1");
        $srv->execute([$entryId, $salonId]);
        $srvRow = $srv->fetch(PDO::FETCH_ASSOC) ?: null;

        $conflicts[] = [
          'op_id' => $opIdStr,
          'entity_type' => 'entry',
          'entity_id' => $payload['id'],
          'reason' => 'server_wins',
          'server_version' => (int)$curRow['version'],
          'server' => $srvRow ? entry_row_to_payload($srvRow) : null,
        ];

        // Still mark op as applied for idempotency (avoid re-sending same op forever).
        $applied[] = $opIdStr;
        continue;
      }

      $pdo->prepare("
        INSERT INTO entry (id, salon_id, work_day_id, staff_id, start_min, end_min, status, client_name, notes, version, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
          work_day_id=VALUES(work_day_id),
          staff_id=VALUES(staff_id),
          start_min=VALUES(start_min),
          end_min=VALUES(end_min),
          status=VALUES(status),
          client_name=VALUES(client_name),
          notes=VALUES(notes),
          version=version+1,
          updated_at=NOW(),
          deleted_at=NULL
      ")->execute([$entryId, $salonId, $workDayIdBin, $staffId, $startMin, $endMin, $status, $clientName, $notes]);

      $lines = $payload['lines'] ?? null;
      if (is_array($lines)) {

        // Helper: map line_type to tinyint
        $mapLineType = function($raw): int {
          if (is_numeric($raw)) return (int)$raw;
          $s = is_string($raw) ? strtolower(trim($raw)) : '';
          if ($s === 'service') return 1;
          if ($s === 'product') return 2;
          if ($s === 'package') return 3;
          return -1;
        };

        // 1) First delete variants (FK points to entry_line, NO CASCADE)
        $pdo->prepare("
          DELETE elv FROM entry_line_variant elv
          INNER JOIN entry_line el ON el.id = elv.entry_line_id
          WHERE el.entry_id = ?
        ")->execute([$entryId]);

        // 2) Then delete lines
        $pdo->prepare("DELETE FROM entry_line WHERE entry_id=?")->execute([$entryId]);

        // 3) Insert lines (with snapshot title)
        $insLine = $pdo->prepare("
          INSERT INTO entry_line (id, salon_id, entry_id, line_type, ref_id, title, qty, unit_price, discount, version, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
        ");

        // 4) Insert variants (optional)
        $insVar = $pdo->prepare("
          INSERT INTO entry_line_variant (id, salon_id, entry_line_id, variant_ref_id, title, qty, unit_price, version, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
        ");

        foreach ($lines as $l) {
          if (!is_array($l)) continue;

          $lineIdStr = (string)($l['id'] ?? '');
          $refIdStr  = (string)($l['ref_id'] ?? ($l['catalog_item_id'] ?? ($l['item_id'] ?? '')));
          $title     = (string)($l['title'] ?? ($l['name'] ?? ($l['label'] ?? '')));
          if ($title !== '') $title = mb_substr($title, 0, 255, 'UTF-8');

          $lineType = $mapLineType($l['line_type'] ?? null);
          $qty      = (float)($l['qty'] ?? 1);

          // Accept multiple key spellings from client
          $unitPriceRaw = $l['unit_price'] ?? ($l['unitPrice'] ?? ($l['price'] ?? ($l['amount'] ?? 0)));
          $unitPrice = (float)$unitPriceRaw;

          $discount = $l['discount'] ?? null;
          $discount = ($discount === null || $discount === '') ? null : (float)$discount;

          if ($lineIdStr === '' || $refIdStr === '' || $lineType < 0) continue;
          // Server schema requires UUIDs for entry_line.id and ref_id; skip invalid rows instead of failing the whole push.
          if (!is_uuid_str($lineIdStr) || !is_uuid_str($refIdStr)) continue;

          $lineId = uuid_to_bin($lineIdStr);
          $refId  = uuid_to_bin($refIdStr);

          $insLine->execute([$lineId, $salonId, $entryId, $lineType, $refId, $title, $qty, $unitPrice, $discount]);

          // Variants
          $variants = $l['variants'] ?? null;
          if (is_array($variants)) {
            foreach ($variants as $v) {
              if (!is_array($v)) continue;
              $varIdStr    = (string)($v['id'] ?? '');
              $varRefIdStr = (string)($v['variant_ref_id'] ?? '');
              $vTitle = (string)($v['title'] ?? ($v['name'] ?? ($v['label'] ?? '')));
              if ($vTitle !== '') $vTitle = mb_substr($vTitle, 0, 255, 'UTF-8');
              if ($varIdStr === '' || $varRefIdStr === '') continue;
              if (!is_uuid_str($varIdStr) || !is_uuid_str($varRefIdStr)) continue;
              $vQty = (float)($v['qty'] ?? 1);
              $vUnitPriceRaw = $v['unit_price'] ?? ($v['unitPrice'] ?? ($v['price'] ?? ($v['amount'] ?? 0)));
              $vUnitPrice = (float)$vUnitPriceRaw;

              $insVar->execute([
                uuid_to_bin($varIdStr),
                $salonId,
                $lineId,
                uuid_to_bin($varRefIdStr),
                $vTitle,
                $vQty,
                $vUnitPrice,
              ]);
            }
          }
        }

        // Recalculate entry.price_total.
        // Preferred source: explicit section totals from client (offline-first UI already has them).
        // Fallback: sum entry_line rows on the server.
        $clientServicesTotal = isset($payload['services_total']) ? (float)$payload['services_total'] : null;
        $clientProductsTotal = isset($payload['products_total']) ? (float)$payload['products_total'] : null;
        $clientPriceTotal    = isset($payload['price_total'])    ? (float)$payload['price_total']    : null;

        if ($clientPriceTotal !== null) {
          $total = $clientPriceTotal;
        } elseif ($clientServicesTotal !== null || $clientProductsTotal !== null) {
          $total = (float)($clientServicesTotal ?? 0) + (float)($clientProductsTotal ?? 0);
        } else {
          $stSum = $pdo->prepare("SELECT COALESCE(SUM(qty * unit_price - COALESCE(discount,0)), 0) FROM entry_line WHERE entry_id=? AND deleted_at IS NULL");
          $stSum->execute([$entryId]);
          $total = (float)$stSum->fetchColumn();
        }

        $pdo->prepare("UPDATE entry SET price_total=?, updated_at=NOW() WHERE id=? AND salon_id=?")
            ->execute([$total, $entryId, $salonId]);
      }

      $entryPayload = load_entry_payload($pdo, $entryId);
      $pdo->prepare("INSERT INTO change_event (salon_id, entity_type, entity_id, op, payload_json, created_at) VALUES (?, 'entry', ?, 'upsert', ?, NOW())")
          ->execute([$salonId, $entryId, json_encode($entryPayload, JSON_UNESCAPED_UNICODE)]);

      $applied[] = $opIdStr;
      continue;
    }

    $applied[] = $opIdStr;
  }

  $stt = $pdo->prepare("SELECT COALESCE(MAX(token),0) AS t FROM change_event WHERE salon_id=?");
  $stt->execute([$salonId]);
  $toToken=(int)$stt->fetchColumn();

  $pdo->commit();
  json_response(['applied'=>$applied,'conflicts'=>$conflicts,'to_token'=>$toToken]);
} catch (Throwable $e) {
  $pdo->rollBack();
  json_response(['error'=>'server_error','message'=>$e->getMessage()], 500);
}
